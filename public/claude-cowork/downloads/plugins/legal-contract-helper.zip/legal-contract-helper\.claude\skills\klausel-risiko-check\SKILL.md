---
name: klausel-risiko-check
description: Bewertet einzelne Klauseln nach Verstaendlichkeit, wirtschaftlichem Risiko und Klärungsbedarf.
---

# Klausel-Risiko-Check

## Wann verwenden
Nutze diesen Skill, wenn du für Legal Ops, Sales, Management den beschriebenen Arbeitsprozess mit Claude strukturiert vorbereiten oder ausführen willst.

## Aufgabe
Bewertet einzelne Klauseln nach Verstaendlichkeit, wirtschaftlichem Risiko und Klärungsbedarf.

## Typischer Input
- Klauseltext
- Vertragsart
- Verhandlungsziel

## Vorgehen
1. Kläre Ziel, Kontext, Zielgruppe und gewünschtes Ausgabeformat.
2. Markiere fehlende Informationen als Rückfragen, statt sie zu erfinden.
3. Strukturiere den Arbeitsprozess in nachvollziehbare Schritte.
4. Erstelle einen ersten Output, der direkt weiterbearbeitet werden kann.
5. Füge einen kurzen Qualitätscheck mit Risiken, Annahmen und nächsten Schritten hinzu.

## Typischer Output
- Risikoeinschaetzung
- Alternativfragen
- Hinweise

## Qualitätscheck
- Sind Annahmen, Unsicherheiten und fehlende Informationen sichtbar?
- Ist der Output für den Arbeitsalltag nutzbar und nicht nur allgemein formuliert?
- Stimmen Ton, Detailgrad und Format mit dem Zielkontext überein?
- Gibt es eine klare Empfehlung oder einen nächsten Schritt?

## Grenzen
Dieser Skill ersetzt keine Rechts-, Steuer-, Finanz- oder Datenschutzberatung. Nutze ihn zur Vorbereitung, Strukturierung und Qualitätssicherung, nicht als finale Fachentscheidung.
