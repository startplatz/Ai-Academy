# Legal & Contract Helper

Ein Dokumentenhelfer fuer Vertraege, Klauseln, Vereinbarungen und geschäftliche Pruefprozesse.

## Enthaltene Skills
- Vertragsreview
- Klausel-Risiko-Check
- Vergleich zweier Vertragsversionen
- Rueckfragenliste fuer Rechtsberatung
- Angebots- und Leistungsumfang-Check
- DocuSign-Prep

## Installation
Kopiere die Ordner aus `.claude/skills/` in dein Claude-Code-Projekt oder in deinen persoenlichen Skills-Ordner.
