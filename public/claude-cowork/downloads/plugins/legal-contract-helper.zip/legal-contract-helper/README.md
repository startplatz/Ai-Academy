# Legal & Contract Helper

Dieses Plugin bündelt mehrere Claude Cowork Skills für einen zusammenhängenden Arbeitsbereich.

## Enthaltene Skills
- /legal-contract-helper:vertragsreview - Vertragsreview
- /legal-contract-helper:klausel-risiko-check - Klausel-Risiko-Check
- /legal-contract-helper:vergleich-zweier-vertragsversionen - Vergleich zweier Vertragsversionen
- /legal-contract-helper:rueckfragenliste-fuer-rechtsberatung - Rückfragenliste für Rechtsberatung
- /legal-contract-helper:angebots-und-leistungsumfang-check - Angebots- und Leistungsumfang-Check
- /legal-contract-helper:docusign-prep - DocuSign-Prep

## Format
Dieses ZIP folgt dem Claude Code / Cowork Plugin-Format:

- `.claude-plugin/plugin.json` beschreibt das Plugin.
- `skills/<skill-name>/SKILL.md` enthält die einzelnen Skills.
- Die Skill-Namen werden im Plugin namespaced, z. B. `/legal-contract-helper:vertragsreview`.

Für Claude.ai Custom Skill Uploads nutze die einzelnen Skill-ZIPs aus der Skill Library. Dieses Paket ist bewusst ein Plugin-Bundle.
