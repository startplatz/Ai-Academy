---
name: legal-contract-helper
description: 'Ein Dokumentenhelfer für Verträge, Klauseln, Vereinbarungen und geschäftliche Prüfprozesse.'
---

# Legal & Contract Helper

## Wann verwenden
Nutze diesen Skill, wenn du einen kompletten Arbeitsbereich statt einzelner Skills aktivieren willst. Das Paket bündelt mehrere Claude-Workflows für typische Aufgaben und verweist auf fokussierte Referenzdateien.

## Arbeitsweise
1. Kläre zuerst, welche Aufgabe, Eingabe und gewünschter Output vorliegen.
2. Wähle aus den enthaltenen Skills die passendste Referenzdatei aus eferences/.
3. Lies nur die Referenz, die zur Aufgabe passt, und folge deren Vorgehen.
4. Wenn mehrere Aufgaben kombiniert sind, arbeite sie nacheinander ab und trenne die Ergebnisse sauber.
5. Frage nach, wenn Pflichtinformationen wie Zielgruppe, Format, Zeitraum, Kennzahlen oder Tonalität fehlen.

## Enthaltene Skills
- Vertragsreview: Strukturiert Verträge, markiert auffällige Klauseln, offene Punkte und Fragen für die rechtliche Prüfung.
- Klausel-Risiko-Check: Bewertet einzelne Klauseln nach Verstaendlichkeit, wirtschaftlichem Risiko und Klärungsbedarf.
- Vergleich zweier Vertragsversionen: Vergleicht zwei Vertragsfassungen und macht inhaltliche, wirtschaftliche und formale Unterschiede sichtbar.
- Rückfragenliste für Rechtsberatung: Erstellt aus Dokumenten und Unsicherheiten eine sortierte Rückfragenliste für externe Rechtsberatung.
- Angebots- und Leistungsumfang-Check: Prüft Angebote und Leistungsbeschreibungen auf Klarheit, Abgrenzung, Annahmen und potenzielle Scope-Risiken.
- DocuSign-Prep: Bereitet Unterzeichnungsprozesse mit Dokumenten, Rollen, Signaturfeldern und Begleitkommunikation vor.

## Referenzen
- eferences/vertragsreview.md: nutze diese Referenz, wenn die Aufgabe zu diesem Skill passt.
- eferences/klausel-risiko-check.md: nutze diese Referenz, wenn die Aufgabe zu diesem Skill passt.
- eferences/vergleich-zweier-vertragsversionen.md: nutze diese Referenz, wenn die Aufgabe zu diesem Skill passt.
- eferences/rueckfragenliste-fuer-rechtsberatung.md: nutze diese Referenz, wenn die Aufgabe zu diesem Skill passt.
- eferences/angebots-und-leistungsumfang-check.md: nutze diese Referenz, wenn die Aufgabe zu diesem Skill passt.
- eferences/docusign-prep.md: nutze diese Referenz, wenn die Aufgabe zu diesem Skill passt.