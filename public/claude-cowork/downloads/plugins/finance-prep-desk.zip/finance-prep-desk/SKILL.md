---
name: finance-prep-desk
description: 'Ein Vorbereitungspaket für finanzielle Übersicht, Buchhaltungsprozesse und betriebswirtschaftliche Auswertungen.'
---

# Finance Prep Desk

## Wann verwenden
Nutze diesen Skill, wenn du einen kompletten Arbeitsbereich statt einzelner Skills aktivieren willst. Das Paket bündelt mehrere Claude-Workflows für typische Aufgaben und verweist auf fokussierte Referenzdateien.

## Arbeitsweise
1. Kläre zuerst, welche Aufgabe, Eingabe und gewünschter Output vorliegen.
2. Wähle aus den enthaltenen Skills die passendste Referenzdatei aus eferences/.
3. Lies nur die Referenz, die zur Aufgabe passt, und folge deren Vorgehen.
4. Wenn mehrere Aufgaben kombiniert sind, arbeite sie nacheinander ab und trenne die Ergebnisse sauber.
5. Frage nach, wenn Pflichtinformationen wie Zielgruppe, Format, Zeitraum, Kennzahlen oder Tonalität fehlen.

## Enthaltene Skills
- Cashflow-Forecast: Erstellt eine einfache Cashflow-Übersicht mit offenen Rechnungen, Risiken und Liquiditätsvorschau.
- Invoice-Chaser: Erkennt offene Rechnungen, priorisiert sie und erstellt passende Zahlungserinnerungen.
- Monatsabschluss-Prepper: Bereitet Monatsabschlüsse vor, erkennt fehlende Unterlagen und strukturiert offene Finanzfragen.
- P&L-Erklärer: Erklärt Gewinn- und Verlustrechnungen verständlich und macht Auffälligkeiten sichtbar.
- Margin-Analyzer: Analysiert Margen nach Produkten, Projekten oder Kunden und zeigt wirtschaftliche Auffälligkeiten.
- Steuerordner-Builder: Strukturiert Steuerunterlagen, Belege und offene Fragen für Buchhaltung oder Steuerberatung.

## Referenzen
- eferences/cashflow-forecast.md: nutze diese Referenz, wenn die Aufgabe zu diesem Skill passt.
- eferences/invoice-chaser.md: nutze diese Referenz, wenn die Aufgabe zu diesem Skill passt.
- eferences/monatsabschluss-prepper.md: nutze diese Referenz, wenn die Aufgabe zu diesem Skill passt.
- eferences/pl-erklaerer.md: nutze diese Referenz, wenn die Aufgabe zu diesem Skill passt.
- eferences/margin-analyzer.md: nutze diese Referenz, wenn die Aufgabe zu diesem Skill passt.
- eferences/steuerordner-builder.md: nutze diese Referenz, wenn die Aufgabe zu diesem Skill passt.