---
description: 'Erklärt Gewinn- und Verlustrechnungen verständlich und macht Auffälligkeiten sichtbar.'
---

# P&L-Erklärer

## Einsatzmoment
Der Skill ist für Situationen gedacht, in denen Teilnehmende zahlengetrieben, deadline-nah und mit dem Druck, aus unordentlichen Daten belastbare Aussagen zu machen sind. Das Ziel ist nicht, schnell generischen Text zu produzieren, sondern Druck aus der Aufgabe zu nehmen und eine belastbare Arbeitsgrundlage zu schaffen.

Typische Spannung: Die P&L zeigt Ergebnisse, aber Führung braucht die Story dahinter.

## Zielbild
Am Ende liegt ein Ergebnis vor, das eine Person direkt prüfen, senden, entscheiden oder weiterbearbeiten kann. Claude soll nicht so tun, als sei alles sicher. Claude soll Annahmen, Lücken, Risiken und Rückfragen sichtbar machen.

Erwartete Outputs:
- verständliche Erklärung
- Kernaussagen
- Auffälligkeiten
- Fragen an Steuerberatung/Finance
- Handlungshinweise

## Typischer Input
- P&L-Report
- Finanzübersicht
- Vorperiode
- Budgetwerte

## Praxisprinzipien
- immer Quelle, Zeitraum, Annahmen und Unsicherheit ausweisen
- Cash, Marge und Abweichungen zuerst erklären, bevor Formulierungen poliert werden
- Steuer- und Rechtsfragen nicht selbst entscheiden, sondern sauber vorbereiten

## Expert Moves für diesen Skill
- Umsatz, Kosten, Marge und Sondereffekte trennen
- Abweichungen gegen Vorperiode/Budget erklären
- Management-Fragen antizipieren

## Vorgehen
1. Lies den Input einmal nur auf Ziel, Kontext und gewünschtes Ergebnis.
2. Markiere fehlende Informationen. Wenn sie entscheidungsrelevant sind, frage nach, statt etwas zu erfinden.
3. Trenne Fakten, Annahmen, Interpretation und Empfehlung sichtbar.
4. Erstelle zuerst eine knappe Arbeitsstruktur, dann den eigentlichen Entwurf.
5. Prüfe das Ergebnis gegen die Qualitätskriterien unten.
6. Liefere bei Unsicherheit zwei Optionen: eine vorsichtige Version und eine mutigere Version mit klarer Begründung.

## Qualitätskriterien
- Zahlenlogik ist nachvollziehbar
- Risiken und fehlende Belege sind markiert
- Output ist prüfbar und nicht nur hübsch formuliert

## Worauf du achten musst
- Zahlen ohne Ursache
- Einmaleffekte verstecken
- zu viel Buchhaltungssprache

## Rückfragen, wenn Informationen fehlen
- Was soll mit dem Ergebnis direkt passieren: senden, entscheiden, intern vorbereiten oder prüfen?
- Wer ist die Zielperson und wie viel Vorwissen hat sie?
- Welche Frist, welches Risiko oder welche geschäftliche Konsequenz hängt daran?
- Gibt es Formulierungen, Zahlen, Namen oder Zusagen, die unverändert bleiben müssen?

## Output-Format
Gib das Ergebnis in dieser Reihenfolge aus:
1. Kurzdiagnose der Ausgangslage
2. Fertiger Entwurf oder strukturierte Arbeitsvorlage
3. Annahmen und offene Punkte
4. Risiken oder rote Flaggen
5. Konkreter nächster Schritt
