# Finance Prep Desk

Dieses Plugin bündelt mehrere Claude Cowork Skills für einen zusammenhängenden Arbeitsbereich.

## Enthaltene Skills
- /finance-prep-desk:cashflow-forecast - Cashflow-Forecast
- /finance-prep-desk:invoice-chaser - Invoice-Chaser
- /finance-prep-desk:monatsabschluss-prepper - Monatsabschluss-Prepper
- /finance-prep-desk:pl-erklaerer - P&L-Erklärer
- /finance-prep-desk:margin-analyzer - Margin-Analyzer
- /finance-prep-desk:steuerordner-builder - Steuerordner-Builder

## Format
Dieses ZIP folgt dem Claude Code / Cowork Plugin-Format:

- `.claude-plugin/plugin.json` beschreibt das Plugin.
- `skills/<skill-name>/SKILL.md` enthält die einzelnen Skills.
- Die Skill-Namen werden im Plugin namespaced, z. B. `/finance-prep-desk:cashflow-forecast`.

Für Claude.ai Custom Skill Uploads nutze die einzelnen Skill-ZIPs aus der Skill Library. Dieses Paket ist bewusst ein Plugin-Bundle.
