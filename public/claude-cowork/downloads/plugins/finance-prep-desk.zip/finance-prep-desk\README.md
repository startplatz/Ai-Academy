# Finance Prep Desk

Ein Vorbereitungspaket fuer finanzielle Uebersicht, Buchhaltungsprozesse und betriebswirtschaftliche Auswertungen.

## Enthaltene Skills
- Cashflow-Forecast
- Invoice-Chaser
- Monatsabschluss-Prepper
- P&L-Erklärer
- Margin-Analyzer
- Steuerordner-Builder

## Installation
Kopiere die Ordner aus `.claude/skills/` in dein Claude-Code-Projekt oder in deinen persoenlichen Skills-Ordner.
