# Founder Operating System

Dieses Plugin bündelt mehrere Claude Cowork Skills für einen zusammenhängenden Arbeitsbereich.

## Enthaltene Skills
- /founder-operating-system:business-briefing - Business-Briefing
- /founder-operating-system:investor-update - Investor-Update
- /founder-operating-system:pitch-deck-coach - Pitch-Deck-Coach
- /founder-operating-system:wettbewerbsanalyse - Wettbewerbsanalyse
- /founder-operating-system:roadmap-priorisierer - Roadmap-Priorisierer
- /founder-operating-system:entscheidungs-memo - Entscheidungs-Memo

## Format
Dieses ZIP folgt dem Claude Code / Cowork Plugin-Format:

- `.claude-plugin/plugin.json` beschreibt das Plugin.
- `skills/<skill-name>/SKILL.md` enthält die einzelnen Skills.
- Die Skill-Namen werden im Plugin namespaced, z. B. `/founder-operating-system:business-briefing`.

Für Claude.ai Custom Skill Uploads nutze die einzelnen Skill-ZIPs aus der Skill Library. Dieses Paket ist bewusst ein Plugin-Bundle.
