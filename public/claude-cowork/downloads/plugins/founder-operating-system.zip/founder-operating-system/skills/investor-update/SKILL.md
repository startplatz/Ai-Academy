---
description: 'Erstellt strukturierte Investor Updates mit Kennzahlen, Fortschritten, Risiken und nächsten Zielen.'
---

# Investor-Update

## Einsatzmoment
Der Skill ist für Situationen gedacht, in denen Teilnehmende mit vielen strategischen Baustellen, wenig Zeit und hoher emotionaler Fallhöhe sind. Das Ziel ist nicht, schnell generischen Text zu produzieren, sondern Druck aus der Aufgabe zu nehmen und eine belastbare Arbeitsgrundlage zu schaffen.

Typische Spannung: Investoren brauchen Vertrauen, auch wenn nicht alles perfekt läuft.

## Zielbild
Am Ende liegt ein Ergebnis vor, das eine Person direkt prüfen, senden, entscheiden oder weiterbearbeiten kann. Claude soll nicht so tun, als sei alles sicher. Claude soll Annahmen, Lücken, Risiken und Rückfragen sichtbar machen.

Erwartete Outputs:
- Investor Update
- KPI-Zusammenfassung
- Highlights
- Risiken
- Ask/Supportbedarf

## Typischer Input
- KPIs
- Meilensteine
- Herausforderungen
- Learnings
- Finanzstatus
- Roadmap

## Praxisprinzipien
- zwischen Signal, Meinung und Entscheidung trennen
- Investoren-, Team- und Kundenperspektive bewusst unterschiedlich formulieren
- jede Empfehlung braucht Trade-off, Risiko und nächsten Test

## Expert Moves für diesen Skill
- Traction, Learnings, Risiken und Asks klar trennen
- Zahlen mit Kontext versehen
- knappe, ehrliche Storyline schreiben

## Vorgehen
1. Lies den Input einmal nur auf Ziel, Kontext und gewünschtes Ergebnis.
2. Markiere fehlende Informationen. Wenn sie entscheidungsrelevant sind, frage nach, statt etwas zu erfinden.
3. Trenne Fakten, Annahmen, Interpretation und Empfehlung sichtbar.
4. Erstelle zuerst eine knappe Arbeitsstruktur, dann den eigentlichen Entwurf.
5. Prüfe das Ergebnis gegen die Qualitätskriterien unten.
6. Liefere bei Unsicherheit zwei Optionen: eine vorsichtige Version und eine mutigere Version mit klarer Begründung.

## Qualitätskriterien
- knappe Executive-Logik statt langer Erklärungen
- Annahmen und Gegenargumente sind sichtbar
- Entscheidung ist mit Handlung und Lernziel verbunden

## Worauf du achten musst
- zu viel Optimismus
- Asks ohne Konkretion
- Metriken ohne Vergleich

## Rückfragen, wenn Informationen fehlen
- Was soll mit dem Ergebnis direkt passieren: senden, entscheiden, intern vorbereiten oder prüfen?
- Wer ist die Zielperson und wie viel Vorwissen hat sie?
- Welche Frist, welches Risiko oder welche geschäftliche Konsequenz hängt daran?
- Gibt es Formulierungen, Zahlen, Namen oder Zusagen, die unverändert bleiben müssen?

## Output-Format
Gib das Ergebnis in dieser Reihenfolge aus:
1. Kurzdiagnose der Ausgangslage
2. Fertiger Entwurf oder strukturierte Arbeitsvorlage
3. Annahmen und offene Punkte
4. Risiken oder rote Flaggen
5. Konkreter nächster Schritt
