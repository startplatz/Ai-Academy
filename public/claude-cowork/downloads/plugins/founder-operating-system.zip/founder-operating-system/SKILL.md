---
name: founder-operating-system
description: 'Ein operatives Steuerungssystem für Gründer und kleine Führungsteams, die Strategie, Kommunikation und Umsetzung zusammenbringen.'
---

# Founder Operating System

## Wann verwenden
Nutze diesen Skill, wenn du einen kompletten Arbeitsbereich statt einzelner Skills aktivieren willst. Das Paket bündelt mehrere Claude-Workflows für typische Aufgaben und verweist auf fokussierte Referenzdateien.

## Arbeitsweise
1. Kläre zuerst, welche Aufgabe, Eingabe und gewünschter Output vorliegen.
2. Wähle aus den enthaltenen Skills die passendste Referenzdatei aus eferences/.
3. Lies nur die Referenz, die zur Aufgabe passt, und folge deren Vorgehen.
4. Wenn mehrere Aufgaben kombiniert sind, arbeite sie nacheinander ab und trenne die Ergebnisse sauber.
5. Frage nach, wenn Pflichtinformationen wie Zielgruppe, Format, Zeitraum, Kennzahlen oder Tonalität fehlen.

## Enthaltene Skills
- Business-Briefing: Erstellt ein kompaktes Business-Briefing aus Zahlen, Terminen, Pipeline, Aufgaben und offenen Entscheidungen.
- Investor-Update: Erstellt strukturierte Investor Updates mit Kennzahlen, Fortschritten, Risiken und nächsten Zielen.
- Pitch-Deck-Coach: Verbessert Pitch Decks durch klare Storyline, Folienstruktur und überzeugende Kernbotschaften.
- Wettbewerbsanalyse: Strukturiert Wettbewerber, Positionierung und Differenzierung für bessere Strategie- und Marketingentscheidungen.
- Roadmap-Priorisierer: Priorisiert Features, Projekte und Initiativen nach Impact, Aufwand, Risiko und strategischer Relevanz.
- Entscheidungs-Memo: Erstellt klare Entscheidungs-Memos mit Optionen, Risiken, Bewertung und Empfehlung.

## Referenzen
- eferences/business-briefing.md: nutze diese Referenz, wenn die Aufgabe zu diesem Skill passt.
- eferences/investor-update.md: nutze diese Referenz, wenn die Aufgabe zu diesem Skill passt.
- eferences/pitch-deck-coach.md: nutze diese Referenz, wenn die Aufgabe zu diesem Skill passt.
- eferences/wettbewerbsanalyse.md: nutze diese Referenz, wenn die Aufgabe zu diesem Skill passt.
- eferences/roadmap-priorisierer.md: nutze diese Referenz, wenn die Aufgabe zu diesem Skill passt.
- eferences/entscheidungs-memo.md: nutze diese Referenz, wenn die Aufgabe zu diesem Skill passt.