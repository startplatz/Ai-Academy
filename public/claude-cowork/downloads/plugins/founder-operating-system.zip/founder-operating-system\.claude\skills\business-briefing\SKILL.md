---
name: business-briefing
description: Erstellt ein kompaktes Business-Briefing aus Zahlen, Terminen, Pipeline, Aufgaben und offenen Entscheidungen.
---

# Business-Briefing

## Wann verwenden
Nutze diesen Skill, wenn du für Gründer, Geschäftsführung, Startup-Teams, Operations, Assistenz den beschriebenen Arbeitsprozess mit Claude strukturiert vorbereiten oder ausführen willst.

## Aufgabe
Das Business-Briefing erstellt eine kompakte Übersicht über zentrale Geschäftsthemen: Zahlen, Pipeline, Termine, Risiken, offene Entscheidungen und wichtige nächste Schritte.

## Typischer Input
- Kalender
- E-Mails
- CRM
- Finanzdaten
- Aufgabenlisten
- Projektstände

## Vorgehen
1. Kläre Ziel, Kontext, Zielgruppe und gewünschtes Ausgabeformat.
2. Markiere fehlende Informationen als Rückfragen, statt sie zu erfinden.
3. Strukturiere den Arbeitsprozess in nachvollziehbare Schritte.
4. Erstelle einen ersten Output, der direkt weiterbearbeitet werden kann.
5. Füge einen kurzen Qualitätscheck mit Risiken, Annahmen und nächsten Schritten hinzu.

## Typischer Output
- Tages- oder Wochenbriefing
- Prioritäten
- offene Entscheidungen
- Risiken
- nächste Schritte

## Qualitätscheck
- Sind Annahmen, Unsicherheiten und fehlende Informationen sichtbar?
- Ist der Output für den Arbeitsalltag nutzbar und nicht nur allgemein formuliert?
- Stimmen Ton, Detailgrad und Format mit dem Zielkontext überein?
- Gibt es eine klare Empfehlung oder einen nächsten Schritt?

## Grenzen
Dieser Skill ersetzt keine Rechts-, Steuer-, Finanz- oder Datenschutzberatung. Nutze ihn zur Vorbereitung, Strukturierung und Qualitätssicherung, nicht als finale Fachentscheidung.
