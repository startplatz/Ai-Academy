# Founder Operating System

Ein operatives Steuerungssystem fuer Gruender und kleine Fuehrungsteams, die Strategie, Kommunikation und Umsetzung zusammenbringen.

## Enthaltene Skills
- Business-Briefing
- Investor-Update
- Pitch-Deck-Coach
- Wettbewerbsanalyse
- Roadmap-Priorisierer
- Entscheidungs-Memo

## Installation
Kopiere die Ordner aus `.claude/skills/` in dein Claude-Code-Projekt oder in deinen persoenlichen Skills-Ordner.
