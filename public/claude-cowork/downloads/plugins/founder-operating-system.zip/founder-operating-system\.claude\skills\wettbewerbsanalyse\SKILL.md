---
name: wettbewerbsanalyse
description: Strukturiert Wettbewerber, Positionierung und Differenzierung für bessere Strategie- und Marketingentscheidungen.
---

# Wettbewerbsanalyse

## Wann verwenden
Nutze diesen Skill, wenn du für Gründer, Marketing, Geschäftsführung, Produktteams, Sales den beschriebenen Arbeitsprozess mit Claude strukturiert vorbereiten oder ausführen willst.

## Aufgabe
Die Wettbewerbsanalyse strukturiert Wettbewerber, Marktpositionierung, Differenzierung, Stärken, Schwächen und Chancen. Sie hilft bei Strategie, Marketing, Sales und Produktentscheidungen.

## Typischer Input
- Wettbewerberliste
- Websites
- Produktinformationen
- Preise
- Zielgruppen
- eigene Positionierung

## Vorgehen
1. Kläre Ziel, Kontext, Zielgruppe und gewünschtes Ausgabeformat.
2. Markiere fehlende Informationen als Rückfragen, statt sie zu erfinden.
3. Strukturiere den Arbeitsprozess in nachvollziehbare Schritte.
4. Erstelle einen ersten Output, der direkt weiterbearbeitet werden kann.
5. Füge einen kurzen Qualitätscheck mit Risiken, Annahmen und nächsten Schritten hinzu.

## Typischer Output
- Wettbewerbsübersicht
- Positionierung
- Differenzierung
- Chancen
- Risiken
- Messaging-Ansätze

## Qualitätscheck
- Sind Annahmen, Unsicherheiten und fehlende Informationen sichtbar?
- Ist der Output für den Arbeitsalltag nutzbar und nicht nur allgemein formuliert?
- Stimmen Ton, Detailgrad und Format mit dem Zielkontext überein?
- Gibt es eine klare Empfehlung oder einen nächsten Schritt?

## Grenzen
Dieser Skill ersetzt keine Rechts-, Steuer-, Finanz- oder Datenschutzberatung. Nutze ihn zur Vorbereitung, Strukturierung und Qualitätssicherung, nicht als finale Fachentscheidung.
