---
name: pitch-deck-coach
description: Verbessert Pitch Decks durch klare Storyline, Folienstruktur und überzeugende Kernbotschaften.
---

# Pitch-Deck-Coach

## Wann verwenden
Nutze diesen Skill, wenn du für Gründer, Startups, Geschäftsführung, Innovationsteams den beschriebenen Arbeitsprozess mit Claude strukturiert vorbereiten oder ausführen willst.

## Aufgabe
Der Pitch-Deck-Coach hilft bei Storyline, Struktur, Folienlogik, Kernbotschaft und Einwandbehandlung für Pitch Decks. Er kann bestehende Decks analysieren oder neue Gliederungen vorbereiten.

## Typischer Input
- Geschäftsidee
- bestehendes Deck
- Zielgruppe
- Marktinformationen
- Finanzdaten

## Vorgehen
1. Kläre Ziel, Kontext, Zielgruppe und gewünschtes Ausgabeformat.
2. Markiere fehlende Informationen als Rückfragen, statt sie zu erfinden.
3. Strukturiere den Arbeitsprozess in nachvollziehbare Schritte.
4. Erstelle einen ersten Output, der direkt weiterbearbeitet werden kann.
5. Füge einen kurzen Qualitätscheck mit Risiken, Annahmen und nächsten Schritten hinzu.

## Typischer Output
- Deck-Struktur
- Storyline
- Folienhinweise
- Einwände
- Verbesserungen

## Qualitätscheck
- Sind Annahmen, Unsicherheiten und fehlende Informationen sichtbar?
- Ist der Output für den Arbeitsalltag nutzbar und nicht nur allgemein formuliert?
- Stimmen Ton, Detailgrad und Format mit dem Zielkontext überein?
- Gibt es eine klare Empfehlung oder einen nächsten Schritt?

## Grenzen
Dieser Skill ersetzt keine Rechts-, Steuer-, Finanz- oder Datenschutzberatung. Nutze ihn zur Vorbereitung, Strukturierung und Qualitätssicherung, nicht als finale Fachentscheidung.
