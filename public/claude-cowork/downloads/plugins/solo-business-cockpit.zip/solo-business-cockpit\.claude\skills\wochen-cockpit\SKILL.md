---
name: wochen-cockpit
description: Erstellt aus Kalender, Aufgaben und Kommunikation eine klare Wochenübersicht mit Prioritäten und offenen Punkten.
---

# Wochen-Cockpit

## Wann verwenden
Nutze diesen Skill, wenn du für Selbstständige, Gründer, Geschäftsführung, Assistenz, Projektmanagement den beschriebenen Arbeitsprozess mit Claude strukturiert vorbereiten oder ausführen willst.

## Aufgabe
Das Wochen-Cockpit erstellt eine strukturierte Übersicht über Aufgaben, Termine, offene Kundenfragen, finanzielle Themen und Prioritäten der Woche. Es hilft dabei, operative Arbeit besser zu überblicken und klare nächste Schritte abzuleiten.

## Typischer Input
- Kalender
- E-Mails
- Aufgabenlisten
- Notizen
- offene Projekte

## Vorgehen
1. Kläre Ziel, Kontext, Zielgruppe und gewünschtes Ausgabeformat.
2. Markiere fehlende Informationen als Rückfragen, statt sie zu erfinden.
3. Strukturiere den Arbeitsprozess in nachvollziehbare Schritte.
4. Erstelle einen ersten Output, der direkt weiterbearbeitet werden kann.
5. Füge einen kurzen Qualitätscheck mit Risiken, Annahmen und nächsten Schritten hinzu.

## Typischer Output
- Wochenübersicht
- Top-Prioritäten
- offene Entscheidungen
- Kunden-To-dos
- Risiken
- empfohlene nächste Schritte

## Qualitätscheck
- Sind Annahmen, Unsicherheiten und fehlende Informationen sichtbar?
- Ist der Output für den Arbeitsalltag nutzbar und nicht nur allgemein formuliert?
- Stimmen Ton, Detailgrad und Format mit dem Zielkontext überein?
- Gibt es eine klare Empfehlung oder einen nächsten Schritt?

## Grenzen
Dieser Skill ersetzt keine Rechts-, Steuer-, Finanz- oder Datenschutzberatung. Nutze ihn zur Vorbereitung, Strukturierung und Qualitätssicherung, nicht als finale Fachentscheidung.
