# Rechnungs-Reminder / Invoice-Chaser

## Wann verwenden
Nutze diesen Skill, wenn du für Selbstständige, Office Management, Finance, Agenturen, kleine Unternehmen den beschriebenen Arbeitsprozess mit Claude strukturiert vorbereiten oder ausführen willst.

## Aufgabe
Der Rechnungs-Reminder erkennt offene Rechnungen, priorisiert sie nach Alter, Betrag und Relevanz und erstellt passende Nachfassmails. Der Ton kann freundlich, neutral, bestimmt oder formell gewählt werden.

## Typischer Input
- Rechnungsliste
- Kundendaten
- Zahlungsstatus
- bisherige Kommunikation

## Vorgehen
1. Kläre Ziel, Kontext, Zielgruppe und gewünschtes Ausgabeformat.
2. Markiere fehlende Informationen als Rückfragen, statt sie zu erfinden.
3. Strukturiere den Arbeitsprozess in nachvollziehbare Schritte.
4. Erstelle einen ersten Output, der direkt weiterbearbeitet werden kann.
5. Füge einen kurzen Qualitätscheck mit Risiken, Annahmen und nächsten Schritten hinzu.

## Typischer Output
- Liste offener Rechnungen
- Priorisierung
- Zahlungsstatus-Zusammenfassung
- Nachfassmail
- Eskalationsvorschlag

## Qualitätscheck
- Sind Annahmen, Unsicherheiten und fehlende Informationen sichtbar?
- Ist der Output für den Arbeitsalltag nutzbar und nicht nur allgemein formuliert?
- Stimmen Ton, Detailgrad und Format mit dem Zielkontext überein?
- Gibt es eine klare Empfehlung oder einen nächsten Schritt?

## Grenzen
Dieser Skill ersetzt keine Rechts-, Steuer-, Finanz- oder Datenschutzberatung. Nutze ihn zur Vorbereitung, Strukturierung und Qualitätssicherung, nicht als finale Fachentscheidung.
