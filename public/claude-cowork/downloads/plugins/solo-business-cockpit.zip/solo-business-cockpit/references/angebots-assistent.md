# Angebots-Assistent

## Wann verwenden
Nutze diesen Skill, wenn du für Freelancer, Agenturen, Berater, Handwerker, Dienstleister, kleine Unternehmen den beschriebenen Arbeitsprozess mit Claude strukturiert vorbereiten oder ausführen willst.

## Aufgabe
Der Angebots-Assistent erstellt aus Kundenanfragen, Stichpunkten oder Projektbriefings strukturierte Angebotsentwürfe. Er hilft dabei, Leistungen klar zu beschreiben, optionale Pakete zu formulieren, offene Rückfragen zu erkennen und eine passende Begleitmail vorzubereiten.

## Typischer Input
- Kundenmail
- Projektbeschreibung
- Leistungsübersicht
- Preisrahmen
- alte Angebotsvorlage

## Vorgehen
1. Kläre Ziel, Kontext, Zielgruppe und gewünschtes Ausgabeformat.
2. Markiere fehlende Informationen als Rückfragen, statt sie zu erfinden.
3. Strukturiere den Arbeitsprozess in nachvollziehbare Schritte.
4. Erstelle einen ersten Output, der direkt weiterbearbeitet werden kann.
5. Füge einen kurzen Qualitätscheck mit Risiken, Annahmen und nächsten Schritten hinzu.

## Typischer Output
- Angebotsstruktur
- Leistungsbeschreibung
- optionale Pakete
- offene Rückfragen
- Begleitmail an den Kunden

## Qualitätscheck
- Sind Annahmen, Unsicherheiten und fehlende Informationen sichtbar?
- Ist der Output für den Arbeitsalltag nutzbar und nicht nur allgemein formuliert?
- Stimmen Ton, Detailgrad und Format mit dem Zielkontext überein?
- Gibt es eine klare Empfehlung oder einen nächsten Schritt?

## Grenzen
Dieser Skill ersetzt keine Rechts-, Steuer-, Finanz- oder Datenschutzberatung. Nutze ihn zur Vorbereitung, Strukturierung und Qualitätssicherung, nicht als finale Fachentscheidung.
