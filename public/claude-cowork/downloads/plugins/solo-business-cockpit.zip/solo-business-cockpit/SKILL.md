---
name: solo-business-cockpit
description: 'Ein kompaktes Arbeitscockpit für Solo-Unternehmer, die zwischen Akquise, Projektarbeit, Kundenkommunikation und Admin wechseln.'
---

# Solo Business Cockpit

## Wann verwenden
Nutze diesen Skill, wenn du einen kompletten Arbeitsbereich statt einzelner Skills aktivieren willst. Das Paket bündelt mehrere Claude-Workflows für typische Aufgaben und verweist auf fokussierte Referenzdateien.

## Arbeitsweise
1. Kläre zuerst, welche Aufgabe, Eingabe und gewünschter Output vorliegen.
2. Wähle aus den enthaltenen Skills die passendste Referenzdatei aus eferences/.
3. Lies nur die Referenz, die zur Aufgabe passt, und folge deren Vorgehen.
4. Wenn mehrere Aufgaben kombiniert sind, arbeite sie nacheinander ab und trenne die Ergebnisse sauber.
5. Frage nach, wenn Pflichtinformationen wie Zielgruppe, Format, Zeitraum, Kennzahlen oder Tonalität fehlen.

## Enthaltene Skills
- Angebots-Assistent: Erstellt aus chaotischen Kundenanfragen klare Angebotsentwürfe mit Leistungsumfang, Rückfragen und passender Kundenmail.
- Rechnungs-Reminder / Invoice-Chaser: Hilft dabei, offene Rechnungen zu erkennen, zu priorisieren und professionelle Zahlungserinnerungen vorzubereiten.
- Kundenbriefing-Reader: Macht aus unübersichtlicher Kundenkommunikation ein klares Projektbriefing mit Anforderungen, offenen Fragen und nächsten Schritten.
- Wochen-Cockpit: Erstellt aus Kalender, Aufgaben und Kommunikation eine klare Wochenübersicht mit Prioritäten und offenen Punkten.
- Content-aus-Auftrag: Macht aus abgeschlossenen Kundenprojekten verwertbaren Content für LinkedIn, Newsletter, Website und Case Studies.
- Scope-Creep-Wächter: Erkennt zusätzliche Kundenwünsche außerhalb des vereinbarten Umfangs und hilft bei professioneller Kommunikation.

## Referenzen
- eferences/angebots-assistent.md: nutze diese Referenz, wenn die Aufgabe zu diesem Skill passt.
- eferences/rechnungs-reminder.md: nutze diese Referenz, wenn die Aufgabe zu diesem Skill passt.
- eferences/kundenbriefing-reader.md: nutze diese Referenz, wenn die Aufgabe zu diesem Skill passt.
- eferences/wochen-cockpit.md: nutze diese Referenz, wenn die Aufgabe zu diesem Skill passt.
- eferences/content-aus-auftrag.md: nutze diese Referenz, wenn die Aufgabe zu diesem Skill passt.
- eferences/scope-creep-waechter.md: nutze diese Referenz, wenn die Aufgabe zu diesem Skill passt.