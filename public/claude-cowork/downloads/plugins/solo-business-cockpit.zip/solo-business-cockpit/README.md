# Solo Business Cockpit

Dieses Plugin bündelt mehrere Claude Cowork Skills für einen zusammenhängenden Arbeitsbereich.

## Enthaltene Skills
- /solo-business-cockpit:angebots-assistent - Angebots-Assistent
- /solo-business-cockpit:rechnungs-reminder - Rechnungs-Reminder / Invoice-Chaser
- /solo-business-cockpit:kundenbriefing-reader - Kundenbriefing-Reader
- /solo-business-cockpit:wochen-cockpit - Wochen-Cockpit
- /solo-business-cockpit:content-aus-auftrag - Content-aus-Auftrag
- /solo-business-cockpit:scope-creep-waechter - Scope-Creep-Wächter

## Format
Dieses ZIP folgt dem Claude Code / Cowork Plugin-Format:

- `.claude-plugin/plugin.json` beschreibt das Plugin.
- `skills/<skill-name>/SKILL.md` enthält die einzelnen Skills.
- Die Skill-Namen werden im Plugin namespaced, z. B. `/solo-business-cockpit:angebots-assistent`.

Für Claude.ai Custom Skill Uploads nutze die einzelnen Skill-ZIPs aus der Skill Library. Dieses Paket ist bewusst ein Plugin-Bundle.
