# Solo Business Cockpit

Ein kompaktes Arbeitscockpit fuer Solo-Unternehmer, die zwischen Akquise, Projektarbeit, Kundenkommunikation und Admin wechseln.

## Enthaltene Skills
- Angebots-Assistent
- Rechnungs-Reminder / Invoice-Chaser
- Kundenbriefing-Reader
- Wochen-Cockpit
- Content-aus-Auftrag
- Scope-Creep-Wächter

## Installation
Kopiere die Ordner aus `.claude/skills/` in dein Claude-Code-Projekt oder in deinen persoenlichen Skills-Ordner.
