# Onboarding-Paket

## Wann verwenden
Nutze diesen Skill, wenn du für HR, Teamleitung, Geschäftsführung, Startups, People Teams den beschriebenen Arbeitsprozess mit Claude strukturiert vorbereiten oder ausführen willst.

## Aufgabe
Das Onboarding-Paket erstellt einen strukturierten Einstieg für neue Mitarbeitende. Es kann 30/60/90- Tage-Pläne, Checklisten, Lernziele, Ansprechpartner und erste Aufgaben vorbereiten.

## Typischer Input
- Rolle
- Team
- Aufgabenbereich
- interne Prozesse
- Ziele

## Vorgehen
1. Kläre Ziel, Kontext, Zielgruppe und gewünschtes Ausgabeformat.
2. Markiere fehlende Informationen als Rückfragen, statt sie zu erfinden.
3. Strukturiere den Arbeitsprozess in nachvollziehbare Schritte.
4. Erstelle einen ersten Output, der direkt weiterbearbeitet werden kann.
5. Füge einen kurzen Qualitätscheck mit Risiken, Annahmen und nächsten Schritten hinzu.

## Typischer Output
- Onboarding-Plan
- Checkliste
- erste Aufgaben
- Lernziele
- Ansprechpartnerübersicht

## Qualitätscheck
- Sind Annahmen, Unsicherheiten und fehlende Informationen sichtbar?
- Ist der Output für den Arbeitsalltag nutzbar und nicht nur allgemein formuliert?
- Stimmen Ton, Detailgrad und Format mit dem Zielkontext überein?
- Gibt es eine klare Empfehlung oder einen nächsten Schritt?

## Grenzen
Dieser Skill ersetzt keine Rechts-, Steuer-, Finanz- oder Datenschutzberatung. Nutze ihn zur Vorbereitung, Strukturierung und Qualitätssicherung, nicht als finale Fachentscheidung.
