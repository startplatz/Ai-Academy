---
description: 'Erstellt strukturierte Interviewfragen und Bewertungsraster für Bewerbungsgespräche.'
---

# Interviewleitfaden

## Einsatzmoment
Der Skill ist für Situationen gedacht, in denen Teilnehmende zwischen Fachbereichsdruck, Fairnessanspruch und dem Wunsch, gute Menschen nicht zu übersehen sind. Das Ziel ist nicht, schnell generischen Text zu produzieren, sondern Druck aus der Aufgabe zu nehmen und eine belastbare Arbeitsgrundlage zu schaffen.

Typische Spannung: Das Gespräch soll menschlich sein, aber vergleichbare Ergebnisse liefern.

## Zielbild
Am Ende liegt ein Ergebnis vor, das eine Person direkt prüfen, senden, entscheiden oder weiterbearbeiten kann. Claude soll nicht so tun, als sei alles sicher. Claude soll Annahmen, Lücken, Risiken und Rückfragen sichtbar machen.

Erwartete Outputs:
- Interviewstruktur
- Fragenkatalog
- Bewertungsraster
- Notizvorlage
- Red Flags

## Typischer Input
- Stellenprofil
- Bewerbungsunterlagen
- gewünschte Kompetenzen
- Interviewdauer

## Praxisprinzipien
- Rolle, Erfolgskriterien und Muss-Anforderungen vor Textproduktion klären
- strukturierte Fragen und Bewertungsanker nutzen statt Bauchgefühl
- Formulierungen auf Fairness, Verständlichkeit und Kandidatenerlebnis prüfen

## Expert Moves für diesen Skill
- Kompetenzen aus Jobanalyse ableiten
- strukturierte Fragen mit Bewertungsankern erstellen
- Follow-ups für Beleg statt Bauchgefühl formulieren

## Vorgehen
1. Lies den Input einmal nur auf Ziel, Kontext und gewünschtes Ergebnis.
2. Markiere fehlende Informationen. Wenn sie entscheidungsrelevant sind, frage nach, statt etwas zu erfinden.
3. Trenne Fakten, Annahmen, Interpretation und Empfehlung sichtbar.
4. Erstelle zuerst eine knappe Arbeitsstruktur, dann den eigentlichen Entwurf.
5. Prüfe das Ergebnis gegen die Qualitätskriterien unten.
6. Liefere bei Unsicherheit zwei Optionen: eine vorsichtige Version und eine mutigere Version mit klarer Begründung.

## Qualitätskriterien
- alle Kriterien sind jobbezogen
- Bias-Risiken werden markiert
- nächster Schritt und Kommunikationsstatus sind klar

## Worauf du achten musst
- hypothetische Fragen ohne Beweiswert
- unterschiedliche Fragen je Kandidat
- keine Notizstruktur

## Rückfragen, wenn Informationen fehlen
- Was soll mit dem Ergebnis direkt passieren: senden, entscheiden, intern vorbereiten oder prüfen?
- Wer ist die Zielperson und wie viel Vorwissen hat sie?
- Welche Frist, welches Risiko oder welche geschäftliche Konsequenz hängt daran?
- Gibt es Formulierungen, Zahlen, Namen oder Zusagen, die unverändert bleiben müssen?

## Output-Format
Gib das Ergebnis in dieser Reihenfolge aus:
1. Kurzdiagnose der Ausgangslage
2. Fertiger Entwurf oder strukturierte Arbeitsvorlage
3. Annahmen und offene Punkte
4. Risiken oder rote Flaggen
5. Konkreter nächster Schritt
