# HR Hiring Pack

Dieses Plugin bündelt mehrere Claude Cowork Skills für einen zusammenhängenden Arbeitsbereich.

## Enthaltene Skills
- /hr-hiring-pack:stellenanzeigen-builder - Stellenanzeigen-Builder
- /hr-hiring-pack:cv-screener - CV-Screener
- /hr-hiring-pack:interviewleitfaden - Interviewleitfaden
- /hr-hiring-pack:onboarding-paket - Onboarding-Paket
- /hr-hiring-pack:mitarbeitergespraech-vorbereitung - Mitarbeitergespräch-Vorbereitung
- /hr-hiring-pack:schulungsplan-designer - Schulungsplan-Designer

## Format
Dieses ZIP folgt dem Claude Code / Cowork Plugin-Format:

- `.claude-plugin/plugin.json` beschreibt das Plugin.
- `skills/<skill-name>/SKILL.md` enthält die einzelnen Skills.
- Die Skill-Namen werden im Plugin namespaced, z. B. `/hr-hiring-pack:stellenanzeigen-builder`.

Für Claude.ai Custom Skill Uploads nutze die einzelnen Skill-ZIPs aus der Skill Library. Dieses Paket ist bewusst ein Plugin-Bundle.
