---
name: hr-hiring-pack
description: 'Ein Paket für Recruiting, Bewerbungsprozesse, Interviews, Onboarding und Personalentwicklung.'
---

# HR Hiring Pack

## Wann verwenden
Nutze diesen Skill, wenn du einen kompletten Arbeitsbereich statt einzelner Skills aktivieren willst. Das Paket bündelt mehrere Claude-Workflows für typische Aufgaben und verweist auf fokussierte Referenzdateien.

## Arbeitsweise
1. Kläre zuerst, welche Aufgabe, Eingabe und gewünschter Output vorliegen.
2. Wähle aus den enthaltenen Skills die passendste Referenzdatei aus eferences/.
3. Lies nur die Referenz, die zur Aufgabe passt, und folge deren Vorgehen.
4. Wenn mehrere Aufgaben kombiniert sind, arbeite sie nacheinander ab und trenne die Ergebnisse sauber.
5. Frage nach, wenn Pflichtinformationen wie Zielgruppe, Format, Zeitraum, Kennzahlen oder Tonalität fehlen.

## Enthaltene Skills
- Stellenanzeigen-Builder: Erstellt klare und ansprechende Stellenanzeigen aus Rollenanforderungen und Unternehmensinformationen.
- CV-Screener: Fasst Bewerbungen strukturiert zusammen und gleicht sie mit definierten Kriterien ab.
- Interviewleitfaden: Erstellt strukturierte Interviewfragen und Bewertungsraster für Bewerbungsgespräche.
- Onboarding-Paket: Erstellt Onboarding-Pläne, Checklisten und erste Aufgaben für neue Mitarbeitende.
- Mitarbeitergespräch-Vorbereitung: Strukturiert Feedback, Ziele und Gesprächsfragen für Mitarbeitergespräche.
- Schulungsplan-Designer: Erstellt strukturierte Lernpfade und Schulungspläne für Teams und Mitarbeitende.

## Referenzen
- eferences/stellenanzeigen-builder.md: nutze diese Referenz, wenn die Aufgabe zu diesem Skill passt.
- eferences/cv-screener.md: nutze diese Referenz, wenn die Aufgabe zu diesem Skill passt.
- eferences/interviewleitfaden.md: nutze diese Referenz, wenn die Aufgabe zu diesem Skill passt.
- eferences/onboarding-paket.md: nutze diese Referenz, wenn die Aufgabe zu diesem Skill passt.
- eferences/mitarbeitergespraech-vorbereitung.md: nutze diese Referenz, wenn die Aufgabe zu diesem Skill passt.
- eferences/schulungsplan-designer.md: nutze diese Referenz, wenn die Aufgabe zu diesem Skill passt.