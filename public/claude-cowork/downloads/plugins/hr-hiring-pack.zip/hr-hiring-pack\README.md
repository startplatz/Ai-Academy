# HR Hiring Pack

Ein Paket fuer Recruiting, Bewerbungsprozesse, Interviews, Onboarding und Personalentwicklung.

## Enthaltene Skills
- Stellenanzeigen-Builder
- CV-Screener
- Interviewleitfaden
- Onboarding-Paket
- Mitarbeitergespräch-Vorbereitung
- Schulungsplan-Designer

## Installation
Kopiere die Ordner aus `.claude/skills/` in dein Claude-Code-Projekt oder in deinen persoenlichen Skills-Ordner.
