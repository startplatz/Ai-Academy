# Sales Pipeline Assistant

Ein Vertriebsassistent fuer mehr Struktur in Lead-Management, Kundenkommunikation und Pipeline-Arbeit.

## Enthaltene Skills
- Lead-Triage
- Sales-Call-Prep
- Follow-up-Schreiber
- CRM-Hygiene-Agent
- Lost-Deal-Analyse
- Customer-Pulse

## Installation
Kopiere die Ordner aus `.claude/skills/` in dein Claude-Code-Projekt oder in deinen persoenlichen Skills-Ordner.
