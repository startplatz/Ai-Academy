# Sales Pipeline Assistant

Dieses Plugin bündelt mehrere Claude Cowork Skills für einen zusammenhängenden Arbeitsbereich.

## Enthaltene Skills
- /sales-pipeline-assistant:lead-triage - Lead-Triage
- /sales-pipeline-assistant:sales-call-prep - Sales-Call-Prep
- /sales-pipeline-assistant:follow-up-schreiber - Follow-up-Schreiber
- /sales-pipeline-assistant:crm-hygiene-agent - CRM-Hygiene-Agent
- /sales-pipeline-assistant:lost-deal-analyse - Lost-Deal-Analyse
- /sales-pipeline-assistant:customer-pulse - Customer-Pulse

## Format
Dieses ZIP folgt dem Claude Code / Cowork Plugin-Format:

- `.claude-plugin/plugin.json` beschreibt das Plugin.
- `skills/<skill-name>/SKILL.md` enthält die einzelnen Skills.
- Die Skill-Namen werden im Plugin namespaced, z. B. `/sales-pipeline-assistant:lead-triage`.

Für Claude.ai Custom Skill Uploads nutze die einzelnen Skill-ZIPs aus der Skill Library. Dieses Paket ist bewusst ein Plugin-Bundle.
