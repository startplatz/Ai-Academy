---
name: sales-pipeline-assistant
description: 'Ein Vertriebsassistent für mehr Struktur in Lead-Management, Kundenkommunikation und Pipeline-Arbeit.'
---

# Sales Pipeline Assistant

## Wann verwenden
Nutze diesen Skill, wenn du einen kompletten Arbeitsbereich statt einzelner Skills aktivieren willst. Das Paket bündelt mehrere Claude-Workflows für typische Aufgaben und verweist auf fokussierte Referenzdateien.

## Arbeitsweise
1. Kläre zuerst, welche Aufgabe, Eingabe und gewünschter Output vorliegen.
2. Wähle aus den enthaltenen Skills die passendste Referenzdatei aus eferences/.
3. Lies nur die Referenz, die zur Aufgabe passt, und folge deren Vorgehen.
4. Wenn mehrere Aufgaben kombiniert sind, arbeite sie nacheinander ab und trenne die Ergebnisse sauber.
5. Frage nach, wenn Pflichtinformationen wie Zielgruppe, Format, Zeitraum, Kennzahlen oder Tonalität fehlen.

## Enthaltene Skills
- Lead-Triage: Priorisiert Leads nach Potenzial, Fit und Dringlichkeit und schlägt nächste Schritte vor.
- Sales-Call-Prep: Bereitet Sales- und Kundengespräche mit Kontext, Fragen und Gesprächszielen vor.
- Follow-up-Schreiber: Schreibt professionelle Follow-up-Mails nach Kundengesprächen, Angeboten oder Demos.
- CRM-Hygiene-Agent: Prüft CRM-Daten auf Lücken, Dubletten, veraltete Deals und unklare nächste Schritte.
- Lost-Deal-Analyse: Analysiert verlorene Deals und erkennt Muster, Absagegründe und Verbesserungspotenziale.
- Customer-Pulse: Erkennt Kundenstimmung aus Kommunikation und macht Risiken, Chancen und offene Themen sichtbar.

## Referenzen
- eferences/lead-triage.md: nutze diese Referenz, wenn die Aufgabe zu diesem Skill passt.
- eferences/sales-call-prep.md: nutze diese Referenz, wenn die Aufgabe zu diesem Skill passt.
- eferences/follow-up-schreiber.md: nutze diese Referenz, wenn die Aufgabe zu diesem Skill passt.
- eferences/crm-hygiene-agent.md: nutze diese Referenz, wenn die Aufgabe zu diesem Skill passt.
- eferences/lost-deal-analyse.md: nutze diese Referenz, wenn die Aufgabe zu diesem Skill passt.
- eferences/customer-pulse.md: nutze diese Referenz, wenn die Aufgabe zu diesem Skill passt.