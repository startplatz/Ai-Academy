# Customer Service Desk

Dieses Plugin bündelt mehrere Claude Cowork Skills für einen zusammenhängenden Arbeitsbereich.

## Enthaltene Skills
- /customer-service-desk:ticket-triage - Ticket-Triage
- /customer-service-desk:antwortvorlagen-generator - Antwortvorlagen-Generator
- /customer-service-desk:customer-pulse - Customer-Pulse
- /customer-service-desk:eskalations-erkennung - Eskalations-Erkennung
- /customer-service-desk:faq-builder - FAQ-Builder
- /customer-service-desk:beschwerde-antworter - Beschwerde-Antworter

## Format
Dieses ZIP folgt dem Claude Code / Cowork Plugin-Format:

- `.claude-plugin/plugin.json` beschreibt das Plugin.
- `skills/<skill-name>/SKILL.md` enthält die einzelnen Skills.
- Die Skill-Namen werden im Plugin namespaced, z. B. `/customer-service-desk:ticket-triage`.

Für Claude.ai Custom Skill Uploads nutze die einzelnen Skill-ZIPs aus der Skill Library. Dieses Paket ist bewusst ein Plugin-Bundle.
