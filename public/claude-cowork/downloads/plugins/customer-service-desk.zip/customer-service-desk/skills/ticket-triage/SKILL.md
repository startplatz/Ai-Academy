---
description: 'Sortiert Support- und Serviceanfragen nach Thema, Dringlichkeit, Kundenwirkung und nächstem sinnvollen Schritt.'
---

# Ticket-Triage

## Einsatzmoment
Der Skill ist für Situationen gedacht, in denen Teilnehmende unter Reaktionsdruck, mit emotionalen Kunden und dem Risiko, Kontext zu verlieren sind. Das Ziel ist nicht, schnell generischen Text zu produzieren, sondern Druck aus der Aufgabe zu nehmen und eine belastbare Arbeitsgrundlage zu schaffen.

Typische Spannung: Support muss schnell sortieren, ohne wichtige Signale zu verlieren.

## Zielbild
Am Ende liegt ein Ergebnis vor, das eine Person direkt prüfen, senden, entscheiden oder weiterbearbeiten kann. Claude soll nicht so tun, als sei alles sicher. Claude soll Annahmen, Lücken, Risiken und Rückfragen sichtbar machen.

Erwartete Outputs:
- Priorisierte Ticketliste
- Cluster
- Antwortbedarf

## Typischer Input
- Ticketexport
- Kundenanfragen
- SLA-Hinweise

## Praxisprinzipien
- erst Anliegen, Emotion, Historie und gewünschte Lösung trennen
- Antworten sollen deeskalieren, aber nicht Verantwortung erfinden
- FAQ- und Vorlagenarbeit aus echten Tickets ableiten, nicht aus Wunschdenken

## Expert Moves für diesen Skill
- Anliegen, Dringlichkeit, Emotion und Kundentyp erfassen
- Routing und erste Antwort vorschlagen
- fehlende Informationen abfragen

## Vorgehen
1. Lies den Input einmal nur auf Ziel, Kontext und gewünschtes Ergebnis.
2. Markiere fehlende Informationen. Wenn sie entscheidungsrelevant sind, frage nach, statt etwas zu erfinden.
3. Trenne Fakten, Annahmen, Interpretation und Empfehlung sichtbar.
4. Erstelle zuerst eine knappe Arbeitsstruktur, dann den eigentlichen Entwurf.
5. Prüfe das Ergebnis gegen die Qualitätskriterien unten.
6. Liefere bei Unsicherheit zwei Optionen: eine vorsichtige Version und eine mutigere Version mit klarer Begründung.

## Qualitätskriterien
- Antwort enthält Anerkennung, Sachstand, Lösungspfad und nächste Erwartung
- Eskalationen sind begründet
- keine internen Details oder ungesicherten Zusagen

## Worauf du achten musst
- alles dringend nennen
- VIP ohne Impact
- keine SLA-Logik

## Rückfragen, wenn Informationen fehlen
- Was soll mit dem Ergebnis direkt passieren: senden, entscheiden, intern vorbereiten oder prüfen?
- Wer ist die Zielperson und wie viel Vorwissen hat sie?
- Welche Frist, welches Risiko oder welche geschäftliche Konsequenz hängt daran?
- Gibt es Formulierungen, Zahlen, Namen oder Zusagen, die unverändert bleiben müssen?

## Output-Format
Gib das Ergebnis in dieser Reihenfolge aus:
1. Kurzdiagnose der Ausgangslage
2. Fertiger Entwurf oder strukturierte Arbeitsvorlage
3. Annahmen und offene Punkte
4. Risiken oder rote Flaggen
5. Konkreter nächster Schritt
