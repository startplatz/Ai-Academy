---
name: customer-service-desk
description: 'Ein Support-Arbeitsplatz für schnellere, konsistentere und besser strukturierte Kundenkommunikation.'
---

# Customer Service Desk

## Wann verwenden
Nutze diesen Skill, wenn du einen kompletten Arbeitsbereich statt einzelner Skills aktivieren willst. Das Paket bündelt mehrere Claude-Workflows für typische Aufgaben und verweist auf fokussierte Referenzdateien.

## Arbeitsweise
1. Kläre zuerst, welche Aufgabe, Eingabe und gewünschter Output vorliegen.
2. Wähle aus den enthaltenen Skills die passendste Referenzdatei aus eferences/.
3. Lies nur die Referenz, die zur Aufgabe passt, und folge deren Vorgehen.
4. Wenn mehrere Aufgaben kombiniert sind, arbeite sie nacheinander ab und trenne die Ergebnisse sauber.
5. Frage nach, wenn Pflichtinformationen wie Zielgruppe, Format, Zeitraum, Kennzahlen oder Tonalität fehlen.

## Enthaltene Skills
- Ticket-Triage: Sortiert Support- und Serviceanfragen nach Thema, Dringlichkeit, Kundenwirkung und nächstem sinnvollen Schritt.
- Antwortvorlagen-Generator: Erstellt konsistente Antwortbausteine für wiederkehrende Kundenfragen, Servicefaelle und interne Freigaben.
- Customer-Pulse: Erkennt Kundenstimmung aus Kommunikation und macht Risiken, Chancen und offene Themen sichtbar.
- Eskalations-Erkennung: Erkennt kritische Kundenfaelle, Tonalität, Risikoindikatoren und Situationen, die eine schnelle Eskalation benoetigen.
- FAQ-Builder: Verdichtet häufige Fragen aus Supportmaterial in klare FAQ-Antworten mit Struktur und konsistenter Sprache.
- Beschwerde-Antworter: Formuliert sachliche, freundliche und lösungsorientierte Antworten auf Beschwerden und schwierige Kundenkommunikation.

## Referenzen
- eferences/ticket-triage.md: nutze diese Referenz, wenn die Aufgabe zu diesem Skill passt.
- eferences/antwortvorlagen-generator.md: nutze diese Referenz, wenn die Aufgabe zu diesem Skill passt.
- eferences/customer-pulse.md: nutze diese Referenz, wenn die Aufgabe zu diesem Skill passt.
- eferences/eskalations-erkennung.md: nutze diese Referenz, wenn die Aufgabe zu diesem Skill passt.
- eferences/faq-builder.md: nutze diese Referenz, wenn die Aufgabe zu diesem Skill passt.
- eferences/beschwerde-antworter.md: nutze diese Referenz, wenn die Aufgabe zu diesem Skill passt.