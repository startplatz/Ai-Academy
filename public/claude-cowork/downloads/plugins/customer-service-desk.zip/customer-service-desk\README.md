# Customer Service Desk

Ein Support-Arbeitsplatz fuer schnellere, konsistentere und besser strukturierte Kundenkommunikation.

## Enthaltene Skills
- Ticket-Triage
- Antwortvorlagen-Generator
- Customer-Pulse
- Eskalations-Erkennung
- FAQ-Builder
- Beschwerde-Antworter

## Installation
Kopiere die Ordner aus `.claude/skills/` in dein Claude-Code-Projekt oder in deinen persoenlichen Skills-Ordner.
