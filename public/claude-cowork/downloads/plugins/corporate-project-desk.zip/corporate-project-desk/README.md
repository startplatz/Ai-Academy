# Corporate Project Desk

Dieses Plugin bündelt mehrere Claude Cowork Skills für einen zusammenhängenden Arbeitsbereich.

## Enthaltene Skills
- /corporate-project-desk:stakeholder-briefing - Stakeholder-Briefing
- /corporate-project-desk:projektstatus-generator - Projektstatus-Generator
- /corporate-project-desk:decision-log - Decision-Log
- /corporate-project-desk:workshop-designer - Workshop-Designer
- /corporate-project-desk:management-summary - Management-Summary
- /corporate-project-desk:risikoregister - Risikoregister

## Format
Dieses ZIP folgt dem Claude Code / Cowork Plugin-Format:

- `.claude-plugin/plugin.json` beschreibt das Plugin.
- `skills/<skill-name>/SKILL.md` enthält die einzelnen Skills.
- Die Skill-Namen werden im Plugin namespaced, z. B. `/corporate-project-desk:stakeholder-briefing`.

Für Claude.ai Custom Skill Uploads nutze die einzelnen Skill-ZIPs aus der Skill Library. Dieses Paket ist bewusst ein Plugin-Bundle.
