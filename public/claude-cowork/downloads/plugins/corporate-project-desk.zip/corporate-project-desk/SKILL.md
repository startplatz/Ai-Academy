---
name: corporate-project-desk
description: 'Ein Projektarbeitsplatz für komplexe Abstimmungen, Statusberichte, Management-Informationen und strukturierte Entscheidungen.'
---

# Corporate Project Desk

## Wann verwenden
Nutze diesen Skill, wenn du einen kompletten Arbeitsbereich statt einzelner Skills aktivieren willst. Das Paket bündelt mehrere Claude-Workflows für typische Aufgaben und verweist auf fokussierte Referenzdateien.

## Arbeitsweise
1. Kläre zuerst, welche Aufgabe, Eingabe und gewünschter Output vorliegen.
2. Wähle aus den enthaltenen Skills die passendste Referenzdatei aus eferences/.
3. Lies nur die Referenz, die zur Aufgabe passt, und folge deren Vorgehen.
4. Wenn mehrere Aufgaben kombiniert sind, arbeite sie nacheinander ab und trenne die Ergebnisse sauber.
5. Frage nach, wenn Pflichtinformationen wie Zielgruppe, Format, Zeitraum, Kennzahlen oder Tonalität fehlen.

## Enthaltene Skills
- Stakeholder-Briefing: Bereitet Stakeholder-Informationen mit Interessen, Risiken und Kommunikationshinweisen auf.
- Projektstatus-Generator: Erstellt Projektstatusberichte mit Fortschritt, Risiken, Blockern und nächsten Schritten.
- Decision-Log: Dokumentiert Entscheidungen mit Begründung, Verantwortlichen, Auswirkungen und offenen Folgepunkten.
- Workshop-Designer: Erstellt Workshop-Konzepte mit Agenda, Übungen, Moderationsleitfaden und Ergebnisstruktur.
- Management-Summary: Verdichtet lange Unterlagen zu klaren Management-Zusammenfassungen mit Kernaussagen und Entscheidungen.
- Risikoregister: Erstellt ein Risikoregister mit Priorisierung, Auswirkungen und möglichen Gegenmaßnahmen.

## Referenzen
- eferences/stakeholder-briefing.md: nutze diese Referenz, wenn die Aufgabe zu diesem Skill passt.
- eferences/projektstatus-generator.md: nutze diese Referenz, wenn die Aufgabe zu diesem Skill passt.
- eferences/decision-log.md: nutze diese Referenz, wenn die Aufgabe zu diesem Skill passt.
- eferences/workshop-designer.md: nutze diese Referenz, wenn die Aufgabe zu diesem Skill passt.
- eferences/management-summary.md: nutze diese Referenz, wenn die Aufgabe zu diesem Skill passt.
- eferences/risikoregister.md: nutze diese Referenz, wenn die Aufgabe zu diesem Skill passt.