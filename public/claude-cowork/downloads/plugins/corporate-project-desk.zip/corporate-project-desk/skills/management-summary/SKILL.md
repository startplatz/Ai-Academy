---
description: 'Verdichtet lange Unterlagen zu klaren Management-Zusammenfassungen mit Kernaussagen und Entscheidungen.'
---

# Management-Summary

## Einsatzmoment
Der Skill ist für Situationen gedacht, in denen Teilnehmende politisch sensibel, stakeholderreich und mit hohem Bedarf an klarer, defensibler Kommunikation sind. Das Ziel ist nicht, schnell generischen Text zu produzieren, sondern Druck aus der Aufgabe zu nehmen und eine belastbare Arbeitsgrundlage zu schaffen.

Typische Spannung: Führung braucht die Essenz, nicht die ganze Analyse.

## Zielbild
Am Ende liegt ein Ergebnis vor, das eine Person direkt prüfen, senden, entscheiden oder weiterbearbeiten kann. Claude soll nicht so tun, als sei alles sicher. Claude soll Annahmen, Lücken, Risiken und Rückfragen sichtbar machen.

Erwartete Outputs:
- Executive Summary
- Kernaussagen
- Risiken
- Entscheidungen
- nächste Schritte

## Typischer Input
- Bericht
- Präsentation
- Analyse
- Projektmaterial
- lange Dokumente

## Praxisprinzipien
- Status, Risiko, Entscheidung und Eskalation sauber trennen
- Stakeholder nicht nur informieren, sondern nach Einfluss, Interesse und benötigter Entscheidung behandeln
- jede Management-Kommunikation muss in zwei Minuten verständlich sein

## Expert Moves für diesen Skill
- Kernaussage, Beleg, Risiko und Empfehlung verdichten
- Details in Anhanglogik auslagern
- Entscheidungsfrage explizit machen

## Vorgehen
1. Lies den Input einmal nur auf Ziel, Kontext und gewünschtes Ergebnis.
2. Markiere fehlende Informationen. Wenn sie entscheidungsrelevant sind, frage nach, statt etwas zu erfinden.
3. Trenne Fakten, Annahmen, Interpretation und Empfehlung sichtbar.
4. Erstelle zuerst eine knappe Arbeitsstruktur, dann den eigentlichen Entwurf.
5. Prüfe das Ergebnis gegen die Qualitätskriterien unten.
6. Liefere bei Unsicherheit zwei Optionen: eine vorsichtige Version und eine mutigere Version mit klarer Begründung.

## Qualitätskriterien
- Ampeln haben Begründung und Maßnahme
- Risiken besitzen Owner, Wahrscheinlichkeit und Auswirkung
- keine beschönigenden Formulierungen ohne Fakten

## Worauf du achten musst
- lange Einleitung
- keine Handlungsempfehlung
- Zahlen ohne Kontext

## Rückfragen, wenn Informationen fehlen
- Was soll mit dem Ergebnis direkt passieren: senden, entscheiden, intern vorbereiten oder prüfen?
- Wer ist die Zielperson und wie viel Vorwissen hat sie?
- Welche Frist, welches Risiko oder welche geschäftliche Konsequenz hängt daran?
- Gibt es Formulierungen, Zahlen, Namen oder Zusagen, die unverändert bleiben müssen?

## Output-Format
Gib das Ergebnis in dieser Reihenfolge aus:
1. Kurzdiagnose der Ausgangslage
2. Fertiger Entwurf oder strukturierte Arbeitsvorlage
3. Annahmen und offene Punkte
4. Risiken oder rote Flaggen
5. Konkreter nächster Schritt
