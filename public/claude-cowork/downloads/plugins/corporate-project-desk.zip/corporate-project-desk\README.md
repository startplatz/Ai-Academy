# Corporate Project Desk

Ein Projektarbeitsplatz fuer komplexe Abstimmungen, Statusberichte, Management-Informationen und strukturierte Entscheidungen.

## Enthaltene Skills
- Stakeholder-Briefing
- Projektstatus-Generator
- Decision-Log
- Workshop-Designer
- Management-Summary
- Risikoregister

## Installation
Kopiere die Ordner aus `.claude/skills/` in dein Claude-Code-Projekt oder in deinen persoenlichen Skills-Ordner.
