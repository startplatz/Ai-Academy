---
description: 'Erstellt technische Spezifikationen aus Anforderungen, User Stories und Produktideen.'
---

# Tech-Spec-Writer

## Einsatzmoment
Der Skill ist für Situationen gedacht, in denen Teilnehmende zwischen Tickets, Spezifikationen, Incidents und dem Wunsch, Ursachen statt Symptome zu bearbeiten sind. Das Ziel ist nicht, schnell generischen Text zu produzieren, sondern Druck aus der Aufgabe zu nehmen und eine belastbare Arbeitsgrundlage zu schaffen.

Typische Spannung: Eine Idee wird erst umsetzbar, wenn sie testbar und begrenzt ist.

## Zielbild
Am Ende liegt ein Ergebnis vor, das eine Person direkt prüfen, senden, entscheiden oder weiterbearbeiten kann. Claude soll nicht so tun, als sei alles sicher. Claude soll Annahmen, Lücken, Risiken und Rückfragen sichtbar machen.

Erwartete Outputs:
- technische Spezifikation
- Anforderungen
- offene Fragen
- Risiken
- Umsetzungshinweise

## Typischer Input
- Anforderung
- User Story
- Produktidee
- bestehende Dokumentation
- technische Rahmenbedingungen

## Praxisprinzipien
- erst Reproduktion, Impact und betroffene Systeme klären
- technische Details in entscheidbare Anforderungen übersetzen
- Postmortems blameless, konkret und maßnahmenorientiert halten

## Expert Moves für diesen Skill
- Problem, Nutzer, Scope, Nicht-Ziele und Akzeptanzkriterien trennen
- Datenflüsse und Edge Cases benennen
- offene technische Fragen sammeln

## Vorgehen
1. Lies den Input einmal nur auf Ziel, Kontext und gewünschtes Ergebnis.
2. Markiere fehlende Informationen. Wenn sie entscheidungsrelevant sind, frage nach, statt etwas zu erfinden.
3. Trenne Fakten, Annahmen, Interpretation und Empfehlung sichtbar.
4. Erstelle zuerst eine knappe Arbeitsstruktur, dann den eigentlichen Entwurf.
5. Prüfe das Ergebnis gegen die Qualitätskriterien unten.
6. Liefere bei Unsicherheit zwei Optionen: eine vorsichtige Version und eine mutigere Version mit klarer Begründung.

## Qualitätskriterien
- Akzeptanzkriterien sind testbar
- Logs, Daten und Vermutungen sind getrennt
- Automatisierung löst ein wiederholbares Problem, keinen Einzelfall

## Worauf du achten musst
- Lösung vor Problem
- unklare Definition of Done
- vergessene Fehlerfälle

## Rückfragen, wenn Informationen fehlen
- Was soll mit dem Ergebnis direkt passieren: senden, entscheiden, intern vorbereiten oder prüfen?
- Wer ist die Zielperson und wie viel Vorwissen hat sie?
- Welche Frist, welches Risiko oder welche geschäftliche Konsequenz hängt daran?
- Gibt es Formulierungen, Zahlen, Namen oder Zusagen, die unverändert bleiben müssen?

## Output-Format
Gib das Ergebnis in dieser Reihenfolge aus:
1. Kurzdiagnose der Ausgangslage
2. Fertiger Entwurf oder strukturierte Arbeitsvorlage
3. Annahmen und offene Punkte
4. Risiken oder rote Flaggen
5. Konkreter nächster Schritt
