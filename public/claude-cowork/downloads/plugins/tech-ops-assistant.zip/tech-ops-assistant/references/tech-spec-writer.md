# Tech-Spec-Writer

## Wann verwenden
Nutze diesen Skill, wenn du für Entwickler, Produktteams, IT-Projektleitung, Gründer, technische Beratung den beschriebenen Arbeitsprozess mit Claude strukturiert vorbereiten oder ausführen willst.

## Aufgabe
Der Tech-Spec-Writer erstellt aus Anforderungen, User Stories oder Projektideen technische Spezifikationen. Er strukturiert Ziele, Anforderungen, Schnittstellen, Daten, Risiken und offene Fragen.

## Typischer Input
- Anforderung
- User Story
- Produktidee
- bestehende Dokumentation
- technische Rahmenbedingungen

## Vorgehen
1. Kläre Ziel, Kontext, Zielgruppe und gewünschtes Ausgabeformat.
2. Markiere fehlende Informationen als Rückfragen, statt sie zu erfinden.
3. Strukturiere den Arbeitsprozess in nachvollziehbare Schritte.
4. Erstelle einen ersten Output, der direkt weiterbearbeitet werden kann.
5. Füge einen kurzen Qualitätscheck mit Risiken, Annahmen und nächsten Schritten hinzu.

## Typischer Output
- technische Spezifikation
- Anforderungen
- offene Fragen
- Risiken
- Umsetzungshinweise

## Qualitätscheck
- Sind Annahmen, Unsicherheiten und fehlende Informationen sichtbar?
- Ist der Output für den Arbeitsalltag nutzbar und nicht nur allgemein formuliert?
- Stimmen Ton, Detailgrad und Format mit dem Zielkontext überein?
- Gibt es eine klare Empfehlung oder einen nächsten Schritt?

## Grenzen
Dieser Skill ersetzt keine Rechts-, Steuer-, Finanz- oder Datenschutzberatung. Nutze ihn zur Vorbereitung, Strukturierung und Qualitätssicherung, nicht als finale Fachentscheidung.
