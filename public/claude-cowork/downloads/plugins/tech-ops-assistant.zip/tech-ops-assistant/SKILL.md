---
name: tech-ops-assistant
description: 'Ein technischer Arbeitsbereich für Tickets, Spezifikationen, API-Dokumentation, Datenanalysen, Automationen und Incident-Learnings.'
---

# Tech Ops Assistant

## Wann verwenden
Nutze diesen Skill, wenn du einen kompletten Arbeitsbereich statt einzelner Skills aktivieren willst. Das Paket bündelt mehrere Claude-Workflows für typische Aufgaben und verweist auf fokussierte Referenzdateien.

## Arbeitsweise
1. Kläre zuerst, welche Aufgabe, Eingabe und gewünschter Output vorliegen.
2. Wähle aus den enthaltenen Skills die passendste Referenzdatei aus eferences/.
3. Lies nur die Referenz, die zur Aufgabe passt, und folge deren Vorgehen.
4. Wenn mehrere Aufgaben kombiniert sind, arbeite sie nacheinander ab und trenne die Ergebnisse sauber.
5. Frage nach, wenn Pflichtinformationen wie Zielgruppe, Format, Zeitraum, Kennzahlen oder Tonalität fehlen.

## Enthaltene Skills
- Ticket-Analyzer: Analysiert Tickets, erkennt wiederkehrende Probleme und priorisiert nächste Schritte.
- Tech-Spec-Writer: Erstellt technische Spezifikationen aus Anforderungen, User Stories und Produktideen.
- API-Doku-Reader: Fasst API-Dokumentation verständlich zusammen und extrahiert relevante Integrationsschritte.
- Datenanalyse-Notebook: Analysiert Tabellen und Daten, erkennt Muster, Ausreißer und verständliche Handlungshinweise.
- Automation-Blueprint: Entwirft Automationsabläufe mit Triggern, Datenflüssen, Tool-Schritten und Freigaben.
- Incident-Postmortem: Erstellt strukturierte Postmortems mit Ursache, Auswirkungen, Timeline und Maßnahmenplan.

## Referenzen
- eferences/ticket-analyzer.md: nutze diese Referenz, wenn die Aufgabe zu diesem Skill passt.
- eferences/tech-spec-writer.md: nutze diese Referenz, wenn die Aufgabe zu diesem Skill passt.
- eferences/api-doku-reader.md: nutze diese Referenz, wenn die Aufgabe zu diesem Skill passt.
- eferences/datenanalyse-notebook.md: nutze diese Referenz, wenn die Aufgabe zu diesem Skill passt.
- eferences/automation-blueprint.md: nutze diese Referenz, wenn die Aufgabe zu diesem Skill passt.
- eferences/incident-postmortem.md: nutze diese Referenz, wenn die Aufgabe zu diesem Skill passt.