# Tech Ops Assistant

Dieses Plugin bündelt mehrere Claude Cowork Skills für einen zusammenhängenden Arbeitsbereich.

## Enthaltene Skills
- /tech-ops-assistant:ticket-analyzer - Ticket-Analyzer
- /tech-ops-assistant:tech-spec-writer - Tech-Spec-Writer
- /tech-ops-assistant:api-doku-reader - API-Doku-Reader
- /tech-ops-assistant:datenanalyse-notebook - Datenanalyse-Notebook
- /tech-ops-assistant:automation-blueprint - Automation-Blueprint
- /tech-ops-assistant:incident-postmortem - Incident-Postmortem

## Format
Dieses ZIP folgt dem Claude Code / Cowork Plugin-Format:

- `.claude-plugin/plugin.json` beschreibt das Plugin.
- `skills/<skill-name>/SKILL.md` enthält die einzelnen Skills.
- Die Skill-Namen werden im Plugin namespaced, z. B. `/tech-ops-assistant:ticket-analyzer`.

Für Claude.ai Custom Skill Uploads nutze die einzelnen Skill-ZIPs aus der Skill Library. Dieses Paket ist bewusst ein Plugin-Bundle.
