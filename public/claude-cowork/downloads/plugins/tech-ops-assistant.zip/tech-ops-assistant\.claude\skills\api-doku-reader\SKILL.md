---
name: api-doku-reader
description: Fasst API-Dokumentation verständlich zusammen und extrahiert relevante Integrationsschritte.
---

# API-Doku-Reader

## Wann verwenden
Nutze diesen Skill, wenn du für Entwickler, No-Code-Builder, IT, Produktteams, technische Projektleitung den beschriebenen Arbeitsprozess mit Claude strukturiert vorbereiten oder ausführen willst.

## Aufgabe
Der API-Doku-Reader liest und strukturiert API-Dokumentation. Er fasst Authentifizierung, Endpoints, Datenmodelle, Beispiele und Integrationsschritte verständlich zusammen.

## Typischer Input
- API-Dokumentation
- technische Anleitung
- Endpoint-Liste
- Integrationsziel

## Vorgehen
1. Kläre Ziel, Kontext, Zielgruppe und gewünschtes Ausgabeformat.
2. Markiere fehlende Informationen als Rückfragen, statt sie zu erfinden.
3. Strukturiere den Arbeitsprozess in nachvollziehbare Schritte.
4. Erstelle einen ersten Output, der direkt weiterbearbeitet werden kann.
5. Füge einen kurzen Qualitätscheck mit Risiken, Annahmen und nächsten Schritten hinzu.

## Typischer Output
- Zusammenfassung
- relevante Endpoints
- Authentifizierungsschritte
- Beispielablauf
- offene Fragen

## Qualitätscheck
- Sind Annahmen, Unsicherheiten und fehlende Informationen sichtbar?
- Ist der Output für den Arbeitsalltag nutzbar und nicht nur allgemein formuliert?
- Stimmen Ton, Detailgrad und Format mit dem Zielkontext überein?
- Gibt es eine klare Empfehlung oder einen nächsten Schritt?

## Grenzen
Dieser Skill ersetzt keine Rechts-, Steuer-, Finanz- oder Datenschutzberatung. Nutze ihn zur Vorbereitung, Strukturierung und Qualitätssicherung, nicht als finale Fachentscheidung.
