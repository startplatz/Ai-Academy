# Tech Ops Assistant

Ein technischer Arbeitsbereich fuer Tickets, Spezifikationen, API-Dokumentation, Datenanalysen, Automationen und Incident-Learnings.

## Enthaltene Skills
- Ticket-Analyzer
- Tech-Spec-Writer
- API-Doku-Reader
- Datenanalyse-Notebook
- Automation-Blueprint
- Incident-Postmortem

## Installation
Kopiere die Ordner aus `.claude/skills/` in dein Claude-Code-Projekt oder in deinen persoenlichen Skills-Ordner.
