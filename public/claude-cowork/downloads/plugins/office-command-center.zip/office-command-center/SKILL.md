---
name: office-command-center
description: 'Ein Organisationszentrum für E-Mails, Meetings, Tabellen, Dokumente und interne Abstimmung.'
---

# Office Command Center

## Wann verwenden
Nutze diesen Skill, wenn du einen kompletten Arbeitsbereich statt einzelner Skills aktivieren willst. Das Paket bündelt mehrere Claude-Workflows für typische Aufgaben und verweist auf fokussierte Referenzdateien.

## Arbeitsweise
1. Kläre zuerst, welche Aufgabe, Eingabe und gewünschter Output vorliegen.
2. Wähle aus den enthaltenen Skills die passendste Referenzdatei aus eferences/.
3. Lies nur die Referenz, die zur Aufgabe passt, und folge deren Vorgehen.
4. Wenn mehrere Aufgaben kombiniert sind, arbeite sie nacheinander ab und trenne die Ergebnisse sauber.
5. Frage nach, wenn Pflichtinformationen wie Zielgruppe, Format, Zeitraum, Kennzahlen oder Tonalität fehlen.

## Enthaltene Skills
- Meeting-zu-Aufgaben: Macht aus Meetings konkrete Aufgaben, Verantwortlichkeiten, Deadlines und Follow-ups.
- Inbox-Priorisierung: Sortiert E-Mails nach Relevanz und Handlungsbedarf und bereitet nächste Schritte vor.
- Excel-Cleaner: Prüft Tabellen auf Fehler, Dubletten, fehlende Werte und Formatprobleme.
- Statusupdate-Schreiber: Formuliert klare Statusupdates aus Projektständen, Aufgaben und offenen Punkten.
- Dokumenten-Finder: Findet relevante Dokumente im Arbeitskontext und fasst ihre wichtigsten Inhalte zusammen.
- Vorlagen-Standardisierer: Standardisiert Texte und Dokumente nach Struktur, Tonalität und internen Vorgaben.

## Referenzen
- eferences/meeting-zu-aufgaben.md: nutze diese Referenz, wenn die Aufgabe zu diesem Skill passt.
- eferences/inbox-priorisierung.md: nutze diese Referenz, wenn die Aufgabe zu diesem Skill passt.
- eferences/excel-cleaner.md: nutze diese Referenz, wenn die Aufgabe zu diesem Skill passt.
- eferences/statusupdate-schreiber.md: nutze diese Referenz, wenn die Aufgabe zu diesem Skill passt.
- eferences/dokumenten-finder.md: nutze diese Referenz, wenn die Aufgabe zu diesem Skill passt.
- eferences/vorlagen-standardisierer.md: nutze diese Referenz, wenn die Aufgabe zu diesem Skill passt.