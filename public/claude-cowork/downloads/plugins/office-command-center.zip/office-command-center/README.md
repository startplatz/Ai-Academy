# Office Command Center

Dieses Plugin bündelt mehrere Claude Cowork Skills für einen zusammenhängenden Arbeitsbereich.

## Enthaltene Skills
- /office-command-center:meeting-zu-aufgaben - Meeting-zu-Aufgaben
- /office-command-center:inbox-priorisierung - Inbox-Priorisierung
- /office-command-center:excel-cleaner - Excel-Cleaner
- /office-command-center:statusupdate-schreiber - Statusupdate-Schreiber
- /office-command-center:dokumenten-finder - Dokumenten-Finder
- /office-command-center:vorlagen-standardisierer - Vorlagen-Standardisierer

## Format
Dieses ZIP folgt dem Claude Code / Cowork Plugin-Format:

- `.claude-plugin/plugin.json` beschreibt das Plugin.
- `skills/<skill-name>/SKILL.md` enthält die einzelnen Skills.
- Die Skill-Namen werden im Plugin namespaced, z. B. `/office-command-center:meeting-zu-aufgaben`.

Für Claude.ai Custom Skill Uploads nutze die einzelnen Skill-ZIPs aus der Skill Library. Dieses Paket ist bewusst ein Plugin-Bundle.
