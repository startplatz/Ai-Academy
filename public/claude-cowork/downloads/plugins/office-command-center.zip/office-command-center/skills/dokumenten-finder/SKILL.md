---
description: 'Findet relevante Dokumente im Arbeitskontext und fasst ihre wichtigsten Inhalte zusammen.'
---

# Dokumenten-Finder

## Einsatzmoment
Der Skill ist für Situationen gedacht, in denen Teilnehmende operativ überladen, viele Nachrichten, Meetings und Tabellen, aber wenig Entscheidungsklarheit sind. Das Ziel ist nicht, schnell generischen Text zu produzieren, sondern Druck aus der Aufgabe zu nehmen und eine belastbare Arbeitsgrundlage zu schaffen.

Typische Spannung: Das richtige Dokument existiert wahrscheinlich, aber niemand weiß wo oder in welcher Version.

## Zielbild
Am Ende liegt ein Ergebnis vor, das eine Person direkt prüfen, senden, entscheiden oder weiterbearbeiten kann. Claude soll nicht so tun, als sei alles sicher. Claude soll Annahmen, Lücken, Risiken und Rückfragen sichtbar machen.

Erwartete Outputs:
- relevante Dokumente
- Kurzfassungen
- Fundstellen
- offene Punkte
- empfohlene nächste Schritte

## Typischer Input
- Suchanfrage
- Ordnerstruktur
- Dateisammlung
- Projektkontext

## Praxisprinzipien
- aus Information zuerst Zuständigkeit, Termin und Entscheidung extrahieren
- Dubletten, Unschärfe und alte Versionen sichtbar machen
- jede Zusammenfassung muss eine Arbeitsliste erzeugen, nicht nur einen schönen Text

## Expert Moves für diesen Skill
- Suchbegriffe, Zeitraum, Personen und Versionen ableiten
- Fundstücke nach Verlässlichkeit sortieren
- fehlende Dokumente als Risiko markieren

## Vorgehen
1. Lies den Input einmal nur auf Ziel, Kontext und gewünschtes Ergebnis.
2. Markiere fehlende Informationen. Wenn sie entscheidungsrelevant sind, frage nach, statt etwas zu erfinden.
3. Trenne Fakten, Annahmen, Interpretation und Empfehlung sichtbar.
4. Erstelle zuerst eine knappe Arbeitsstruktur, dann den eigentlichen Entwurf.
5. Prüfe das Ergebnis gegen die Qualitätskriterien unten.
6. Liefere bei Unsicherheit zwei Optionen: eine vorsichtige Version und eine mutigere Version mit klarer Begründung.

## Qualitätskriterien
- Aufgaben sind eindeutig formuliert
- Status trennt Fakten, Blocker und nächste Schritte
- Tabellen bleiben überprüfbar und reversibel

## Worauf du achten musst
- alte Versionen
- ähnliche Dateinamen
- fehlende Quelle

## Rückfragen, wenn Informationen fehlen
- Was soll mit dem Ergebnis direkt passieren: senden, entscheiden, intern vorbereiten oder prüfen?
- Wer ist die Zielperson und wie viel Vorwissen hat sie?
- Welche Frist, welches Risiko oder welche geschäftliche Konsequenz hängt daran?
- Gibt es Formulierungen, Zahlen, Namen oder Zusagen, die unverändert bleiben müssen?

## Output-Format
Gib das Ergebnis in dieser Reihenfolge aus:
1. Kurzdiagnose der Ausgangslage
2. Fertiger Entwurf oder strukturierte Arbeitsvorlage
3. Annahmen und offene Punkte
4. Risiken oder rote Flaggen
5. Konkreter nächster Schritt
