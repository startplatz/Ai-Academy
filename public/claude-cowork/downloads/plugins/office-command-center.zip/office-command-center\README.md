# Office Command Center

Ein Organisationszentrum fuer E-Mails, Meetings, Tabellen, Dokumente und interne Abstimmung.

## Enthaltene Skills
- Meeting-zu-Aufgaben
- Inbox-Priorisierung
- Excel-Cleaner
- Statusupdate-Schreiber
- Dokumenten-Finder
- Vorlagen-Standardisierer

## Installation
Kopiere die Ordner aus `.claude/skills/` in dein Claude-Code-Projekt oder in deinen persoenlichen Skills-Ordner.
