---
name: marketing-growth-desk
description: 'Ein kreativer und analytischer Arbeitsplatz für Kampagnen, Content-Produktion und kanalübergreifende Kommunikation.'
---

# Marketing Growth Desk

## Wann verwenden
Nutze diesen Skill, wenn du einen kompletten Arbeitsbereich statt einzelner Skills aktivieren willst. Das Paket bündelt mehrere Claude-Workflows für typische Aufgaben und verweist auf fokussierte Referenzdateien.

## Arbeitsweise
1. Kläre zuerst, welche Aufgabe, Eingabe und gewünschter Output vorliegen.
2. Wähle aus den enthaltenen Skills die passendste Referenzdatei aus eferences/.
3. Lies nur die Referenz, die zur Aufgabe passt, und folge deren Vorgehen.
4. Wenn mehrere Aufgaben kombiniert sind, arbeite sie nacheinander ab und trenne die Ergebnisse sauber.
5. Frage nach, wenn Pflichtinformationen wie Zielgruppe, Format, Zeitraum, Kennzahlen oder Tonalität fehlen.

## Enthaltene Skills
- Kampagnen-Planer: Entwickelt aus Zielgruppe, Angebot und Ziel eine strukturierte Kampagne mit Botschaften, Kanälen und Umsetzungsschritten.
- Content-Repurposer: Verwandelt lange Inhalte in viele verwertbare Contentformate für Social Media, Newsletter und Website.
- Brand-Voice-Wächter: Überarbeitet Texte passend zur Markenstimme und sorgt für konsistente Kommunikation.
- Newsletter-Schreiber: Erstellt Newsletter mit Betreff, Struktur, Text und Call-to-Action aus Stichpunkten und Themen.
- Ad-Copy-Generator: Erstellt Anzeigenvarianten mit Headlines, Hooks, Nutzenversprechen und Call-to-Actions.
- Performance-Analyst: Analysiert Kampagnendaten und übersetzt Zahlen in verständliche Erkenntnisse und nächste Schritte.

## Referenzen
- eferences/kampagnen-planer.md: nutze diese Referenz, wenn die Aufgabe zu diesem Skill passt.
- eferences/content-repurposer.md: nutze diese Referenz, wenn die Aufgabe zu diesem Skill passt.
- eferences/brand-voice-waechter.md: nutze diese Referenz, wenn die Aufgabe zu diesem Skill passt.
- eferences/newsletter-schreiber.md: nutze diese Referenz, wenn die Aufgabe zu diesem Skill passt.
- eferences/ad-copy-generator.md: nutze diese Referenz, wenn die Aufgabe zu diesem Skill passt.
- eferences/performance-analyst.md: nutze diese Referenz, wenn die Aufgabe zu diesem Skill passt.