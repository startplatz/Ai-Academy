# Newsletter-Schreiber

## Wann verwenden
Nutze diesen Skill, wenn du für Marketing, Creator, Selbstständige, Agenturen, Bildungseinrichtungen den beschriebenen Arbeitsprozess mit Claude strukturiert vorbereiten oder ausführen willst.

## Aufgabe
Der Newsletter-Schreiber erstellt Newsletter aus Themen, Angeboten, Links, Notizen oder Kampagnenzielen. Er kann Betreffzeilen, Einleitungen, Haupttext, CTA und Varianten vorbereiten.

## Typischer Input
- Thema
- Zielgruppe
- Angebot
- Links
- Stichpunkte
- gewünschter Ton

## Vorgehen
1. Kläre Ziel, Kontext, Zielgruppe und gewünschtes Ausgabeformat.
2. Markiere fehlende Informationen als Rückfragen, statt sie zu erfinden.
3. Strukturiere den Arbeitsprozess in nachvollziehbare Schritte.
4. Erstelle einen ersten Output, der direkt weiterbearbeitet werden kann.
5. Füge einen kurzen Qualitätscheck mit Risiken, Annahmen und nächsten Schritten hinzu.

## Typischer Output
- Newsletter-Entwurf
- Betreffzeilen
- Preheader
- CTA
- Varianten

## Qualitätscheck
- Sind Annahmen, Unsicherheiten und fehlende Informationen sichtbar?
- Ist der Output für den Arbeitsalltag nutzbar und nicht nur allgemein formuliert?
- Stimmen Ton, Detailgrad und Format mit dem Zielkontext überein?
- Gibt es eine klare Empfehlung oder einen nächsten Schritt?

## Grenzen
Dieser Skill ersetzt keine Rechts-, Steuer-, Finanz- oder Datenschutzberatung. Nutze ihn zur Vorbereitung, Strukturierung und Qualitätssicherung, nicht als finale Fachentscheidung.
