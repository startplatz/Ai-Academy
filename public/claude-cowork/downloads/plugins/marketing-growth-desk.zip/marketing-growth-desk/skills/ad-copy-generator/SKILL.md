---
description: 'Erstellt Anzeigenvarianten mit Headlines, Hooks, Nutzenversprechen und Call-to-Actions.'
---

# Ad-Copy-Generator

## Einsatzmoment
Der Skill ist für Situationen gedacht, in denen Teilnehmende unter Veröffentlichungsdruck, mit Angst vor generischem Content und Markenverwässerung sind. Das Ziel ist nicht, schnell generischen Text zu produzieren, sondern Druck aus der Aufgabe zu nehmen und eine belastbare Arbeitsgrundlage zu schaffen.

Typische Spannung: Anzeigen brauchen Schärfe, aber falsche Versprechen kosten Vertrauen und Budget.

## Zielbild
Am Ende liegt ein Ergebnis vor, das eine Person direkt prüfen, senden, entscheiden oder weiterbearbeiten kann. Claude soll nicht so tun, als sei alles sicher. Claude soll Annahmen, Lücken, Risiken und Rückfragen sichtbar machen.

Erwartete Outputs:
- Headline-Varianten
- Primary Texts
- CTAs
- Hook-Ideen
- A/B-Varianten

## Typischer Input
- Angebot
- Zielgruppe
- Kanal
- Nutzenversprechen
- Einschränkungen

## Praxisprinzipien
- erst Zielgruppe, Kanal und gewünschte Handlung klären
- eine Kernbotschaft in kanalnative Formen übersetzen, nicht blind kopieren
- jede Variante gegen Brand Voice, Faktentreue und Hook-Schärfe prüfen

## Expert Moves für diesen Skill
- Problem, Zielgruppe und Beleg herausarbeiten
- mehrere Hook-Winkel statt Synonyme erzeugen
- Varianten nach Testhypothese labeln

## Vorgehen
1. Lies den Input einmal nur auf Ziel, Kontext und gewünschtes Ergebnis.
2. Markiere fehlende Informationen. Wenn sie entscheidungsrelevant sind, frage nach, statt etwas zu erfinden.
3. Trenne Fakten, Annahmen, Interpretation und Empfehlung sichtbar.
4. Erstelle zuerst eine knappe Arbeitsstruktur, dann den eigentlichen Entwurf.
5. Prüfe das Ergebnis gegen die Qualitätskriterien unten.
6. Liefere bei Unsicherheit zwei Optionen: eine vorsichtige Version und eine mutigere Version mit klarer Begründung.

## Qualitätskriterien
- Hook, Nutzenversprechen und CTA passen zum Kanal
- Brand Voice bleibt erkennbar
- keine Leistungsversprechen ohne Beleg

## Worauf du achten musst
- Superlative ohne Proof
- zu breite Zielgruppe
- CTA ohne konkrete Erwartung

## Rückfragen, wenn Informationen fehlen
- Was soll mit dem Ergebnis direkt passieren: senden, entscheiden, intern vorbereiten oder prüfen?
- Wer ist die Zielperson und wie viel Vorwissen hat sie?
- Welche Frist, welches Risiko oder welche geschäftliche Konsequenz hängt daran?
- Gibt es Formulierungen, Zahlen, Namen oder Zusagen, die unverändert bleiben müssen?

## Output-Format
Gib das Ergebnis in dieser Reihenfolge aus:
1. Kurzdiagnose der Ausgangslage
2. Fertiger Entwurf oder strukturierte Arbeitsvorlage
3. Annahmen und offene Punkte
4. Risiken oder rote Flaggen
5. Konkreter nächster Schritt
