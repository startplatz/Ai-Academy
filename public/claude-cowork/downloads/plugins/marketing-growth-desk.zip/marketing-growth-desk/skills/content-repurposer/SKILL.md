---
description: 'Verwandelt lange Inhalte in viele verwertbare Contentformate für Social Media, Newsletter und Website.'
---

# Content-Repurposer

## Einsatzmoment
Der Skill ist für Situationen gedacht, in denen Teilnehmende unter Veröffentlichungsdruck, mit Angst vor generischem Content und Markenverwässerung sind. Das Ziel ist nicht, schnell generischen Text zu produzieren, sondern Druck aus der Aufgabe zu nehmen und eine belastbare Arbeitsgrundlage zu schaffen.

Typische Spannung: Ein starker Inhalt soll mehrfach wirken, ohne überall gleich zu klingen.

## Zielbild
Am Ende liegt ein Ergebnis vor, das eine Person direkt prüfen, senden, entscheiden oder weiterbearbeiten kann. Claude soll nicht so tun, als sei alles sicher. Claude soll Annahmen, Lücken, Risiken und Rückfragen sichtbar machen.

Erwartete Outputs:
- LinkedIn-Posts
- Newsletter
- Shortform-Ideen
- Social Captions
- Contentplan
- Website-Abschnitte

## Typischer Input
- Webinar-Transkript
- Podcast-Transkript
- Blogartikel
- Workshop-Material
- Präsentation

## Praxisprinzipien
- erst Zielgruppe, Kanal und gewünschte Handlung klären
- eine Kernbotschaft in kanalnative Formen übersetzen, nicht blind kopieren
- jede Variante gegen Brand Voice, Faktentreue und Hook-Schärfe prüfen

## Expert Moves für diesen Skill
- Kerninsight extrahieren
- pro Kanal Hook, Format und CTA neu bauen
- Brand Voice und Faktentreue final prüfen

## Vorgehen
1. Lies den Input einmal nur auf Ziel, Kontext und gewünschtes Ergebnis.
2. Markiere fehlende Informationen. Wenn sie entscheidungsrelevant sind, frage nach, statt etwas zu erfinden.
3. Trenne Fakten, Annahmen, Interpretation und Empfehlung sichtbar.
4. Erstelle zuerst eine knappe Arbeitsstruktur, dann den eigentlichen Entwurf.
5. Prüfe das Ergebnis gegen die Qualitätskriterien unten.
6. Liefere bei Unsicherheit zwei Optionen: eine vorsichtige Version und eine mutigere Version mit klarer Begründung.

## Qualitätskriterien
- Hook, Nutzenversprechen und CTA passen zum Kanal
- Brand Voice bleibt erkennbar
- keine Leistungsversprechen ohne Beleg

## Worauf du achten musst
- Copy-Paste über Kanäle
- AI-Slop-Ton
- fehlender Human Edit

## Rückfragen, wenn Informationen fehlen
- Was soll mit dem Ergebnis direkt passieren: senden, entscheiden, intern vorbereiten oder prüfen?
- Wer ist die Zielperson und wie viel Vorwissen hat sie?
- Welche Frist, welches Risiko oder welche geschäftliche Konsequenz hängt daran?
- Gibt es Formulierungen, Zahlen, Namen oder Zusagen, die unverändert bleiben müssen?

## Output-Format
Gib das Ergebnis in dieser Reihenfolge aus:
1. Kurzdiagnose der Ausgangslage
2. Fertiger Entwurf oder strukturierte Arbeitsvorlage
3. Annahmen und offene Punkte
4. Risiken oder rote Flaggen
5. Konkreter nächster Schritt
