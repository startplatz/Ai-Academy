# Marketing Growth Desk

Dieses Plugin bündelt mehrere Claude Cowork Skills für einen zusammenhängenden Arbeitsbereich.

## Enthaltene Skills
- /marketing-growth-desk:kampagnen-planer - Kampagnen-Planer
- /marketing-growth-desk:content-repurposer - Content-Repurposer
- /marketing-growth-desk:brand-voice-waechter - Brand-Voice-Wächter
- /marketing-growth-desk:newsletter-schreiber - Newsletter-Schreiber
- /marketing-growth-desk:ad-copy-generator - Ad-Copy-Generator
- /marketing-growth-desk:performance-analyst - Performance-Analyst

## Format
Dieses ZIP folgt dem Claude Code / Cowork Plugin-Format:

- `.claude-plugin/plugin.json` beschreibt das Plugin.
- `skills/<skill-name>/SKILL.md` enthält die einzelnen Skills.
- Die Skill-Namen werden im Plugin namespaced, z. B. `/marketing-growth-desk:kampagnen-planer`.

Für Claude.ai Custom Skill Uploads nutze die einzelnen Skill-ZIPs aus der Skill Library. Dieses Paket ist bewusst ein Plugin-Bundle.
