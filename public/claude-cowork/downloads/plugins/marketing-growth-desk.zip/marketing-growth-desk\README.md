# Marketing Growth Desk

Ein kreativer und analytischer Arbeitsplatz fuer Kampagnen, Content-Produktion und kanaluebergreifende Kommunikation.

## Enthaltene Skills
- Kampagnen-Planer
- Content-Repurposer
- Brand-Voice-Wächter
- Newsletter-Schreiber
- Ad-Copy-Generator
- Performance-Analyst

## Installation
Kopiere die Ordner aus `.claude/skills/` in dein Claude-Code-Projekt oder in deinen persoenlichen Skills-Ordner.
