---
name: ad-copy-generator
description: Erstellt Anzeigenvarianten mit Headlines, Hooks, Nutzenversprechen und Call-to-Actions.
---

# Ad-Copy-Generator

## Wann verwenden
Nutze diesen Skill, wenn du für Marketing, Performance Marketing, Agenturen, Gründer, Sales-nahe Teams den beschriebenen Arbeitsprozess mit Claude strukturiert vorbereiten oder ausführen willst.

## Aufgabe
Der Ad-Copy-Generator erstellt Varianten für Anzeigen, Social Ads, LinkedIn Ads, Google Ads oder Kampagnen-Posts. Er berücksichtigt Zielgruppe, Nutzenversprechen, Angebot, Kanal und Tonalität.

## Typischer Input
- Angebot
- Zielgruppe
- Kanal
- Nutzenversprechen
- Einschränkungen

## Vorgehen
1. Kläre Ziel, Kontext, Zielgruppe und gewünschtes Ausgabeformat.
2. Markiere fehlende Informationen als Rückfragen, statt sie zu erfinden.
3. Strukturiere den Arbeitsprozess in nachvollziehbare Schritte.
4. Erstelle einen ersten Output, der direkt weiterbearbeitet werden kann.
5. Füge einen kurzen Qualitätscheck mit Risiken, Annahmen und nächsten Schritten hinzu.

## Typischer Output
- Headline-Varianten
- Primary Texts
- CTAs
- Hook-Ideen
- A/B-Varianten

## Qualitätscheck
- Sind Annahmen, Unsicherheiten und fehlende Informationen sichtbar?
- Ist der Output für den Arbeitsalltag nutzbar und nicht nur allgemein formuliert?
- Stimmen Ton, Detailgrad und Format mit dem Zielkontext überein?
- Gibt es eine klare Empfehlung oder einen nächsten Schritt?

## Grenzen
Dieser Skill ersetzt keine Rechts-, Steuer-, Finanz- oder Datenschutzberatung. Nutze ihn zur Vorbereitung, Strukturierung und Qualitätssicherung, nicht als finale Fachentscheidung.
