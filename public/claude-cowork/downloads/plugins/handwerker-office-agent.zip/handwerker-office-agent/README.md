# Handwerker Office Agent

Dieses Plugin bündelt mehrere Claude Cowork Skills für einen zusammenhängenden Arbeitsbereich.

## Enthaltene Skills
- /handwerker-office-agent:anfrage-triage - Anfrage-Triage
- /handwerker-office-agent:aufmass-zu-angebot - Aufmaß-zu-Angebot
- /handwerker-office-agent:materiallisten-generator - Materiallisten-Generator
- /handwerker-office-agent:baustellen-protokoll - Baustellen-Protokoll
- /handwerker-office-agent:termin-koordinator - Termin-Koordinator
- /handwerker-office-agent:reklamations-antworter - Reklamations-Antworter

## Format
Dieses ZIP folgt dem Claude Code / Cowork Plugin-Format:

- `.claude-plugin/plugin.json` beschreibt das Plugin.
- `skills/<skill-name>/SKILL.md` enthält die einzelnen Skills.
- Die Skill-Namen werden im Plugin namespaced, z. B. `/handwerker-office-agent:anfrage-triage`.

Für Claude.ai Custom Skill Uploads nutze die einzelnen Skill-ZIPs aus der Skill Library. Dieses Paket ist bewusst ein Plugin-Bundle.
