---
name: handwerker-office-agent
description: 'Ein digitales Backoffice für Handwerk und lokale Services, das Mails, Notizen und Bilder in klare nächste Schritte verwandelt.'
---

# Handwerker Office Agent

## Wann verwenden
Nutze diesen Skill, wenn du einen kompletten Arbeitsbereich statt einzelner Skills aktivieren willst. Das Paket bündelt mehrere Claude-Workflows für typische Aufgaben und verweist auf fokussierte Referenzdateien.

## Arbeitsweise
1. Kläre zuerst, welche Aufgabe, Eingabe und gewünschter Output vorliegen.
2. Wähle aus den enthaltenen Skills die passendste Referenzdatei aus eferences/.
3. Lies nur die Referenz, die zur Aufgabe passt, und folge deren Vorgehen.
4. Wenn mehrere Aufgaben kombiniert sind, arbeite sie nacheinander ab und trenne die Ergebnisse sauber.
5. Frage nach, wenn Pflichtinformationen wie Zielgruppe, Format, Zeitraum, Kennzahlen oder Tonalität fehlen.

## Enthaltene Skills
- Anfrage-Triage: Sortiert Kundenanfragen nach Dringlichkeit, Aufwand und Potenzial und bereitet passende Antworten vor.
- Aufmaß-zu-Angebot: Verwandelt Aufmaßnotizen, Bilder oder Kurzbeschreibungen in strukturierte Angebotsentwürfe.
- Materiallisten-Generator: Erstellt aus Auftragsinformationen eine Material- und Werkzeugliste für bessere Vorbereitung.
- Baustellen-Protokoll: Erstellt aus Baustellennotizen und Bildern strukturierte Tagesberichte, Mängellisten und Kundenupdates.
- Termin-Koordinator: Hilft bei Terminabstimmung, Bestätigungen und Kundenkommunikation rund um Verfügbarkeiten.
- Reklamations-Antworter: Formuliert sachliche und professionelle Antworten auf Beschwerden, Reklamationen und schwierige Kundenmails.

## Referenzen
- eferences/anfrage-triage.md: nutze diese Referenz, wenn die Aufgabe zu diesem Skill passt.
- eferences/aufmass-zu-angebot.md: nutze diese Referenz, wenn die Aufgabe zu diesem Skill passt.
- eferences/materiallisten-generator.md: nutze diese Referenz, wenn die Aufgabe zu diesem Skill passt.
- eferences/baustellen-protokoll.md: nutze diese Referenz, wenn die Aufgabe zu diesem Skill passt.
- eferences/termin-koordinator.md: nutze diese Referenz, wenn die Aufgabe zu diesem Skill passt.
- eferences/reklamations-antworter.md: nutze diese Referenz, wenn die Aufgabe zu diesem Skill passt.