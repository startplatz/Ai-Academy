---
name: anfrage-triage
description: Sortiert Kundenanfragen nach Dringlichkeit, Aufwand und Potenzial und bereitet passende Antworten vor.
---

# Anfrage-Triage

## Wann verwenden
Nutze diesen Skill, wenn du für Handwerksbetriebe, lokale Dienstleister, Agenturen, Sales, Support den beschriebenen Arbeitsprozess mit Claude strukturiert vorbereiten oder ausführen willst.

## Aufgabe
Die Anfrage-Triage sortiert eingehende Kundenanfragen nach Dringlichkeit, Ort, Aufwand, Auftragswert und benötigten Rückfragen. Sie hilft dabei, relevante Anfragen schneller zu erkennen und strukturiert zu beantworten.

## Typischer Input
- Kundenmail
- Kontaktformular
- Anfragebeschreibung
- Standort
- gewünschter Termin

## Vorgehen
1. Kläre Ziel, Kontext, Zielgruppe und gewünschtes Ausgabeformat.
2. Markiere fehlende Informationen als Rückfragen, statt sie zu erfinden.
3. Strukturiere den Arbeitsprozess in nachvollziehbare Schritte.
4. Erstelle einen ersten Output, der direkt weiterbearbeitet werden kann.
5. Füge einen kurzen Qualitätscheck mit Risiken, Annahmen und nächsten Schritten hinzu.

## Typischer Output
- Priorisierung
- Einschätzung der Dringlichkeit
- offene Rückfragen
- Antwortvorschlag
- nächste Schritte

## Qualitätscheck
- Sind Annahmen, Unsicherheiten und fehlende Informationen sichtbar?
- Ist der Output für den Arbeitsalltag nutzbar und nicht nur allgemein formuliert?
- Stimmen Ton, Detailgrad und Format mit dem Zielkontext überein?
- Gibt es eine klare Empfehlung oder einen nächsten Schritt?

## Grenzen
Dieser Skill ersetzt keine Rechts-, Steuer-, Finanz- oder Datenschutzberatung. Nutze ihn zur Vorbereitung, Strukturierung und Qualitätssicherung, nicht als finale Fachentscheidung.
