# Handwerker Office Agent

Ein digitales Backoffice fuer Handwerk und lokale Services, das Mails, Notizen und Bilder in klare naechste Schritte verwandelt.

## Enthaltene Skills
- Anfrage-Triage
- Aufmaß-zu-Angebot
- Materiallisten-Generator
- Baustellen-Protokoll
- Termin-Koordinator
- Reklamations-Antworter

## Installation
Kopiere die Ordner aus `.claude/skills/` in dein Claude-Code-Projekt oder in deinen persoenlichen Skills-Ordner.
