# Data & Excel Analyst

Ein Analysepaket fuer Tabellen, Datenqualitaet, einfache Auswertungen und verstaendliche Reports.

## Enthaltene Skills
- Excel-Cleaner
- Datenanalyse-Notebook
- Dashboard-Builder
- Ausreisser-Erkennung
- Report-Generator
- Datenqualitaets-Check

## Installation
Kopiere die Ordner aus `.claude/skills/` in dein Claude-Code-Projekt oder in deinen persoenlichen Skills-Ordner.
