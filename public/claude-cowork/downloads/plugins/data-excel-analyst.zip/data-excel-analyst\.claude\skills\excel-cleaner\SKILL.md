---
name: excel-cleaner
description: Prüft Tabellen auf Fehler, Dubletten, fehlende Werte und Formatprobleme.
---

# Excel-Cleaner

## Wann verwenden
Nutze diesen Skill, wenn du für Office, Finance, HR, Sales, Operations, Datenrollen den beschriebenen Arbeitsprozess mit Claude strukturiert vorbereiten oder ausführen willst.

## Aufgabe
Der Excel-Cleaner prüft Tabellen auf Dubletten, fehlende Daten, inkonsistente Formate, Auffälligkeiten und einfache Fehler. Er bereitet Listen für weitere Auswertung oder Nutzung vor.

## Typischer Input
- Excel-Datei
- CSV-Datei
- Kundenliste
- Bewerberliste
- Rechnungsübersicht

## Vorgehen
1. Kläre Ziel, Kontext, Zielgruppe und gewünschtes Ausgabeformat.
2. Markiere fehlende Informationen als Rückfragen, statt sie zu erfinden.
3. Strukturiere den Arbeitsprozess in nachvollziehbare Schritte.
4. Erstelle einen ersten Output, der direkt weiterbearbeitet werden kann.
5. Füge einen kurzen Qualitätscheck mit Risiken, Annahmen und nächsten Schritten hinzu.

## Typischer Output
- bereinigte Datenstruktur
- Fehlerliste
- Dublettenhinweise
- fehlende Werte
- empfohlene Korrekturen

## Qualitätscheck
- Sind Annahmen, Unsicherheiten und fehlende Informationen sichtbar?
- Ist der Output für den Arbeitsalltag nutzbar und nicht nur allgemein formuliert?
- Stimmen Ton, Detailgrad und Format mit dem Zielkontext überein?
- Gibt es eine klare Empfehlung oder einen nächsten Schritt?

## Grenzen
Dieser Skill ersetzt keine Rechts-, Steuer-, Finanz- oder Datenschutzberatung. Nutze ihn zur Vorbereitung, Strukturierung und Qualitätssicherung, nicht als finale Fachentscheidung.
