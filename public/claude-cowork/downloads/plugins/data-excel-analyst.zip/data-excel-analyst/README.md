# Data & Excel Analyst

Dieses Plugin bündelt mehrere Claude Cowork Skills für einen zusammenhängenden Arbeitsbereich.

## Enthaltene Skills
- /data-excel-analyst:excel-cleaner - Excel-Cleaner
- /data-excel-analyst:datenanalyse-notebook - Datenanalyse-Notebook
- /data-excel-analyst:dashboard-builder - Dashboard-Builder
- /data-excel-analyst:ausreisser-erkennung - Ausreißer-Erkennung
- /data-excel-analyst:report-generator - Report-Generator
- /data-excel-analyst:datenqualitaets-check - Datenqualitäts-Check

## Format
Dieses ZIP folgt dem Claude Code / Cowork Plugin-Format:

- `.claude-plugin/plugin.json` beschreibt das Plugin.
- `skills/<skill-name>/SKILL.md` enthält die einzelnen Skills.
- Die Skill-Namen werden im Plugin namespaced, z. B. `/data-excel-analyst:excel-cleaner`.

Für Claude.ai Custom Skill Uploads nutze die einzelnen Skill-ZIPs aus der Skill Library. Dieses Paket ist bewusst ein Plugin-Bundle.
