---
name: data-excel-analyst
description: 'Ein Analysepaket für Tabellen, Datenqualität, einfache Auswertungen und verständliche Reports.'
---

# Data & Excel Analyst

## Wann verwenden
Nutze diesen Skill, wenn du einen kompletten Arbeitsbereich statt einzelner Skills aktivieren willst. Das Paket bündelt mehrere Claude-Workflows für typische Aufgaben und verweist auf fokussierte Referenzdateien.

## Arbeitsweise
1. Kläre zuerst, welche Aufgabe, Eingabe und gewünschter Output vorliegen.
2. Wähle aus den enthaltenen Skills die passendste Referenzdatei aus eferences/.
3. Lies nur die Referenz, die zur Aufgabe passt, und folge deren Vorgehen.
4. Wenn mehrere Aufgaben kombiniert sind, arbeite sie nacheinander ab und trenne die Ergebnisse sauber.
5. Frage nach, wenn Pflichtinformationen wie Zielgruppe, Format, Zeitraum, Kennzahlen oder Tonalität fehlen.

## Enthaltene Skills
- Excel-Cleaner: Prüft Tabellen auf Fehler, Dubletten, fehlende Werte und Formatprobleme.
- Datenanalyse-Notebook: Analysiert Tabellen und Daten, erkennt Muster, Ausreißer und verständliche Handlungshinweise.
- Dashboard-Builder: Entwirft einfache Dashboard-Strukturen aus Tabellen, Reports und wiederkehrenden Kennzahlen.
- Ausreißer-Erkennung: Sucht in Tabellen und Reports nach auffälligen Werten, Ausreißern, Lücken und möglichen Datenfehlern.
- Report-Generator: Erstellt aus Daten, Notizen und Kennzahlen einen verständlichen Report mit Kernaussagen und Handlungsempfehlungen.
- Datenqualitäts-Check: Prüft Daten auf Vollständigkeit, Konsistenz, Dubletten, Formatprobleme und dokumentierte Annahmen.

## Referenzen
- eferences/excel-cleaner.md: nutze diese Referenz, wenn die Aufgabe zu diesem Skill passt.
- eferences/datenanalyse-notebook.md: nutze diese Referenz, wenn die Aufgabe zu diesem Skill passt.
- eferences/dashboard-builder.md: nutze diese Referenz, wenn die Aufgabe zu diesem Skill passt.
- eferences/ausreisser-erkennung.md: nutze diese Referenz, wenn die Aufgabe zu diesem Skill passt.
- eferences/report-generator.md: nutze diese Referenz, wenn die Aufgabe zu diesem Skill passt.
- eferences/datenqualitaets-check.md: nutze diese Referenz, wenn die Aufgabe zu diesem Skill passt.