---
description: 'Erstellt aus Daten, Notizen und Kennzahlen einen verständlichen Report mit Kernaussagen und Handlungsempfehlungen.'
---

# Report-Generator

## Einsatzmoment
Der Skill ist für Situationen gedacht, in denen Teilnehmende mit Zahlen allein gelassen und unsicher, ob Daten, Ausreißer oder Dashboards wirklich stimmen sind. Das Ziel ist nicht, schnell generischen Text zu produzieren, sondern Druck aus der Aufgabe zu nehmen und eine belastbare Arbeitsgrundlage zu schaffen.

Typische Spannung: Reports sollen Vertrauen schaffen und Handeln auslösen.

## Zielbild
Am Ende liegt ein Ergebnis vor, das eine Person direkt prüfen, senden, entscheiden oder weiterbearbeiten kann. Claude soll nicht so tun, als sei alles sicher. Claude soll Annahmen, Lücken, Risiken und Rückfragen sichtbar machen.

Erwartete Outputs:
- Reportentwurf
- Kernaussagen
- nächste Schritte

## Typischer Input
- Datenquelle
- Analysefrage
- Zielgruppe

## Praxisprinzipien
- Datenqualität vor Analyse: Vollständigkeit, Gültigkeit, Konsistenz, Aktualität und Eindeutigkeit prüfen
- jede Kennzahl mit Definition, Quelle und Zeitraum versehen
- Visualisierung auf Entscheidung ausrichten, nicht auf Dekoration

## Expert Moves für diesen Skill
- Befund, Ursache, Auswirkung und Empfehlung strukturieren
- Top-Insights priorisieren
- Unsicherheit und Datenqualität ausweisen

## Vorgehen
1. Lies den Input einmal nur auf Ziel, Kontext und gewünschtes Ergebnis.
2. Markiere fehlende Informationen. Wenn sie entscheidungsrelevant sind, frage nach, statt etwas zu erfinden.
3. Trenne Fakten, Annahmen, Interpretation und Empfehlung sichtbar.
4. Erstelle zuerst eine knappe Arbeitsstruktur, dann den eigentlichen Entwurf.
5. Prüfe das Ergebnis gegen die Qualitätskriterien unten.
6. Liefere bei Unsicherheit zwei Optionen: eine vorsichtige Version und eine mutigere Version mit klarer Begründung.

## Qualitätskriterien
- Bereinigungsschritte sind dokumentiert
- Ausreißer werden erklärt statt nur entfernt
- Report trennt Befund, Interpretation und Handlungsempfehlung

## Worauf du achten musst
- Datenfriedhof
- keine Zielgruppe
- Empfehlung ohne Beleg

## Rückfragen, wenn Informationen fehlen
- Was soll mit dem Ergebnis direkt passieren: senden, entscheiden, intern vorbereiten oder prüfen?
- Wer ist die Zielperson und wie viel Vorwissen hat sie?
- Welche Frist, welches Risiko oder welche geschäftliche Konsequenz hängt daran?
- Gibt es Formulierungen, Zahlen, Namen oder Zusagen, die unverändert bleiben müssen?

## Output-Format
Gib das Ergebnis in dieser Reihenfolge aus:
1. Kurzdiagnose der Ausgangslage
2. Fertiger Entwurf oder strukturierte Arbeitsvorlage
3. Annahmen und offene Punkte
4. Risiken oder rote Flaggen
5. Konkreter nächster Schritt
