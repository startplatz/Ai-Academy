---
name: meeting-zu-aufgaben
description: 'Macht aus Meetings konkrete Aufgaben, Verantwortlichkeiten, Deadlines und Follow-ups.'
---

# Meeting-zu-Aufgaben

## Einsatzmoment
Der Skill ist für Situationen gedacht, in denen Teilnehmende operativ überladen, viele Nachrichten, Meetings und Tabellen, aber wenig Entscheidungsklarheit sind. Das Ziel ist nicht, schnell generischen Text zu produzieren, sondern Druck aus der Aufgabe zu nehmen und eine belastbare Arbeitsgrundlage zu schaffen.

Typische Spannung: Nach Meetings fühlen sich alle informiert, aber niemand weiß genau, was passiert.

## Zielbild
Am Ende liegt ein Ergebnis vor, das eine Person direkt prüfen, senden, entscheiden oder weiterbearbeiten kann. Claude soll nicht so tun, als sei alles sicher. Claude soll Annahmen, Lücken, Risiken und Rückfragen sichtbar machen.

Erwartete Outputs:
- Aufgabenliste
- Verantwortliche
- Deadlines
- offene Fragen
- Follow-up-Mail
- Kurzprotokoll

## Typischer Input
- Meetingnotizen
- Transcript
- Agenda
- Chatverlauf
- Projektkontext

## Praxisprinzipien
- aus Information zuerst Zuständigkeit, Termin und Entscheidung extrahieren
- Dubletten, Unschärfe und alte Versionen sichtbar machen
- jede Zusammenfassung muss eine Arbeitsliste erzeugen, nicht nur einen schönen Text

## Expert Moves für diesen Skill
- Entscheidungen, Aufgaben und offene Fragen trennen
- Owner, Termin und Definition of Done ergänzen
- Blocker separat eskalierbar machen

## Vorgehen
1. Lies den Input einmal nur auf Ziel, Kontext und gewünschtes Ergebnis.
2. Markiere fehlende Informationen. Wenn sie entscheidungsrelevant sind, frage nach, statt etwas zu erfinden.
3. Trenne Fakten, Annahmen, Interpretation und Empfehlung sichtbar.
4. Erstelle zuerst eine knappe Arbeitsstruktur, dann den eigentlichen Entwurf.
5. Prüfe das Ergebnis gegen die Qualitätskriterien unten.
6. Liefere bei Unsicherheit zwei Optionen: eine vorsichtige Version und eine mutigere Version mit klarer Begründung.

## Qualitätskriterien
- Aufgaben sind eindeutig formuliert
- Status trennt Fakten, Blocker und nächste Schritte
- Tabellen bleiben überprüfbar und reversibel

## Worauf du achten musst
- Aufgaben ohne Verb
- Owner-Gruppe statt Person
- Entscheidungen als Diskussionspunkt versteckt

## Rückfragen, wenn Informationen fehlen
- Was soll mit dem Ergebnis direkt passieren: senden, entscheiden, intern vorbereiten oder prüfen?
- Wer ist die Zielperson und wie viel Vorwissen hat sie?
- Welche Frist, welches Risiko oder welche geschäftliche Konsequenz hängt daran?
- Gibt es Formulierungen, Zahlen, Namen oder Zusagen, die unverändert bleiben müssen?

## Output-Format
Gib das Ergebnis in dieser Reihenfolge aus:
1. Kurzdiagnose der Ausgangslage
2. Fertiger Entwurf oder strukturierte Arbeitsvorlage
3. Annahmen und offene Punkte
4. Risiken oder rote Flaggen
5. Konkreter nächster Schritt
