---
name: margin-analyzer
description: 'Analysiert Margen nach Produkten, Projekten oder Kunden und zeigt wirtschaftliche Auffälligkeiten.'
---

# Margin-Analyzer

## Wann verwenden
Nutze diesen Skill, wenn du für Geschäftsführung, Finance, Sales, Operations, Gründer den beschriebenen Arbeitsprozess mit Claude strukturiert vorbereiten oder ausführen willst.

## Aufgabe
Der Margin-Analyzer prüft Produkte, Projekte, Kunden oder Leistungen auf Marge und Wirtschaftlichkeit. Er erkennt schwache Margen, Kostentreiber und mögliche Verbesserungsfelder.

## Typischer Input
- Umsatzdaten
- Kosten
- Projektzeiten
- Produktdaten
- Kundendaten

## Vorgehen
1. Kläre Ziel, Kontext, Zielgruppe und gewünschtes Ausgabeformat.
2. Markiere fehlende Informationen als Rückfragen, statt sie zu erfinden.
3. Strukturiere den Arbeitsprozess in nachvollziehbare Schritte.
4. Erstelle einen ersten Output, der direkt weiterbearbeitet werden kann.
5. Füge einen kurzen Qualitätscheck mit Risiken, Annahmen und nächsten Schritten hinzu.

## Typischer Output
- Margenübersicht
- schwache Bereiche
- Kostentreiber
- Verbesserungsideen
- nächste Analysen

## Qualitätscheck
- Sind Annahmen, Unsicherheiten und fehlende Informationen sichtbar?
- Ist der Output für den Arbeitsalltag nutzbar und nicht nur allgemein formuliert?
- Stimmen Ton, Detailgrad und Format mit dem Zielkontext überein?
- Gibt es eine klare Empfehlung oder einen nächsten Schritt?

## Grenzen
Dieser Skill ersetzt keine Rechts-, Steuer-, Finanz- oder Datenschutzberatung. Nutze ihn zur Vorbereitung, Strukturierung und Qualitätssicherung, nicht als finale Fachentscheidung.
