---
name: decision-log
description: 'Dokumentiert Entscheidungen mit Begründung, Verantwortlichen, Auswirkungen und offenen Folgepunkten.'
---

# Decision-Log

## Wann verwenden
Nutze diesen Skill, wenn du für Projektmanagement, Produktteams, Geschäftsführung, Konzernteams, Startups den beschriebenen Arbeitsprozess mit Claude strukturiert vorbereiten oder ausführen willst.

## Aufgabe
Der Decision-Log dokumentiert Entscheidungen, Begründungen, Alternativen, Verantwortliche und Auswirkungen. Er hilft dabei, Projekt- und Managemententscheidungen nachvollziehbar zu machen.

## Typischer Input
- Meetingnotizen
- Entscheidungsunterlagen
- Projektverlauf
- Stakeholder-Kommentare

## Vorgehen
1. Kläre Ziel, Kontext, Zielgruppe und gewünschtes Ausgabeformat.
2. Markiere fehlende Informationen als Rückfragen, statt sie zu erfinden.
3. Strukturiere den Arbeitsprozess in nachvollziehbare Schritte.
4. Erstelle einen ersten Output, der direkt weiterbearbeitet werden kann.
5. Füge einen kurzen Qualitätscheck mit Risiken, Annahmen und nächsten Schritten hinzu.

## Typischer Output
- Entscheidungsliste
- Begründungen
- Verantwortliche
- Auswirkungen
- offene Folgepunkte

## Qualitätscheck
- Sind Annahmen, Unsicherheiten und fehlende Informationen sichtbar?
- Ist der Output für den Arbeitsalltag nutzbar und nicht nur allgemein formuliert?
- Stimmen Ton, Detailgrad und Format mit dem Zielkontext überein?
- Gibt es eine klare Empfehlung oder einen nächsten Schritt?

## Grenzen
Dieser Skill ersetzt keine Rechts-, Steuer-, Finanz- oder Datenschutzberatung. Nutze ihn zur Vorbereitung, Strukturierung und Qualitätssicherung, nicht als finale Fachentscheidung.
