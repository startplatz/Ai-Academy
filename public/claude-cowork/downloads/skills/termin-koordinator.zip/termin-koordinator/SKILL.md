---
name: termin-koordinator
description: 'Hilft bei Terminabstimmung, Bestätigungen und Kundenkommunikation rund um Verfügbarkeiten.'
---

# Termin-Koordinator

## Einsatzmoment
Der Skill ist für Situationen gedacht, in denen Teilnehmende zwischen Baustelle, Telefon, Angebot und Materialliste, oft mit unvollständigen Angaben sind. Das Ziel ist nicht, schnell generischen Text zu produzieren, sondern Druck aus der Aufgabe zu nehmen und eine belastbare Arbeitsgrundlage zu schaffen.

Typische Spannung: Ein Termin hängt an Menschen, Material, Zugang und Wetter.

## Zielbild
Am Ende liegt ein Ergebnis vor, das eine Person direkt prüfen, senden, entscheiden oder weiterbearbeiten kann. Claude soll nicht so tun, als sei alles sicher. Claude soll Annahmen, Lücken, Risiken und Rückfragen sichtbar machen.

Erwartete Outputs:
- Terminvorschläge
- Bestätigungsmail
- Rückfragen
- Erinnerungstext
- interne Notiz

## Typischer Input
- Kalenderdaten
- Kundenwunsch
- Verfügbarkeiten
- Ort
- Dauer

## Praxisprinzipien
- erst den Auftrag fachlich eingrenzen, dann formulieren
- Maße, Material, Ort, Termin, Zugang und Abhängigkeiten als Risiko behandeln, nicht als Nebensache
- Kundensprache einfach halten und interne Arbeitsschritte präzise genug für die Ausführung machen

## Expert Moves für diesen Skill
- Abhängigkeiten und Puffer prüfen
- Kundenkommunikation mit klaren Optionen erstellen
- Bestätigung, Erinnerung und Fallback formulieren

## Vorgehen
1. Lies den Input einmal nur auf Ziel, Kontext und gewünschtes Ergebnis.
2. Markiere fehlende Informationen. Wenn sie entscheidungsrelevant sind, frage nach, statt etwas zu erfinden.
3. Trenne Fakten, Annahmen, Interpretation und Empfehlung sichtbar.
4. Erstelle zuerst eine knappe Arbeitsstruktur, dann den eigentlichen Entwurf.
5. Prüfe das Ergebnis gegen die Qualitätskriterien unten.
6. Liefere bei Unsicherheit zwei Optionen: eine vorsichtige Version und eine mutigere Version mit klarer Begründung.

## Qualitätskriterien
- offene Rückfragen sind getrennt von Annahmen
- Leistungsumfang und Ausschlüsse sind verständlich
- nichts versprechen, was vor Ort geprüft werden muss

## Worauf du achten musst
- keine Pufferzeit
- nicht bestätigter Zugang
- Abhängigkeiten von Drittgewerken

## Rückfragen, wenn Informationen fehlen
- Was soll mit dem Ergebnis direkt passieren: senden, entscheiden, intern vorbereiten oder prüfen?
- Wer ist die Zielperson und wie viel Vorwissen hat sie?
- Welche Frist, welches Risiko oder welche geschäftliche Konsequenz hängt daran?
- Gibt es Formulierungen, Zahlen, Namen oder Zusagen, die unverändert bleiben müssen?

## Output-Format
Gib das Ergebnis in dieser Reihenfolge aus:
1. Kurzdiagnose der Ausgangslage
2. Fertiger Entwurf oder strukturierte Arbeitsvorlage
3. Annahmen und offene Punkte
4. Risiken oder rote Flaggen
5. Konkreter nächster Schritt
