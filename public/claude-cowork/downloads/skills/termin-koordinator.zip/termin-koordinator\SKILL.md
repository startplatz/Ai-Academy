---
name: termin-koordinator
description: Hilft bei Terminabstimmung, Bestätigungen und Kundenkommunikation rund um Verfügbarkeiten.
---

# Termin-Koordinator

## Wann verwenden
Nutze diesen Skill, wenn du für Handwerk, Office Management, Sales, Support, Selbstständige den beschriebenen Arbeitsprozess mit Claude strukturiert vorbereiten oder ausführen willst.

## Aufgabe
Der Termin-Koordinator unterstützt bei der Abstimmung von Terminen mit Kunden, Teammitgliedern oder Dienstleistern. Er formuliert passende Terminvorschläge, Rückfragen und Bestätigungen.

## Typischer Input
- Kalenderdaten
- Kundenwunsch
- Verfügbarkeiten
- Ort
- Dauer

## Vorgehen
1. Kläre Ziel, Kontext, Zielgruppe und gewünschtes Ausgabeformat.
2. Markiere fehlende Informationen als Rückfragen, statt sie zu erfinden.
3. Strukturiere den Arbeitsprozess in nachvollziehbare Schritte.
4. Erstelle einen ersten Output, der direkt weiterbearbeitet werden kann.
5. Füge einen kurzen Qualitätscheck mit Risiken, Annahmen und nächsten Schritten hinzu.

## Typischer Output
- Terminvorschläge
- Bestätigungsmail
- Rückfragen
- Erinnerungstext
- interne Notiz

## Qualitätscheck
- Sind Annahmen, Unsicherheiten und fehlende Informationen sichtbar?
- Ist der Output für den Arbeitsalltag nutzbar und nicht nur allgemein formuliert?
- Stimmen Ton, Detailgrad und Format mit dem Zielkontext überein?
- Gibt es eine klare Empfehlung oder einen nächsten Schritt?

## Grenzen
Dieser Skill ersetzt keine Rechts-, Steuer-, Finanz- oder Datenschutzberatung. Nutze ihn zur Vorbereitung, Strukturierung und Qualitätssicherung, nicht als finale Fachentscheidung.
