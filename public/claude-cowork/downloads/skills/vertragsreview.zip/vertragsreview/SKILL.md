---
name: vertragsreview
description: 'Strukturiert Verträge, markiert auffällige Klauseln, offene Punkte und Fragen für die rechtliche Prüfung.'
---

# Vertragsreview

## Einsatzmoment
Der Skill ist für Situationen gedacht, in denen Teilnehmende unsicher, weil Verträge wichtig sind, aber juristische Bewertung nicht improvisiert werden darf sind. Das Ziel ist nicht, schnell generischen Text zu produzieren, sondern Druck aus der Aufgabe zu nehmen und eine belastbare Arbeitsgrundlage zu schaffen.

Typische Spannung: Der Vertrag ist wichtig, aber Claude darf nicht Rechtsberatung simulieren.

## Zielbild
Am Ende liegt ein Ergebnis vor, das eine Person direkt prüfen, senden, entscheiden oder weiterbearbeiten kann. Claude soll nicht so tun, als sei alles sicher. Claude soll Annahmen, Lücken, Risiken und Rückfragen sichtbar machen.

Erwartete Outputs:
- Review-Zusammenfassung
- Risiken
- Rückfragen

## Typischer Input
- Vertrag
- Prüfziel
- Kontext

## Praxisprinzipien
- nicht beraten, sondern Struktur, Risiken, Unklarheiten und Rückfragen vorbereiten
- Klauseln immer mit Kontext, Konsequenz und Verhandlungsfrage betrachten
- rote Flaggen markieren, ohne rechtliche Schlussfolgerungen als Gewissheit auszugeben

## Expert Moves für diesen Skill
- Klauseltypen und wirtschaftliche Konsequenzen sortieren
- unklare Pflichten und Fristen markieren
- Rückfragen für Jurist oder Gegenpartei vorbereiten

## Vorgehen
1. Lies den Input einmal nur auf Ziel, Kontext und gewünschtes Ergebnis.
2. Markiere fehlende Informationen. Wenn sie entscheidungsrelevant sind, frage nach, statt etwas zu erfinden.
3. Trenne Fakten, Annahmen, Interpretation und Empfehlung sichtbar.
4. Erstelle zuerst eine knappe Arbeitsstruktur, dann den eigentlichen Entwurf.
5. Prüfe das Ergebnis gegen die Qualitätskriterien unten.
6. Liefere bei Unsicherheit zwei Optionen: eine vorsichtige Version und eine mutigere Version mit klarer Begründung.

## Qualitätskriterien
- juristische Prüfung wird nicht ersetzt
- Risiken sind priorisiert und begründet
- Rückfragen sind für externe Beratung sofort nutzbar

## Worauf du achten musst
- rechtliche Bewertung als Gewissheit
- fehlender Kontext
- versteckte Kündigungs- oder Haftungslogik

## Rückfragen, wenn Informationen fehlen
- Was soll mit dem Ergebnis direkt passieren: senden, entscheiden, intern vorbereiten oder prüfen?
- Wer ist die Zielperson und wie viel Vorwissen hat sie?
- Welche Frist, welches Risiko oder welche geschäftliche Konsequenz hängt daran?
- Gibt es Formulierungen, Zahlen, Namen oder Zusagen, die unverändert bleiben müssen?

## Output-Format
Gib das Ergebnis in dieser Reihenfolge aus:
1. Kurzdiagnose der Ausgangslage
2. Fertiger Entwurf oder strukturierte Arbeitsvorlage
3. Annahmen und offene Punkte
4. Risiken oder rote Flaggen
5. Konkreter nächster Schritt
