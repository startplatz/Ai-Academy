---
name: follow-up-schreiber
description: 'Schreibt professionelle Follow-up-Mails nach Kundengesprächen, Angeboten oder Demos.'
---

# Follow-up-Schreiber

## Einsatzmoment
Der Skill ist für Situationen gedacht, in denen Teilnehmende Pipeline-Druck, verstreute Gesprächsnotizen und Sorge, echte Chancen falsch einzuschätzen sind. Das Ziel ist nicht, schnell generischen Text zu produzieren, sondern Druck aus der Aufgabe zu nehmen und eine belastbare Arbeitsgrundlage zu schaffen.

Typische Spannung: Nach dem Gespräch muss Momentum entstehen, nicht nur Höflichkeit.

## Zielbild
Am Ende liegt ein Ergebnis vor, das eine Person direkt prüfen, senden, entscheiden oder weiterbearbeiten kann. Claude soll nicht so tun, als sei alles sicher. Claude soll Annahmen, Lücken, Risiken und Rückfragen sichtbar machen.

Erwartete Outputs:
- Follow-up-Mail
- Kurzfassung
- Reminder-Variante
- nächster CTA
- interne Notiz

## Typischer Input
- Gesprächsnotizen
- Angebot
- bisherige Kommunikation
- gewünschter nächster Schritt

## Praxisprinzipien
- jede Empfehlung an Bedarf, Timing, Budget, Entscheidungsweg und nächsten Schritt koppeln
- CRM-Hygiene als Führungsinstrument behandeln: Wenn es nicht im CRM steht, existiert es praktisch nicht
- Follow-ups mit konkretem Anlass schreiben, nicht als höfliches Nachfassen ohne Substanz

## Expert Moves für diesen Skill
- Gesprächsbezug und Wertversprechen wieder aufnehmen
- Entscheidungen und offene Punkte dokumentieren
- konkreten nächsten Schritt mit Datum anbieten

## Vorgehen
1. Lies den Input einmal nur auf Ziel, Kontext und gewünschtes Ergebnis.
2. Markiere fehlende Informationen. Wenn sie entscheidungsrelevant sind, frage nach, statt etwas zu erfinden.
3. Trenne Fakten, Annahmen, Interpretation und Empfehlung sichtbar.
4. Erstelle zuerst eine knappe Arbeitsstruktur, dann den eigentlichen Entwurf.
5. Prüfe das Ergebnis gegen die Qualitätskriterien unten.
6. Liefere bei Unsicherheit zwei Optionen: eine vorsichtige Version und eine mutigere Version mit klarer Begründung.

## Qualitätskriterien
- Next Step plus Datum ist enthalten
- Deal-Risiken und fehlende Informationen sind sichtbar
- Ton ist hilfreich, spezifisch und nicht drängend

## Worauf du achten musst
- generisches Danke
- kein Anlass
- nächster Schritt ohne Verbindlichkeit

## Rückfragen, wenn Informationen fehlen
- Was soll mit dem Ergebnis direkt passieren: senden, entscheiden, intern vorbereiten oder prüfen?
- Wer ist die Zielperson und wie viel Vorwissen hat sie?
- Welche Frist, welches Risiko oder welche geschäftliche Konsequenz hängt daran?
- Gibt es Formulierungen, Zahlen, Namen oder Zusagen, die unverändert bleiben müssen?

## Output-Format
Gib das Ergebnis in dieser Reihenfolge aus:
1. Kurzdiagnose der Ausgangslage
2. Fertiger Entwurf oder strukturierte Arbeitsvorlage
3. Annahmen und offene Punkte
4. Risiken oder rote Flaggen
5. Konkreter nächster Schritt
