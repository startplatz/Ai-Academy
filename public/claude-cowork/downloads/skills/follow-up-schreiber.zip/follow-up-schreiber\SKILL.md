---
name: follow-up-schreiber
description: Schreibt professionelle Follow-up-Mails nach Kundengesprächen, Angeboten oder Demos.
---

# Follow-up-Schreiber

## Wann verwenden
Nutze diesen Skill, wenn du für Sales, Account Management, Selbstständige, Agenturen, Beratung den beschriebenen Arbeitsprozess mit Claude strukturiert vorbereiten oder ausführen willst.

## Aufgabe
Der Follow-up-Schreiber erstellt passende Follow-up-Mails nach Gesprächen, Angeboten, Demos oder längerer Funkstille. Er kann Tonalität, Dringlichkeit und gewünschtes Ziel berücksichtigen.

## Typischer Input
- Gesprächsnotizen
- Angebot
- bisherige Kommunikation
- gewünschter nächster Schritt

## Vorgehen
1. Kläre Ziel, Kontext, Zielgruppe und gewünschtes Ausgabeformat.
2. Markiere fehlende Informationen als Rückfragen, statt sie zu erfinden.
3. Strukturiere den Arbeitsprozess in nachvollziehbare Schritte.
4. Erstelle einen ersten Output, der direkt weiterbearbeitet werden kann.
5. Füge einen kurzen Qualitätscheck mit Risiken, Annahmen und nächsten Schritten hinzu.

## Typischer Output
- Follow-up-Mail
- Kurzfassung
- Reminder-Variante
- nächster CTA
- interne Notiz

## Qualitätscheck
- Sind Annahmen, Unsicherheiten und fehlende Informationen sichtbar?
- Ist der Output für den Arbeitsalltag nutzbar und nicht nur allgemein formuliert?
- Stimmen Ton, Detailgrad und Format mit dem Zielkontext überein?
- Gibt es eine klare Empfehlung oder einen nächsten Schritt?

## Grenzen
Dieser Skill ersetzt keine Rechts-, Steuer-, Finanz- oder Datenschutzberatung. Nutze ihn zur Vorbereitung, Strukturierung und Qualitätssicherung, nicht als finale Fachentscheidung.
