---
name: content-repurposer
description: Verwandelt lange Inhalte in viele verwertbare Contentformate für Social Media, Newsletter und Website.
---

# Content-Repurposer

## Wann verwenden
Nutze diesen Skill, wenn du für Marketing, Creator, Agenturen, Gründer, Trainer, Kommunikationsteams den beschriebenen Arbeitsprozess mit Claude strukturiert vorbereiten oder ausführen willst.

## Aufgabe
Der Content-Repurposer verwandelt lange Inhalte in mehrere kurze Formate. Aus einem Webinar, Podcast, Workshop, Blogartikel oder Transkript entstehen Posts, Newsletter, Shorts-Ideen, Landingpage-Abschnitte oder interne Wissensbausteine.

## Typischer Input
- Webinar-Transkript
- Podcast-Transkript
- Blogartikel
- Workshop-Material
- Präsentation

## Vorgehen
1. Kläre Ziel, Kontext, Zielgruppe und gewünschtes Ausgabeformat.
2. Markiere fehlende Informationen als Rückfragen, statt sie zu erfinden.
3. Strukturiere den Arbeitsprozess in nachvollziehbare Schritte.
4. Erstelle einen ersten Output, der direkt weiterbearbeitet werden kann.
5. Füge einen kurzen Qualitätscheck mit Risiken, Annahmen und nächsten Schritten hinzu.

## Typischer Output
- LinkedIn-Posts
- Newsletter
- Shortform-Ideen
- Social Captions
- Contentplan
- Website-Abschnitte

## Qualitätscheck
- Sind Annahmen, Unsicherheiten und fehlende Informationen sichtbar?
- Ist der Output für den Arbeitsalltag nutzbar und nicht nur allgemein formuliert?
- Stimmen Ton, Detailgrad und Format mit dem Zielkontext überein?
- Gibt es eine klare Empfehlung oder einen nächsten Schritt?

## Grenzen
Dieser Skill ersetzt keine Rechts-, Steuer-, Finanz- oder Datenschutzberatung. Nutze ihn zur Vorbereitung, Strukturierung und Qualitätssicherung, nicht als finale Fachentscheidung.
