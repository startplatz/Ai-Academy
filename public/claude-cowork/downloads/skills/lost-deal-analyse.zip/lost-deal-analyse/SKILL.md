---
name: lost-deal-analyse
description: 'Analysiert verlorene Deals und erkennt Muster, Absagegründe und Verbesserungspotenziale.'
---

# Lost-Deal-Analyse

## Wann verwenden
Nutze diesen Skill, wenn du für Sales, Geschäftsführung, Gründer, Marketing, Customer Success den beschriebenen Arbeitsprozess mit Claude strukturiert vorbereiten oder ausführen willst.

## Aufgabe
Die Lost-Deal-Analyse untersucht verlorene Deals, Absagegründe und Muster in der Pipeline. Sie hilft dabei, wiederkehrende Hindernisse und Verbesserungsmöglichkeiten zu erkennen.

## Typischer Input
- verlorene Deals
- Absagegründe
- Gesprächsnotizen
- Angebote
- CRM-Daten

## Vorgehen
1. Kläre Ziel, Kontext, Zielgruppe und gewünschtes Ausgabeformat.
2. Markiere fehlende Informationen als Rückfragen, statt sie zu erfinden.
3. Strukturiere den Arbeitsprozess in nachvollziehbare Schritte.
4. Erstelle einen ersten Output, der direkt weiterbearbeitet werden kann.
5. Füge einen kurzen Qualitätscheck mit Risiken, Annahmen und nächsten Schritten hinzu.

## Typischer Output
- Musteranalyse
- häufige Absagegründe
- Verbesserungsvorschläge
- Hypothesen
- nächste Maßnahmen

## Qualitätscheck
- Sind Annahmen, Unsicherheiten und fehlende Informationen sichtbar?
- Ist der Output für den Arbeitsalltag nutzbar und nicht nur allgemein formuliert?
- Stimmen Ton, Detailgrad und Format mit dem Zielkontext überein?
- Gibt es eine klare Empfehlung oder einen nächsten Schritt?

## Grenzen
Dieser Skill ersetzt keine Rechts-, Steuer-, Finanz- oder Datenschutzberatung. Nutze ihn zur Vorbereitung, Strukturierung und Qualitätssicherung, nicht als finale Fachentscheidung.
