---
name: performance-analyst
description: 'Analysiert Kampagnendaten und übersetzt Zahlen in verständliche Erkenntnisse und nächste Schritte.'
---

# Performance-Analyst

## Wann verwenden
Nutze diesen Skill, wenn du für Marketing, Geschäftsführung, Performance Teams, Agenturen, Gründer den beschriebenen Arbeitsprozess mit Claude strukturiert vorbereiten oder ausführen willst.

## Aufgabe
Der Performance-Analyst interpretiert Marketing- oder Kampagnendaten und leitet verständliche Erkenntnisse und nächste Maßnahmen ab. Er kann Zahlen in Handlungsempfehlungen übersetzen.

## Typischer Input
- Kampagnendaten
- Analytics-Export
- Ad-Daten
- Newsletter-Kennzahlen
- Zielwerte

## Vorgehen
1. Kläre Ziel, Kontext, Zielgruppe und gewünschtes Ausgabeformat.
2. Markiere fehlende Informationen als Rückfragen, statt sie zu erfinden.
3. Strukturiere den Arbeitsprozess in nachvollziehbare Schritte.
4. Erstelle einen ersten Output, der direkt weiterbearbeitet werden kann.
5. Füge einen kurzen Qualitätscheck mit Risiken, Annahmen und nächsten Schritten hinzu.

## Typischer Output
- Ergebniszusammenfassung
- Auffälligkeiten
- Hypothesen
- Handlungsempfehlungen
- nächste Tests

## Qualitätscheck
- Sind Annahmen, Unsicherheiten und fehlende Informationen sichtbar?
- Ist der Output für den Arbeitsalltag nutzbar und nicht nur allgemein formuliert?
- Stimmen Ton, Detailgrad und Format mit dem Zielkontext überein?
- Gibt es eine klare Empfehlung oder einen nächsten Schritt?

## Grenzen
Dieser Skill ersetzt keine Rechts-, Steuer-, Finanz- oder Datenschutzberatung. Nutze ihn zur Vorbereitung, Strukturierung und Qualitätssicherung, nicht als finale Fachentscheidung.
