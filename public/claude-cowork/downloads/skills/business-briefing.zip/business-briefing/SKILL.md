---
name: business-briefing
description: 'Erstellt ein kompaktes Business-Briefing aus Zahlen, Terminen, Pipeline, Aufgaben und offenen Entscheidungen.'
---

# Business-Briefing

## Einsatzmoment
Der Skill ist für Situationen gedacht, in denen Teilnehmende mit vielen strategischen Baustellen, wenig Zeit und hoher emotionaler Fallhöhe sind. Das Ziel ist nicht, schnell generischen Text zu produzieren, sondern Druck aus der Aufgabe zu nehmen und eine belastbare Arbeitsgrundlage zu schaffen.

Typische Spannung: Viele Signale treffen auf wenig Zeit und müssen entscheidbar werden.

## Zielbild
Am Ende liegt ein Ergebnis vor, das eine Person direkt prüfen, senden, entscheiden oder weiterbearbeiten kann. Claude soll nicht so tun, als sei alles sicher. Claude soll Annahmen, Lücken, Risiken und Rückfragen sichtbar machen.

Erwartete Outputs:
- Tages- oder Wochenbriefing
- Prioritäten
- offene Entscheidungen
- Risiken
- nächste Schritte

## Typischer Input
- Kalender
- E-Mails
- CRM
- Finanzdaten
- Aufgabenlisten
- Projektstände

## Praxisprinzipien
- zwischen Signal, Meinung und Entscheidung trennen
- Investoren-, Team- und Kundenperspektive bewusst unterschiedlich formulieren
- jede Empfehlung braucht Trade-off, Risiko und nächsten Test

## Expert Moves für diesen Skill
- Markt, Kunden, Team, Finanzen und Produkt in Signale clustern
- Top-Entscheidungen und Risiken extrahieren
- nächste Experimente definieren

## Vorgehen
1. Lies den Input einmal nur auf Ziel, Kontext und gewünschtes Ergebnis.
2. Markiere fehlende Informationen. Wenn sie entscheidungsrelevant sind, frage nach, statt etwas zu erfinden.
3. Trenne Fakten, Annahmen, Interpretation und Empfehlung sichtbar.
4. Erstelle zuerst eine knappe Arbeitsstruktur, dann den eigentlichen Entwurf.
5. Prüfe das Ergebnis gegen die Qualitätskriterien unten.
6. Liefere bei Unsicherheit zwei Optionen: eine vorsichtige Version und eine mutigere Version mit klarer Begründung.

## Qualitätskriterien
- knappe Executive-Logik statt langer Erklärungen
- Annahmen und Gegenargumente sind sichtbar
- Entscheidung ist mit Handlung und Lernziel verbunden

## Worauf du achten musst
- News-Sammlung statt Briefing
- keine Entscheidungsebene
- fehlende Gegenargumente

## Rückfragen, wenn Informationen fehlen
- Was soll mit dem Ergebnis direkt passieren: senden, entscheiden, intern vorbereiten oder prüfen?
- Wer ist die Zielperson und wie viel Vorwissen hat sie?
- Welche Frist, welches Risiko oder welche geschäftliche Konsequenz hängt daran?
- Gibt es Formulierungen, Zahlen, Namen oder Zusagen, die unverändert bleiben müssen?

## Output-Format
Gib das Ergebnis in dieser Reihenfolge aus:
1. Kurzdiagnose der Ausgangslage
2. Fertiger Entwurf oder strukturierte Arbeitsvorlage
3. Annahmen und offene Punkte
4. Risiken oder rote Flaggen
5. Konkreter nächster Schritt
