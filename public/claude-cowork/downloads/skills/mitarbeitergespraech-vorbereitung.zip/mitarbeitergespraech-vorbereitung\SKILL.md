---
name: mitarbeitergespraech-vorbereitung
description: Strukturiert Feedback, Ziele und Gesprächsfragen für Mitarbeitergespräche.
---

# Mitarbeitergespräch-Vorbereitung

## Wann verwenden
Nutze diesen Skill, wenn du für HR, Teamleitung, Geschäftsführung, People Management den beschriebenen Arbeitsprozess mit Claude strukturiert vorbereiten oder ausführen willst.

## Aufgabe
Die Mitarbeitergespräch-Vorbereitung strukturiert Feedback, Ziele, offene Themen und Gesprächsfragen. Sie hilft dabei, Gespräche fair, konkret und zielorientiert vorzubereiten.

## Typischer Input
- bisherige Ziele
- Feedbacknotizen
- Leistungsbeispiele
- offene Themen
- Entwicklungswünsche

## Vorgehen
1. Kläre Ziel, Kontext, Zielgruppe und gewünschtes Ausgabeformat.
2. Markiere fehlende Informationen als Rückfragen, statt sie zu erfinden.
3. Strukturiere den Arbeitsprozess in nachvollziehbare Schritte.
4. Erstelle einen ersten Output, der direkt weiterbearbeitet werden kann.
5. Füge einen kurzen Qualitätscheck mit Risiken, Annahmen und nächsten Schritten hinzu.

## Typischer Output
- Gesprächsstruktur
- Feedbackpunkte
- Zielformulierungen
- Fragen
- Dokumentationsvorlage

## Qualitätscheck
- Sind Annahmen, Unsicherheiten und fehlende Informationen sichtbar?
- Ist der Output für den Arbeitsalltag nutzbar und nicht nur allgemein formuliert?
- Stimmen Ton, Detailgrad und Format mit dem Zielkontext überein?
- Gibt es eine klare Empfehlung oder einen nächsten Schritt?

## Grenzen
Dieser Skill ersetzt keine Rechts-, Steuer-, Finanz- oder Datenschutzberatung. Nutze ihn zur Vorbereitung, Strukturierung und Qualitätssicherung, nicht als finale Fachentscheidung.
