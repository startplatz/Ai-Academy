---
name: vergleich-zweier-vertragsversionen
description: 'Vergleicht zwei Vertragsfassungen und macht inhaltliche, wirtschaftliche und formale Unterschiede sichtbar.'
---

# Vergleich zweier Vertragsversionen

## Einsatzmoment
Der Skill ist für Situationen gedacht, in denen Teilnehmende unsicher, weil Verträge wichtig sind, aber juristische Bewertung nicht improvisiert werden darf sind. Das Ziel ist nicht, schnell generischen Text zu produzieren, sondern Druck aus der Aufgabe zu nehmen und eine belastbare Arbeitsgrundlage zu schaffen.

Typische Spannung: Änderungen zwischen Versionen sind leicht zu übersehen.

## Zielbild
Am Ende liegt ein Ergebnis vor, das eine Person direkt prüfen, senden, entscheiden oder weiterbearbeiten kann. Claude soll nicht so tun, als sei alles sicher. Claude soll Annahmen, Lücken, Risiken und Rückfragen sichtbar machen.

Erwartete Outputs:
- Aenderungsliste
- Risiken
- offene Entscheidungen

## Typischer Input
- Version A
- Version B
- Prüffokus

## Praxisprinzipien
- nicht beraten, sondern Struktur, Risiken, Unklarheiten und Rückfragen vorbereiten
- Klauseln immer mit Kontext, Konsequenz und Verhandlungsfrage betrachten
- rote Flaggen markieren, ohne rechtliche Schlussfolgerungen als Gewissheit auszugeben

## Expert Moves für diesen Skill
- inhaltliche Änderungen, Streichungen und neue Pflichten clustern
- wirtschaftliche Auswirkung priorisieren
- Rückfragen je Änderung formulieren

## Vorgehen
1. Lies den Input einmal nur auf Ziel, Kontext und gewünschtes Ergebnis.
2. Markiere fehlende Informationen. Wenn sie entscheidungsrelevant sind, frage nach, statt etwas zu erfinden.
3. Trenne Fakten, Annahmen, Interpretation und Empfehlung sichtbar.
4. Erstelle zuerst eine knappe Arbeitsstruktur, dann den eigentlichen Entwurf.
5. Prüfe das Ergebnis gegen die Qualitätskriterien unten.
6. Liefere bei Unsicherheit zwei Optionen: eine vorsichtige Version und eine mutigere Version mit klarer Begründung.

## Qualitätskriterien
- juristische Prüfung wird nicht ersetzt
- Risiken sind priorisiert und begründet
- Rückfragen sind für externe Beratung sofort nutzbar

## Worauf du achten musst
- Formatänderungen als Inhalt werten
- kleine Wörter übersehen
- keine Versionsreferenz

## Rückfragen, wenn Informationen fehlen
- Was soll mit dem Ergebnis direkt passieren: senden, entscheiden, intern vorbereiten oder prüfen?
- Wer ist die Zielperson und wie viel Vorwissen hat sie?
- Welche Frist, welches Risiko oder welche geschäftliche Konsequenz hängt daran?
- Gibt es Formulierungen, Zahlen, Namen oder Zusagen, die unverändert bleiben müssen?

## Output-Format
Gib das Ergebnis in dieser Reihenfolge aus:
1. Kurzdiagnose der Ausgangslage
2. Fertiger Entwurf oder strukturierte Arbeitsvorlage
3. Annahmen und offene Punkte
4. Risiken oder rote Flaggen
5. Konkreter nächster Schritt
