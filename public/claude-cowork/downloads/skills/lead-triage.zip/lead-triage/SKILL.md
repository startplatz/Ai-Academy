---
name: lead-triage
description: 'Priorisiert Leads nach Potenzial, Fit und Dringlichkeit und schlägt nächste Schritte vor.'
---

# Lead-Triage

## Wann verwenden
Nutze diesen Skill, wenn du für Sales, Gründer, Agenturen, B2B-Teams, Customer Success den beschriebenen Arbeitsprozess mit Claude strukturiert vorbereiten oder ausführen willst.

## Aufgabe
Die Lead-Triage sortiert eingehende Leads nach Fit, Potenzial, Dringlichkeit und nächstem sinnvollen Schritt. Sie hilft Sales-Teams und Gründern dabei, relevante Chancen schneller zu erkennen.

## Typischer Input
- Leadliste
- Formularanfragen
- CRM-Daten
- E-Mail-Verläufe
- Zielkundenprofil

## Vorgehen
1. Kläre Ziel, Kontext, Zielgruppe und gewünschtes Ausgabeformat.
2. Markiere fehlende Informationen als Rückfragen, statt sie zu erfinden.
3. Strukturiere den Arbeitsprozess in nachvollziehbare Schritte.
4. Erstelle einen ersten Output, der direkt weiterbearbeitet werden kann.
5. Füge einen kurzen Qualitätscheck mit Risiken, Annahmen und nächsten Schritten hinzu.

## Typischer Output
- Lead-Priorisierung
- Fit-Einschätzung
- nächste Schritte
- Rückfragen
- Kontaktvorschlag

## Qualitätscheck
- Sind Annahmen, Unsicherheiten und fehlende Informationen sichtbar?
- Ist der Output für den Arbeitsalltag nutzbar und nicht nur allgemein formuliert?
- Stimmen Ton, Detailgrad und Format mit dem Zielkontext überein?
- Gibt es eine klare Empfehlung oder einen nächsten Schritt?

## Grenzen
Dieser Skill ersetzt keine Rechts-, Steuer-, Finanz- oder Datenschutzberatung. Nutze ihn zur Vorbereitung, Strukturierung und Qualitätssicherung, nicht als finale Fachentscheidung.
