---
name: crm-hygiene-agent
description: Prüft CRM-Daten auf Lücken, Dubletten, veraltete Deals und unklare nächste Schritte.
---

# CRM-Hygiene-Agent

## Wann verwenden
Nutze diesen Skill, wenn du für Sales, CRM-Management, Geschäftsführung, Operations, Customer Success den beschriebenen Arbeitsprozess mit Claude strukturiert vorbereiten oder ausführen willst.

## Aufgabe
Der CRM-Hygiene-Agent prüft CRM-Daten auf fehlende Felder, doppelte Kontakte, veraltete Deals, inkonsistente Status und unklare nächste Schritte.

## Typischer Input
- CRM-Export
- Leadliste
- Deal-Daten
- Kontaktfelder
- Pipeline-Status

## Vorgehen
1. Kläre Ziel, Kontext, Zielgruppe und gewünschtes Ausgabeformat.
2. Markiere fehlende Informationen als Rückfragen, statt sie zu erfinden.
3. Strukturiere den Arbeitsprozess in nachvollziehbare Schritte.
4. Erstelle einen ersten Output, der direkt weiterbearbeitet werden kann.
5. Füge einen kurzen Qualitätscheck mit Risiken, Annahmen und nächsten Schritten hinzu.

## Typischer Output
- Datenqualitätsbericht
- fehlende Felder
- Dublettenhinweise
- veraltete Deals
- empfohlene Korrekturen

## Qualitätscheck
- Sind Annahmen, Unsicherheiten und fehlende Informationen sichtbar?
- Ist der Output für den Arbeitsalltag nutzbar und nicht nur allgemein formuliert?
- Stimmen Ton, Detailgrad und Format mit dem Zielkontext überein?
- Gibt es eine klare Empfehlung oder einen nächsten Schritt?

## Grenzen
Dieser Skill ersetzt keine Rechts-, Steuer-, Finanz- oder Datenschutzberatung. Nutze ihn zur Vorbereitung, Strukturierung und Qualitätssicherung, nicht als finale Fachentscheidung.
