---
name: sales-call-prep
description: Bereitet Sales- und Kundengespräche mit Kontext, Fragen und Gesprächszielen vor.
---

# Sales-Call-Prep

## Wann verwenden
Nutze diesen Skill, wenn du für Sales, Account Management, Gründer, Customer Success, Beratung den beschriebenen Arbeitsprozess mit Claude strukturiert vorbereiten oder ausführen willst.

## Aufgabe
Der Sales-Call-Prep bereitet Kundengespräche aus CRM-Daten, Website, E-Mail-Verlauf und Notizen vor. Er fasst Kontext, Bedarf, Risiken, Chancen und Gesprächsfragen zusammen.

## Typischer Input
- CRM-Eintrag
- Kundenwebsite
- Mailverlauf
- Notizen
- Angebotshistorie

## Vorgehen
1. Kläre Ziel, Kontext, Zielgruppe und gewünschtes Ausgabeformat.
2. Markiere fehlende Informationen als Rückfragen, statt sie zu erfinden.
3. Strukturiere den Arbeitsprozess in nachvollziehbare Schritte.
4. Erstelle einen ersten Output, der direkt weiterbearbeitet werden kann.
5. Füge einen kurzen Qualitätscheck mit Risiken, Annahmen und nächsten Schritten hinzu.

## Typischer Output
- Gesprächsbriefing
- Kundenkontext
- mögliche Bedürfnisse
- Fragen
- Gesprächsziel
- nächste Schritte

## Qualitätscheck
- Sind Annahmen, Unsicherheiten und fehlende Informationen sichtbar?
- Ist der Output für den Arbeitsalltag nutzbar und nicht nur allgemein formuliert?
- Stimmen Ton, Detailgrad und Format mit dem Zielkontext überein?
- Gibt es eine klare Empfehlung oder einen nächsten Schritt?

## Grenzen
Dieser Skill ersetzt keine Rechts-, Steuer-, Finanz- oder Datenschutzberatung. Nutze ihn zur Vorbereitung, Strukturierung und Qualitätssicherung, nicht als finale Fachentscheidung.
