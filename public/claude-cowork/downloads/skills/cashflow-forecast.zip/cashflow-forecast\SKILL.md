---
name: cashflow-forecast
description: Erstellt eine einfache Cashflow-Übersicht mit offenen Rechnungen, Risiken und Liquiditätsvorschau.
---

# Cashflow-Forecast

## Wann verwenden
Nutze diesen Skill, wenn du für Selbstständige, Geschäftsführung, Finance, Office Management, Gründer den beschriebenen Arbeitsprozess mit Claude strukturiert vorbereiten oder ausführen willst.

## Aufgabe
Der Cashflow-Forecast erstellt aus Einnahmen, Ausgaben, offenen Rechnungen und geplanten Zahlungen eine einfache Liquiditätsvorschau. Er kann Engpässe, Risiken und wichtige Zahlungszeitpunkte sichtbar machen.

## Typischer Input
- Einnahmen
- Ausgaben
- offene Rechnungen
- geplante Zahlungen
- Kontostand

## Vorgehen
1. Kläre Ziel, Kontext, Zielgruppe und gewünschtes Ausgabeformat.
2. Markiere fehlende Informationen als Rückfragen, statt sie zu erfinden.
3. Strukturiere den Arbeitsprozess in nachvollziehbare Schritte.
4. Erstelle einen ersten Output, der direkt weiterbearbeitet werden kann.
5. Füge einen kurzen Qualitätscheck mit Risiken, Annahmen und nächsten Schritten hinzu.

## Typischer Output
- Liquiditätsübersicht
- 30-Tage-Vorschau
- Engpasshinweise
- offene Zahlungen
- Handlungsempfehlungen

## Qualitätscheck
- Sind Annahmen, Unsicherheiten und fehlende Informationen sichtbar?
- Ist der Output für den Arbeitsalltag nutzbar und nicht nur allgemein formuliert?
- Stimmen Ton, Detailgrad und Format mit dem Zielkontext überein?
- Gibt es eine klare Empfehlung oder einen nächsten Schritt?

## Grenzen
Dieser Skill ersetzt keine Rechts-, Steuer-, Finanz- oder Datenschutzberatung. Nutze ihn zur Vorbereitung, Strukturierung und Qualitätssicherung, nicht als finale Fachentscheidung.
