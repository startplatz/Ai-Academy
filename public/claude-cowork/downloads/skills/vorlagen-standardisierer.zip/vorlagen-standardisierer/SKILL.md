---
name: vorlagen-standardisierer
description: 'Standardisiert Texte und Dokumente nach Struktur, Tonalität und internen Vorgaben.'
---

# Vorlagen-Standardisierer

## Wann verwenden
Nutze diesen Skill, wenn du für Office, HR, Marketing, Sales, Verwaltung, Projektmanagement den beschriebenen Arbeitsprozess mit Claude strukturiert vorbereiten oder ausführen willst.

## Aufgabe
Der Vorlagen-Standardisierer bringt Texte, Dokumente und Vorlagen in ein einheitliches Format. Er achtet auf Tonalität, Struktur, Pflichtfelder und interne Standards.

## Typischer Input
- bestehende Vorlage
- neuer Text
- Styleguide
- Pflichtfelder
- Beispieltext

## Vorgehen
1. Kläre Ziel, Kontext, Zielgruppe und gewünschtes Ausgabeformat.
2. Markiere fehlende Informationen als Rückfragen, statt sie zu erfinden.
3. Strukturiere den Arbeitsprozess in nachvollziehbare Schritte.
4. Erstelle einen ersten Output, der direkt weiterbearbeitet werden kann.
5. Füge einen kurzen Qualitätscheck mit Risiken, Annahmen und nächsten Schritten hinzu.

## Typischer Output
- standardisierte Vorlage
- überarbeiteter Text
- Formatvorschlag
- Checkliste
- Varianten

## Qualitätscheck
- Sind Annahmen, Unsicherheiten und fehlende Informationen sichtbar?
- Ist der Output für den Arbeitsalltag nutzbar und nicht nur allgemein formuliert?
- Stimmen Ton, Detailgrad und Format mit dem Zielkontext überein?
- Gibt es eine klare Empfehlung oder einen nächsten Schritt?

## Grenzen
Dieser Skill ersetzt keine Rechts-, Steuer-, Finanz- oder Datenschutzberatung. Nutze ihn zur Vorbereitung, Strukturierung und Qualitätssicherung, nicht als finale Fachentscheidung.
