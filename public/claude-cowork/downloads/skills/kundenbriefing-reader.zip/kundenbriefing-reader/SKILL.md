---
name: kundenbriefing-reader
description: 'Macht aus unübersichtlicher Kundenkommunikation ein klares Projektbriefing mit Anforderungen, offenen Fragen und nächsten Schritten.'
---

# Kundenbriefing-Reader

## Wann verwenden
Nutze diesen Skill, wenn du für Agenturen, Freelancer, Berater, Projektmanager, Dienstleister den beschriebenen Arbeitsprozess mit Claude strukturiert vorbereiten oder ausführen willst.

## Aufgabe
Der Kundenbriefing-Reader analysiert Kundenmails, Dokumente, Notizen und Anhänge und erstellt daraus ein klares Projektbriefing. Er fasst Ziele, Anforderungen, offene Fragen, Risiken und nächste Schritte zusammen.

## Typischer Input
- Kundenmail
- Briefingdokument
- alte Kommunikation
- Meetingnotizen
- Anhänge

## Vorgehen
1. Kläre Ziel, Kontext, Zielgruppe und gewünschtes Ausgabeformat.
2. Markiere fehlende Informationen als Rückfragen, statt sie zu erfinden.
3. Strukturiere den Arbeitsprozess in nachvollziehbare Schritte.
4. Erstelle einen ersten Output, der direkt weiterbearbeitet werden kann.
5. Füge einen kurzen Qualitätscheck mit Risiken, Annahmen und nächsten Schritten hinzu.

## Typischer Output
- Projektziel
- Anforderungen
- offene Fragen
- Risiken
- nächste Schritte
- interne Zusammenfassung

## Qualitätscheck
- Sind Annahmen, Unsicherheiten und fehlende Informationen sichtbar?
- Ist der Output für den Arbeitsalltag nutzbar und nicht nur allgemein formuliert?
- Stimmen Ton, Detailgrad und Format mit dem Zielkontext überein?
- Gibt es eine klare Empfehlung oder einen nächsten Schritt?

## Grenzen
Dieser Skill ersetzt keine Rechts-, Steuer-, Finanz- oder Datenschutzberatung. Nutze ihn zur Vorbereitung, Strukturierung und Qualitätssicherung, nicht als finale Fachentscheidung.
