---
name: kundenbriefing-reader
description: 'Macht aus unübersichtlicher Kundenkommunikation ein klares Projektbriefing mit Anforderungen, offenen Fragen und nächsten Schritten.'
---

# Kundenbriefing-Reader

## Einsatzmoment
Der Skill ist für Situationen gedacht, in denen Teilnehmende selbstständig, unter Zeitdruck, nah am Kunden und mit vielen halbfertigen Dingen im Kopf sind. Das Ziel ist nicht, schnell generischen Text zu produzieren, sondern Druck aus der Aufgabe zu nehmen und eine belastbare Arbeitsgrundlage zu schaffen.

Typische Spannung: Im Briefing steht viel, aber nicht alles, was für saubere Arbeit nötig ist.

## Zielbild
Am Ende liegt ein Ergebnis vor, das eine Person direkt prüfen, senden, entscheiden oder weiterbearbeiten kann. Claude soll nicht so tun, als sei alles sicher. Claude soll Annahmen, Lücken, Risiken und Rückfragen sichtbar machen.

Erwartete Outputs:
- Projektziel
- Anforderungen
- offene Fragen
- Risiken
- nächste Schritte
- interne Zusammenfassung

## Typischer Input
- Kundenmail
- Briefingdokument
- alte Kommunikation
- Meetingnotizen
- Anhänge

## Praxisprinzipien
- erst entscheiden, welcher nächste Schritt Geld, Klarheit oder Ruhe bringt
- nie eine Kundenantwort schreiben, ohne Annahmen, offene Punkte und Konsequenz sichtbar zu machen
- kleine Aufgaben so abschließen, dass daraus direkt ein sendbarer Entwurf oder eine klare Entscheidung entsteht

## Expert Moves für diesen Skill
- Ziele, Zielgruppe, Deliverables, Timing und Entscheider extrahieren
- Widersprüche markieren
- Rückfragen nach Arbeitsrisiko priorisieren

## Vorgehen
1. Lies den Input einmal nur auf Ziel, Kontext und gewünschtes Ergebnis.
2. Markiere fehlende Informationen. Wenn sie entscheidungsrelevant sind, frage nach, statt etwas zu erfinden.
3. Trenne Fakten, Annahmen, Interpretation und Empfehlung sichtbar.
4. Erstelle zuerst eine knappe Arbeitsstruktur, dann den eigentlichen Entwurf.
5. Prüfe das Ergebnis gegen die Qualitätskriterien unten.
6. Liefere bei Unsicherheit zwei Optionen: eine vorsichtige Version und eine mutigere Version mit klarer Begründung.

## Qualitätskriterien
- klare nächste Handlung mit Verantwortlichem und Datum
- keine falsche Sicherheit bei Preisen, Zusagen oder Fristen
- Ton: professionell, menschlich, knapp und nicht nach KI klingend

## Worauf du achten musst
- versteckte Muss-Kriterien
- unklare Freigabewege
- fehlende Erfolgskriterien

## Rückfragen, wenn Informationen fehlen
- Was soll mit dem Ergebnis direkt passieren: senden, entscheiden, intern vorbereiten oder prüfen?
- Wer ist die Zielperson und wie viel Vorwissen hat sie?
- Welche Frist, welches Risiko oder welche geschäftliche Konsequenz hängt daran?
- Gibt es Formulierungen, Zahlen, Namen oder Zusagen, die unverändert bleiben müssen?

## Output-Format
Gib das Ergebnis in dieser Reihenfolge aus:
1. Kurzdiagnose der Ausgangslage
2. Fertiger Entwurf oder strukturierte Arbeitsvorlage
3. Annahmen und offene Punkte
4. Risiken oder rote Flaggen
5. Konkreter nächster Schritt
