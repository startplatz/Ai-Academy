---
name: aufmass-zu-angebot
description: 'Verwandelt Aufmaßnotizen, Bilder oder Kurzbeschreibungen in strukturierte Angebotsentwürfe.'
---

# Aufmaß-zu-Angebot

## Wann verwenden
Nutze diesen Skill, wenn du für Handwerk, Bau-nahe Dienstleistungen, Eventtechnik, Gebäudeservice, lokale Dienstleister den beschriebenen Arbeitsprozess mit Claude strukturiert vorbereiten oder ausführen willst.

## Aufgabe
Der Aufmaß-zu-Angebot-Skill erstellt aus Notizen, Bildern, Sprachnotizen oder einfachen Beschreibungen einen Angebotsentwurf. Er strukturiert Leistungen, Materialbedarf, Arbeitsaufwand und offene Rückfragen.

## Typischer Input
- Aufmaßnotizen
- Bilder
- Sprachnotiz-Transkript
- Kundenbeschreibung
- Preislisten

## Vorgehen
1. Kläre Ziel, Kontext, Zielgruppe und gewünschtes Ausgabeformat.
2. Markiere fehlende Informationen als Rückfragen, statt sie zu erfinden.
3. Strukturiere den Arbeitsprozess in nachvollziehbare Schritte.
4. Erstelle einen ersten Output, der direkt weiterbearbeitet werden kann.
5. Füge einen kurzen Qualitätscheck mit Risiken, Annahmen und nächsten Schritten hinzu.

## Typischer Output
- Angebotsentwurf
- Leistungspositionen
- Materialbedarf
- offene Fragen
- Kundenmail

## Qualitätscheck
- Sind Annahmen, Unsicherheiten und fehlende Informationen sichtbar?
- Ist der Output für den Arbeitsalltag nutzbar und nicht nur allgemein formuliert?
- Stimmen Ton, Detailgrad und Format mit dem Zielkontext überein?
- Gibt es eine klare Empfehlung oder einen nächsten Schritt?

## Grenzen
Dieser Skill ersetzt keine Rechts-, Steuer-, Finanz- oder Datenschutzberatung. Nutze ihn zur Vorbereitung, Strukturierung und Qualitätssicherung, nicht als finale Fachentscheidung.
