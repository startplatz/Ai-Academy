---
name: reklamations-antworter
description: Formuliert sachliche und professionelle Antworten auf Beschwerden, Reklamationen und schwierige Kundenmails.
---

# Reklamations-Antworter

## Wann verwenden
Nutze diesen Skill, wenn du für Handwerk, Support, Sales, Dienstleister, Geschäftsführung den beschriebenen Arbeitsprozess mit Claude strukturiert vorbereiten oder ausführen willst.

## Aufgabe
Der Reklamations-Antworter hilft dabei, Beschwerden und Reklamationen sachlich, freundlich und professionell zu beantworten. Er fasst den Kern des Problems zusammen, erkennt mögliche Eskalationen und schlägt passende Reaktionen vor.

## Typischer Input
- Kundenbeschwerde
- Auftragsdaten
- bisherige Kommunikation
- interne Einschätzung

## Vorgehen
1. Kläre Ziel, Kontext, Zielgruppe und gewünschtes Ausgabeformat.
2. Markiere fehlende Informationen als Rückfragen, statt sie zu erfinden.
3. Strukturiere den Arbeitsprozess in nachvollziehbare Schritte.
4. Erstelle einen ersten Output, der direkt weiterbearbeitet werden kann.
5. Füge einen kurzen Qualitätscheck mit Risiken, Annahmen und nächsten Schritten hinzu.

## Typischer Output
- Antwortentwurf
- Problemanalyse
- Deeskalationsvorschlag
- Rückfragen
- interne Handlungsempfehlung

## Qualitätscheck
- Sind Annahmen, Unsicherheiten und fehlende Informationen sichtbar?
- Ist der Output für den Arbeitsalltag nutzbar und nicht nur allgemein formuliert?
- Stimmen Ton, Detailgrad und Format mit dem Zielkontext überein?
- Gibt es eine klare Empfehlung oder einen nächsten Schritt?

## Grenzen
Dieser Skill ersetzt keine Rechts-, Steuer-, Finanz- oder Datenschutzberatung. Nutze ihn zur Vorbereitung, Strukturierung und Qualitätssicherung, nicht als finale Fachentscheidung.
