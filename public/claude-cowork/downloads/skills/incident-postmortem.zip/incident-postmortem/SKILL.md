---
name: incident-postmortem
description: 'Erstellt strukturierte Postmortems mit Ursache, Auswirkungen, Timeline und Maßnahmenplan.'
---

# Incident-Postmortem

## Wann verwenden
Nutze diesen Skill, wenn du für IT, Entwicklung, Operations, Support, Produktteams den beschriebenen Arbeitsprozess mit Claude strukturiert vorbereiten oder ausführen willst.

## Aufgabe
Der Incident-Postmortem erstellt aus Fehlerberichten, Logs, Tickets und Teamnotizen eine strukturierte Nachbetrachtung. Er analysiert Ursache, Auswirkungen, Zeitverlauf und Maßnahmen.

## Typischer Input
- Incidentnotizen
- Logs
- Tickets
- Timeline
- Maßnahmen

## Vorgehen
1. Kläre Ziel, Kontext, Zielgruppe und gewünschtes Ausgabeformat.
2. Markiere fehlende Informationen als Rückfragen, statt sie zu erfinden.
3. Strukturiere den Arbeitsprozess in nachvollziehbare Schritte.
4. Erstelle einen ersten Output, der direkt weiterbearbeitet werden kann.
5. Füge einen kurzen Qualitätscheck mit Risiken, Annahmen und nächsten Schritten hinzu.

## Typischer Output
- Incident-Zusammenfassung
- Root-Cause-Analyse
- Impact
- Timeline
- Maßnahmenplan

## Qualitätscheck
- Sind Annahmen, Unsicherheiten und fehlende Informationen sichtbar?
- Ist der Output für den Arbeitsalltag nutzbar und nicht nur allgemein formuliert?
- Stimmen Ton, Detailgrad und Format mit dem Zielkontext überein?
- Gibt es eine klare Empfehlung oder einen nächsten Schritt?

## Grenzen
Dieser Skill ersetzt keine Rechts-, Steuer-, Finanz- oder Datenschutzberatung. Nutze ihn zur Vorbereitung, Strukturierung und Qualitätssicherung, nicht als finale Fachentscheidung.
