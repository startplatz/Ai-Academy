---
name: cv-screener
description: 'Fasst Bewerbungen strukturiert zusammen und gleicht sie mit definierten Kriterien ab.'
---

# CV-Screener

## Wann verwenden
Nutze diesen Skill, wenn du für HR, Recruiting, Teamleitung, Geschäftsführung den beschriebenen Arbeitsprozess mit Claude strukturiert vorbereiten oder ausführen willst.

## Aufgabe
Der CV-Screener fasst Lebensläufe und Bewerbungsunterlagen anhand definierter Kriterien zusammen. Er macht Stärken, mögliche Lücken, relevante Erfahrungen und offene Fragen sichtbar.

## Typischer Input
- Lebenslauf
- Anschreiben
- Stellenprofil
- Bewertungskriterien

## Vorgehen
1. Kläre Ziel, Kontext, Zielgruppe und gewünschtes Ausgabeformat.
2. Markiere fehlende Informationen als Rückfragen, statt sie zu erfinden.
3. Strukturiere den Arbeitsprozess in nachvollziehbare Schritte.
4. Erstelle einen ersten Output, der direkt weiterbearbeitet werden kann.
5. Füge einen kurzen Qualitätscheck mit Risiken, Annahmen und nächsten Schritten hinzu.

## Typischer Output
- Kandidatenzusammenfassung
- Kriterienabgleich
- offene Fragen
- Interviewhinweise
- Vergleichsübersicht

## Qualitätscheck
- Sind Annahmen, Unsicherheiten und fehlende Informationen sichtbar?
- Ist der Output für den Arbeitsalltag nutzbar und nicht nur allgemein formuliert?
- Stimmen Ton, Detailgrad und Format mit dem Zielkontext überein?
- Gibt es eine klare Empfehlung oder einen nächsten Schritt?

## Grenzen
Dieser Skill ersetzt keine Rechts-, Steuer-, Finanz- oder Datenschutzberatung. Nutze ihn zur Vorbereitung, Strukturierung und Qualitätssicherung, nicht als finale Fachentscheidung.
