---
name: stakeholder-briefing
description: Bereitet Stakeholder-Informationen mit Interessen, Risiken und Kommunikationshinweisen auf.
---

# Stakeholder-Briefing

## Wann verwenden
Nutze diesen Skill, wenn du für Projektmanagement, Konzernteams, Geschäftsführung, interne Beratung, Produktteams den beschriebenen Arbeitsprozess mit Claude strukturiert vorbereiten oder ausführen willst.

## Aufgabe
Das Stakeholder-Briefing fasst relevante Informationen, Interessen, Risiken und offene Punkte für einzelne Stakeholder oder Gruppen zusammen.

## Typischer Input
- Projektmaterial
- Stakeholderliste
- Meetingnotizen
- Statusberichte
- offene Themen

## Vorgehen
1. Kläre Ziel, Kontext, Zielgruppe und gewünschtes Ausgabeformat.
2. Markiere fehlende Informationen als Rückfragen, statt sie zu erfinden.
3. Strukturiere den Arbeitsprozess in nachvollziehbare Schritte.
4. Erstelle einen ersten Output, der direkt weiterbearbeitet werden kann.
5. Füge einen kurzen Qualitätscheck mit Risiken, Annahmen und nächsten Schritten hinzu.

## Typischer Output
- Stakeholderübersicht
- Interessen
- Risiken
- Kommunikationshinweise
- nächste Schritte

## Qualitätscheck
- Sind Annahmen, Unsicherheiten und fehlende Informationen sichtbar?
- Ist der Output für den Arbeitsalltag nutzbar und nicht nur allgemein formuliert?
- Stimmen Ton, Detailgrad und Format mit dem Zielkontext überein?
- Gibt es eine klare Empfehlung oder einen nächsten Schritt?

## Grenzen
Dieser Skill ersetzt keine Rechts-, Steuer-, Finanz- oder Datenschutzberatung. Nutze ihn zur Vorbereitung, Strukturierung und Qualitätssicherung, nicht als finale Fachentscheidung.
