---
name: baustellen-protokoll
description: 'Erstellt aus Baustellennotizen und Bildern strukturierte Tagesberichte, Mängellisten und Kundenupdates.'
---

# Baustellen-Protokoll

## Wann verwenden
Nutze diesen Skill, wenn du für Handwerk, Bauleitung, Facility Management, technische Dienstleister, Projektkoordination den beschriebenen Arbeitsprozess mit Claude strukturiert vorbereiten oder ausführen willst.

## Aufgabe
Das Baustellen-Protokoll wandelt Stichpunkte, Fotos, Tagesnotizen oder Sprachnotizen in eine strukturierte Dokumentation um. Es kann Arbeitsfortschritt, Probleme, offene Punkte und nächste Schritte zusammenfassen.

## Typischer Input
- Tagesnotizen
- Fotos
- Sprachnotizen
- Baustellenstatus
- offene Mängel

## Vorgehen
1. Kläre Ziel, Kontext, Zielgruppe und gewünschtes Ausgabeformat.
2. Markiere fehlende Informationen als Rückfragen, statt sie zu erfinden.
3. Strukturiere den Arbeitsprozess in nachvollziehbare Schritte.
4. Erstelle einen ersten Output, der direkt weiterbearbeitet werden kann.
5. Füge einen kurzen Qualitätscheck mit Risiken, Annahmen und nächsten Schritten hinzu.

## Typischer Output
- Tagesbericht
- Fortschrittsdokumentation
- offene Punkte
- Mängelliste
- Kundenupdate

## Qualitätscheck
- Sind Annahmen, Unsicherheiten und fehlende Informationen sichtbar?
- Ist der Output für den Arbeitsalltag nutzbar und nicht nur allgemein formuliert?
- Stimmen Ton, Detailgrad und Format mit dem Zielkontext überein?
- Gibt es eine klare Empfehlung oder einen nächsten Schritt?

## Grenzen
Dieser Skill ersetzt keine Rechts-, Steuer-, Finanz- oder Datenschutzberatung. Nutze ihn zur Vorbereitung, Strukturierung und Qualitätssicherung, nicht als finale Fachentscheidung.
