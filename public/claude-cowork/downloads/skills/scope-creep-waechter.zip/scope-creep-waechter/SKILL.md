---
name: scope-creep-waechter
description: 'Erkennt zusätzliche Kundenwünsche außerhalb des vereinbarten Umfangs und hilft bei professioneller Kommunikation.'
---

# Scope-Creep-Wächter

## Wann verwenden
Nutze diesen Skill, wenn du für Freelancer, Agenturen, Berater, Dienstleister, Projektmanager den beschriebenen Arbeitsprozess mit Claude strukturiert vorbereiten oder ausführen willst.

## Aufgabe
Der Scope-Creep-Wächter prüft Kundenanfragen darauf, ob sie über den ursprünglich vereinbarten Leistungsumfang hinausgehen. Er formuliert sachliche Hinweise, Rückfragen und Vorschläge für Zusatzangebote.

## Typischer Input
- ursprüngliches Angebot
- Leistungsbeschreibung
- neue Kundenanfrage
- Projektstatus

## Vorgehen
1. Kläre Ziel, Kontext, Zielgruppe und gewünschtes Ausgabeformat.
2. Markiere fehlende Informationen als Rückfragen, statt sie zu erfinden.
3. Strukturiere den Arbeitsprozess in nachvollziehbare Schritte.
4. Erstelle einen ersten Output, der direkt weiterbearbeitet werden kann.
5. Füge einen kurzen Qualitätscheck mit Risiken, Annahmen und nächsten Schritten hinzu.

## Typischer Output
- Einschätzung zum Leistungsumfang
- zusätzliche Anforderungen
- Formulierung für Kundenantwort
- Vorschlag für Zusatzangebot

## Qualitätscheck
- Sind Annahmen, Unsicherheiten und fehlende Informationen sichtbar?
- Ist der Output für den Arbeitsalltag nutzbar und nicht nur allgemein formuliert?
- Stimmen Ton, Detailgrad und Format mit dem Zielkontext überein?
- Gibt es eine klare Empfehlung oder einen nächsten Schritt?

## Grenzen
Dieser Skill ersetzt keine Rechts-, Steuer-, Finanz- oder Datenschutzberatung. Nutze ihn zur Vorbereitung, Strukturierung und Qualitätssicherung, nicht als finale Fachentscheidung.
