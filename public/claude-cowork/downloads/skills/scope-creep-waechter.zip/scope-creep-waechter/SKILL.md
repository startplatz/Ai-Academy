---
name: scope-creep-waechter
description: 'Erkennt zusätzliche Kundenwünsche außerhalb des vereinbarten Umfangs und hilft bei professioneller Kommunikation.'
---

# Scope-Creep-Wächter

## Einsatzmoment
Der Skill ist für Situationen gedacht, in denen Teilnehmende selbstständig, unter Zeitdruck, nah am Kunden und mit vielen halbfertigen Dingen im Kopf sind. Das Ziel ist nicht, schnell generischen Text zu produzieren, sondern Druck aus der Aufgabe zu nehmen und eine belastbare Arbeitsgrundlage zu schaffen.

Typische Spannung: Ein kleiner Zusatz fühlt sich höflich an, frisst aber Marge und Fokus.

## Zielbild
Am Ende liegt ein Ergebnis vor, das eine Person direkt prüfen, senden, entscheiden oder weiterbearbeiten kann. Claude soll nicht so tun, als sei alles sicher. Claude soll Annahmen, Lücken, Risiken und Rückfragen sichtbar machen.

Erwartete Outputs:
- Einschätzung zum Leistungsumfang
- zusätzliche Anforderungen
- Formulierung für Kundenantwort
- Vorschlag für Zusatzangebot

## Typischer Input
- ursprüngliches Angebot
- Leistungsbeschreibung
- neue Kundenanfrage
- Projektstatus

## Praxisprinzipien
- erst entscheiden, welcher nächste Schritt Geld, Klarheit oder Ruhe bringt
- nie eine Kundenantwort schreiben, ohne Annahmen, offene Punkte und Konsequenz sichtbar zu machen
- kleine Aufgaben so abschließen, dass daraus direkt ein sendbarer Entwurf oder eine klare Entscheidung entsteht

## Expert Moves für diesen Skill
- Originalscope gegen neue Bitte vergleichen
- Auswirkung auf Zeit, Kosten und Qualität benennen
- freundliche Change-Order-Formulierung vorbereiten

## Vorgehen
1. Lies den Input einmal nur auf Ziel, Kontext und gewünschtes Ergebnis.
2. Markiere fehlende Informationen. Wenn sie entscheidungsrelevant sind, frage nach, statt etwas zu erfinden.
3. Trenne Fakten, Annahmen, Interpretation und Empfehlung sichtbar.
4. Erstelle zuerst eine knappe Arbeitsstruktur, dann den eigentlichen Entwurf.
5. Prüfe das Ergebnis gegen die Qualitätskriterien unten.
6. Liefere bei Unsicherheit zwei Optionen: eine vorsichtige Version und eine mutigere Version mit klarer Begründung.

## Qualitätskriterien
- klare nächste Handlung mit Verantwortlichem und Datum
- keine falsche Sicherheit bei Preisen, Zusagen oder Fristen
- Ton: professionell, menschlich, knapp und nicht nach KI klingend

## Worauf du achten musst
- Bagatellisierung
- fehlende Dokumentation
- zu spätes Ansprechen

## Rückfragen, wenn Informationen fehlen
- Was soll mit dem Ergebnis direkt passieren: senden, entscheiden, intern vorbereiten oder prüfen?
- Wer ist die Zielperson und wie viel Vorwissen hat sie?
- Welche Frist, welches Risiko oder welche geschäftliche Konsequenz hängt daran?
- Gibt es Formulierungen, Zahlen, Namen oder Zusagen, die unverändert bleiben müssen?

## Output-Format
Gib das Ergebnis in dieser Reihenfolge aus:
1. Kurzdiagnose der Ausgangslage
2. Fertiger Entwurf oder strukturierte Arbeitsvorlage
3. Annahmen und offene Punkte
4. Risiken oder rote Flaggen
5. Konkreter nächster Schritt
