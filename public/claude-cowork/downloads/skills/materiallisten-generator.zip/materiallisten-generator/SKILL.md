---
name: materiallisten-generator
description: 'Erstellt aus Auftragsinformationen eine Material- und Werkzeugliste für bessere Vorbereitung.'
---

# Materiallisten-Generator

## Wann verwenden
Nutze diesen Skill, wenn du für Handwerker, Techniker, Eventdienstleister, Facility Management, Bau-nahe Gewerke den beschriebenen Arbeitsprozess mit Claude strukturiert vorbereiten oder ausführen willst.

## Aufgabe
Der Materiallisten-Generator erstellt aus einer Jobbeschreibung eine strukturierte Liste mit benötigten Materialien, Werkzeugen, Mengenannahmen und offenen Klärungspunkten.

## Typischer Input
- Jobbeschreibung
- Auftragsumfang
- Maße
- Fotos
- Erfahrungswerte

## Vorgehen
1. Kläre Ziel, Kontext, Zielgruppe und gewünschtes Ausgabeformat.
2. Markiere fehlende Informationen als Rückfragen, statt sie zu erfinden.
3. Strukturiere den Arbeitsprozess in nachvollziehbare Schritte.
4. Erstelle einen ersten Output, der direkt weiterbearbeitet werden kann.
5. Füge einen kurzen Qualitätscheck mit Risiken, Annahmen und nächsten Schritten hinzu.

## Typischer Output
- Materialliste
- Werkzeugliste
- Mengenannahmen
- offene Rückfragen
- Vorbereitungsliste

## Qualitätscheck
- Sind Annahmen, Unsicherheiten und fehlende Informationen sichtbar?
- Ist der Output für den Arbeitsalltag nutzbar und nicht nur allgemein formuliert?
- Stimmen Ton, Detailgrad und Format mit dem Zielkontext überein?
- Gibt es eine klare Empfehlung oder einen nächsten Schritt?

## Grenzen
Dieser Skill ersetzt keine Rechts-, Steuer-, Finanz- oder Datenschutzberatung. Nutze ihn zur Vorbereitung, Strukturierung und Qualitätssicherung, nicht als finale Fachentscheidung.
