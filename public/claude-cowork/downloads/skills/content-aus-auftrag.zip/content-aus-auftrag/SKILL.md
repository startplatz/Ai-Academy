---
name: content-aus-auftrag
description: 'Macht aus abgeschlossenen Kundenprojekten verwertbaren Content für LinkedIn, Newsletter, Website und Case Studies.'
---

# Content-aus-Auftrag

## Wann verwenden
Nutze diesen Skill, wenn du für Freelancer, Agenturen, Berater, Gründer, Marketingteams den beschriebenen Arbeitsprozess mit Claude strukturiert vorbereiten oder ausführen willst.

## Aufgabe
Der Content-aus-Auftrag verwandelt abgeschlossene Projekte, Kundenarbeiten oder interne Learnings in verwertbaren Content. Aus einem Projekt können LinkedIn-Posts, Case Studies, Newsletter-Abschnitte, Website-Texte oder Social-Media-Ideen entstehen.

## Typischer Input
- Projektbeschreibung
- Ergebnis
- Kundennutzen
- Learnings
- Zielgruppe

## Vorgehen
1. Kläre Ziel, Kontext, Zielgruppe und gewünschtes Ausgabeformat.
2. Markiere fehlende Informationen als Rückfragen, statt sie zu erfinden.
3. Strukturiere den Arbeitsprozess in nachvollziehbare Schritte.
4. Erstelle einen ersten Output, der direkt weiterbearbeitet werden kann.
5. Füge einen kurzen Qualitätscheck mit Risiken, Annahmen und nächsten Schritten hinzu.

## Typischer Output
- LinkedIn-Post
- Case-Study-Struktur
- Newsletter-Text
- Social-Media-Ideen
- Website-Textbausteine

## Qualitätscheck
- Sind Annahmen, Unsicherheiten und fehlende Informationen sichtbar?
- Ist der Output für den Arbeitsalltag nutzbar und nicht nur allgemein formuliert?
- Stimmen Ton, Detailgrad und Format mit dem Zielkontext überein?
- Gibt es eine klare Empfehlung oder einen nächsten Schritt?

## Grenzen
Dieser Skill ersetzt keine Rechts-, Steuer-, Finanz- oder Datenschutzberatung. Nutze ihn zur Vorbereitung, Strukturierung und Qualitätssicherung, nicht als finale Fachentscheidung.
