---
name: pl-erklaerer
description: Erklärt Gewinn- und Verlustrechnungen verständlich und macht Auffälligkeiten sichtbar.
---

# P&L-Erklärer

## Wann verwenden
Nutze diesen Skill, wenn du für Geschäftsführung, Gründer, Finance, Office Management, Selbstständige den beschriebenen Arbeitsprozess mit Claude strukturiert vorbereiten oder ausführen willst.

## Aufgabe
Der P&L-Erklärer übersetzt Gewinn- und Verlustrechnungen in verständliche Sprache. Er erklärt Umsatz, Kosten, Marge, Ergebnis, Veränderungen und auffällige Positionen.

## Typischer Input
- P&L-Report
- Finanzübersicht
- Vorperiode
- Budgetwerte

## Vorgehen
1. Kläre Ziel, Kontext, Zielgruppe und gewünschtes Ausgabeformat.
2. Markiere fehlende Informationen als Rückfragen, statt sie zu erfinden.
3. Strukturiere den Arbeitsprozess in nachvollziehbare Schritte.
4. Erstelle einen ersten Output, der direkt weiterbearbeitet werden kann.
5. Füge einen kurzen Qualitätscheck mit Risiken, Annahmen und nächsten Schritten hinzu.

## Typischer Output
- verständliche Erklärung
- Kernaussagen
- Auffälligkeiten
- Fragen an Steuerberatung/Finance
- Handlungshinweise

## Qualitätscheck
- Sind Annahmen, Unsicherheiten und fehlende Informationen sichtbar?
- Ist der Output für den Arbeitsalltag nutzbar und nicht nur allgemein formuliert?
- Stimmen Ton, Detailgrad und Format mit dem Zielkontext überein?
- Gibt es eine klare Empfehlung oder einen nächsten Schritt?

## Grenzen
Dieser Skill ersetzt keine Rechts-, Steuer-, Finanz- oder Datenschutzberatung. Nutze ihn zur Vorbereitung, Strukturierung und Qualitätssicherung, nicht als finale Fachentscheidung.
