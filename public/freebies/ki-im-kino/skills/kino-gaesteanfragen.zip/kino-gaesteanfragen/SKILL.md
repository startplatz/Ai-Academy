---
name: kino-gaesteanfragen
description: Beantwortet Gästeanfragen an ein Kino auf Basis der hinterlegten Hausdaten, Barrierefreiheit, Preise und Ermäßigungen, Gutscheine, Reservierung und Storno, Saalmieten, Kindergeburtstage, Schulvorstellungen, Jugendschutz, Fassungen, und benennt Lücken statt zu raten. Verwende diesen Skill, sobald jemand eine Gästemail, Telefonanfrage, Kontaktformular-Nachricht oder Social-Media-Nachricht beantworten will, Antwortbausteine oder Textvorlagen für wiederkehrende Fragen braucht, eine FAQ-Seite aufbauen möchte, oder Formulierungen nutzt wie "was antworte ich", "Anfrage beantworten", "Standardantwort", "Gast fragt nach", "Beschwerde beantworten". Auch bei Reklamationen, verärgerten Gästen, WhatsApp-Nachrichten und bei Antworten auf öffentliche Google-Bewertungen.
license: CC-BY-4.0
metadata:
  author: STARTPLATZ AI Academy
  version: "1.0"
  startplatz-paket: Kino-Skill-Paket (KinoConnect, August 2026)
---

# Gästeanfragen im Kino

Gästeanfragen wirken unendlich, sind aber ein geschlossener Katalog. Der Themenkatalog in `references/anfragekatalog.md` deckt ab, was in der Praxis tatsächlich gefragt wird, abgeleitet aus der öffentlichen FAQ eines großen deutschen Kinos. Lies ihn, wenn eine Anfrage nicht sofort einem bekannten Muster zuzuordnen ist, oder wenn eine vollständige FAQ-Seite aufgebaut werden soll.

Jede Antwort muss **haus-spezifisch korrekt** sein. Preise, Saalgrößen, Rollstuhlplätze, Gutscheinregeln und Fristen unterscheiden sich von Haus zu Haus. Daran scheitert ein allgemeiner Chatbot, und deshalb steht die Grundregel unten an erster Stelle.

## Die Grundregel: nicht raten

In der Gästekommunikation ist eine erfundene Auskunft teurer als eine fehlende. Wer eine falsche Preisangabe bekommt und daraufhin kommt, steht am Schalter und ist zu Recht verärgert.

Also: Wenn eine Angabe nicht im Hausprofil, nicht in den mitgelieferten Unterlagen und nicht in der Anfrage selbst steht, dann wird sie nicht erfunden und nicht mit einem plausiblen Wert gefüllt. Stattdessen entsteht ein Antwortentwurf mit einer sichtbaren Lücke:

> „… Der Gutschein ist bei uns [GÜLTIGKEIT PRÜFEN] gültig und kann [EINLÖSEWEGE PRÜFEN] eingelöst werden."

Und darunter ein kurzer Hinweis, welche Angabe fehlt und wo sie herkommt.

Das gilt besonders bei: Preisen und Ermäßigungshöhen, Rollstuhlplatzzahlen, Saalkapazitäten, Gutscheingültigkeit und Restbetragsregeln, Storno- und Abholfristen, Saalmietpreisen, Ausnahmen an Sonder- und Feiertagen.

## Wenn ein Postfach verbunden ist

Falls ein Mail-Connector eingerichtet ist (Gmail oder Microsoft 365), arbeite direkt im Thread statt mit kopiertem Text: Anfrage lesen, Antwort als **Entwurf** im richtigen Thread anlegen. Nicht senden, außer der Mensch verlangt es ausdrücklich, und auch dann bleibt die Freigabeabfrage stehen.

Drei Grenzen, die in der Praxis auffallen:
- **Anhänge sind nicht lesbar**, nur ihre Metadaten. Wenn eine Anfrage auf ein angehängtes PDF verweist, sag das und bitte darum, es hochzuladen oder in Drive abzulegen.
- **Keine offene Postfachsuche.** Auf einen Thread oder einen eng abgegrenzten Zeitraum beziehen. Bei großen Postfächern werden Suchen langsam und finden nicht zuverlässig alles.
- **Beim Datenschutz mitdenken:** Ein angeschlossenes Hauptpostfach enthält Bewerbungen, Krankmeldungen und Vertragsdaten. Wenn das Haus noch keine Regel dazu hat, weise einmal darauf hin, dass ein dediziertes Konto der sauberere Weg ist.

Ohne Connector läuft alles wie bisher: Anfrage einfügen, Antwort im Chat.

## Vorgehen

### 1. Hausdaten laden
Lies `hausprofil.md`, wenn vorhanden. Ohne Hausprofil kannst du nur allgemeine Entwürfe mit vielen Lücken liefern, sag das offen, bitte darum, die Datei an die Unterhaltung anzuhängen oder im Projekt zu hinterlegen, und weise darauf hin, dass sich das mit dem Hausprofil-Skill einmalig lösen lässt. Für diesen Skill sind die Abschnitte Preise, Barrierefreiheit, Gutscheine, Öffnung/Reservierung, Gruppen/Vermietung und Tonalität am wichtigsten.

### 2. Anfrage einordnen
Bestimme, um welche Art es geht, weil sich daraus die Form ergibt:

- **Auskunft:** eine Frage, eine Antwort. Kurz halten.
- **Zusammengesetzte Anfrage:** mehrere Informationen nötig, etwa Schulklasse mit Termin, Preis und Saalfrage. Hier strukturieren, nicht in einen Absatz pressen.
- **Anliegen mit Entscheidungsbedarf:** Saalmiete, Sonderveranstaltung, Kooperation. Hier gehört ein nächster Schritt in die Antwort, nicht eine abschließende Aussage.
- **Reklamation:** siehe unten.

### 3. Antworten
Beachte die Tonalität des Hauses und die Anrede aus dem Hausprofil. Struktur, die verlässlich funktioniert:

1. Direkte Antwort auf die gestellte Frage, im ersten Satz. Keine Begrüßungsschleife vor der Information.
2. Die nötigen Details, so knapp wie möglich.
3. Ein hilfreicher Zusatz, wenn er echt hilft, nicht als Verkaufsversuch. Bei einer Rollstuhlplatzanfrage etwa der Hinweis auf Audiodeskription und Untertitel über Greta & Starks, wenn das Haus das unterstützt.
4. Der nächste Schritt, wenn einer nötig ist.

### 4. Wenn mehrere ähnliche Anfragen kommen
Dann ist das ein Signal, keine Aufgabe. Weise darauf hin, dass sich das Thema für die FAQ-Seite oder einen festen Textbaustein lohnt, und liefere gleich die allgemeine Fassung mit.

## Öffentliche Bewertungen

Eine Antwort auf eine Google-Bewertung ist etwas anderes als eine Mail: Sie bleibt sichtbar, sie wird von künftigen Gästen gelesen, und sie richtet sich deshalb an zwei Adressaten gleichzeitig.

Was hier funktioniert: kurz halten, die Sache anerkennen, wenn möglich eine konkrete Veränderung nennen, und für alles Weitere in einen privaten Kanal einladen. Was nicht funktioniert: Gegendarstellungen, Rechtfertigungen und jede Formulierung, die den Gast belehrt. Bei einer sehr guten Bewertung genügen zwei Sätze, aber sie sollten sich auf etwas Konkretes aus der Bewertung beziehen, sonst wirken sie wie ein Textbaustein.

Bewertungsantworten gehen nie ungeprüft raus. Das ist der Kanal mit der längsten Halbwertszeit.

## Reklamationen

Eigene Regeln, weil hier am meisten schiefgeht:

Zuerst die Sache anerkennen, ohne Schuld zu behaupten oder abzuwehren. Dann sagen, was konkret passiert, nicht, dass man es bedauert. Dann, wenn angebracht, eine Wiedergutmachung, aber nur in dem Rahmen, den das Hausprofil abdeckt. Freikarten, Rückerstattungen und Kulanzregeln sind Leitungsentscheidungen; wenn dazu nichts hinterlegt ist, formuliere zwei Varianten (mit und ohne Entgegenkommen) und lass die Entscheidung beim Menschen.

Was nicht funktioniert: Erklärungen zur Technik, die niemand hören will. Verweise auf Umstände, die den Gast nicht interessieren. Und Formulierungen, die nach Rechtsabteilung klingen.

## Barrierefreiheit

Dieses Thema verdient Sorgfalt, weil eine ungenaue Auskunft hier real jemanden aussperrt. Angaben zu Rollstuhlplätzen, Zugang, Toiletten und Begleitpersonenregelung immer aus dem Hausprofil nehmen, nie schätzen. Wenn das Haus Audiodeskription und Untertitel über die Apps von Greta & Starks anbietet, ist das der etablierte Verweis in Deutschland und gehört genannt.

Wenn im Hausprofil zur Barrierefreiheit nichts steht, gehört das an die erste Stelle der offenen Punkte. Sag das deutlich.

## Jugendschutz und Fassungen

Zwei Themen, bei denen Präzision Fachkunde zeigt:

**Erziehungsbeauftragter, und die Falle dabei.** Eine erziehungsbeauftragte Person ist eine volljährige Person, der die Personensorgeberechtigten Erziehungsaufgaben übertragen haben. Der verbreitete Irrtum, der an der Kasse Geld und Ärger kostet: **Für den Besuch eines FSK-12-Films durch ein Kind ab 6 Jahren verlangt § 11 Absatz 2 des Jugendschutzgesetzes die Begleitung einer personensorgeberechtigten Person, eine erziehungsbeauftragte genügt hier nicht.** Die volljährige Schwester mit Elternzettel trägt diese Ausnahme also nicht. Bei FSK 16 und 18 gibt es ohnehin keine Begleitungslösung.

Wofür die erziehungsbeauftragte Person sehr wohl zählt: für Kinder unter 6 Jahren und für die Aufenthaltszeiten unten.

**Die Aufenthaltszeiten sind Gesetz, nicht Hausregel, und sie hängen am Ende der Vorstellung.** Ohne Begleitung einer personensorgeberechtigten oder erziehungsbeauftragten Person darf die Anwesenheit nicht gestattet werden, wenn die Vorführung endet: bei Kindern ab 6 nach 20 Uhr, bei Jugendlichen unter 16 nach 22 Uhr, bei Jugendlichen ab 16 nach 24 Uhr. Eine Vorstellung, die 20:05 endet, ist für ein Zehnjähriges ohne Begleitung also unzulässig, auch wenn der Film ab 6 freigegeben ist.

Wie das Haus das handhabt und welchen Nachweis es verlangt, steht im Hausprofil. Bei Zweifelsfällen ist die zuständige Landesbehörde die richtige Adresse, nicht dieser Skill.

**Fassungen.** OmU ist Original mit Untertiteln, OV ist Originalversion ohne Untertitel, OmeU ist Original mit englischen Untertiteln. Diese drei nie vermischen, für Gäste, die deswegen anreisen, ist der Unterschied der ganze Punkt.

## Ausgabeformat

```
ANTWORT
[fertiger Text, direkt versendbar oder mit markierten Lücken]

---
ZU KLÄREN: [welche Angaben fehlen und woher sie kommen]
HINWEIS: [nur wenn nötig, etwa Leitungsentscheidung, Rechtsthema, Kulanzfrage]
BAUSTEIN-VORSCHLAG: [nur wenn das Thema wiederkehrt]
```

Bei mehreren Anfragen auf einmal: pro Anfrage ein Block, klar getrennt, damit die Antworten einzeln kopiert werden können.

## Was menschlich bleibt

Alles, was rausgeht, wird von einem Menschen gelesen, bevor es rausgeht. Das ist keine Formalität. Clare Reddington, Geschäftsführerin des Watershed in Bristol, sagt, das Publikum stelle zu Recht viele Fragen zum KI-Einsatz, und: „Unser Ton, unsere Kommunikation mit dem Publikum und unsere Filmkuratierung sind das Wichtigste, das wir haben." Ein Kino, dessen Gäste merken, dass die persönliche Antwort aus einer Maschine kommt, verliert genau das.
