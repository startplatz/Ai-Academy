# Themenkatalog der Gästeanfragen

Abgeleitet aus der öffentlichen FAQ eines großen deutschen Kinos (CINENOVA Köln, abgerufen 18.08.2026) und aus dem von der FFA geförderten Kinoleitfaden. Der Katalog ist als Prüfliste gedacht: Beim Aufbau einer FAQ-Seite oder eines Bausteinsets zeigt er, was typischerweise noch fehlt.

Jeder Punkt trägt einen Hinweis, welche Angabe aus dem Hausprofil nötig ist. Steht sie dort nicht, entsteht in der Antwort eine sichtbare Lücke.

## Inhalt

1. Anreise und Vor Ort
2. Preise, Ermäßigungen, Zahlung
3. Tickets, Reservierung, Storno
4. Gutscheine und Kundenkarte
5. Abomodelle
6. Barrierefreiheit
7. Jugendschutz
8. Programm und Fassungen
9. Gruppen und Sonderveranstaltungen
10. Sonstiges und Organisatorisches
11. Reklamationen
12. Was regelmäßig fehlt

---

## 1. Anreise und Vor Ort

| Frage | Nötige Hausangabe |
|---|---|
| Wie komme ich hin, wo kann ich parken? | Adresse, Parksituation, ÖPNV |
| Wann öffnet die Kasse? | Kassenzeiten, ggf. abweichend am Wochenende |
| Darf ich eigene Getränke und Speisen mitbringen? | Mitbringregel |
| Sind Hunde erlaubt? | Regelung, ggf. Ausnahme für Assistenzhunde |
| Wo sind die Toiletten, gibt es eine barrierefreie? | siehe Abschnitt 6 |

## 2. Preise, Ermäßigungen, Zahlung

| Frage | Nötige Hausangabe |
|---|---|
| Was kostet ein Ticket? | Preisstaffel, Zuschläge, Saalunterschiede |
| Gibt es Ermäßigung für Schüler und Studierende? | Ermäßigungsgruppen und Nachweise |
| Ermäßigung mit Behindertenausweis, gilt sie auch für die Begleitperson? | Regelung inkl. Merkzeichen-Praxis |
| Sind Ermäßigungen mit anderen Vorteilen kombinierbar? | Kombinationsregel |
| Wie kann ich bezahlen? | Zahlungsmittel an Kasse und online |
| Gibt es Gruppenpreise? | siehe Abschnitt 9 |

## 3. Tickets, Reservierung, Storno

| Frage | Nötige Hausangabe |
|---|---|
| Wie funktioniert das Online-Ticket, brauche ich einen Ausdruck? | Ticketform, QR-Code-Praxis |
| Fällt eine Online-Gebühr an? | Gebührenhöhe oder -freiheit |
| Kann ich reservieren und bis wann muss ich abholen? | Reservierungsweg, Abholfrist |
| Kann ich stornieren oder umbuchen? | Stornoregel, Fristen, Ausnahmen |
| Ich habe mein Ticket verloren. | Vorgehen, Nachweisweg |

## 4. Gutscheine und Kundenkarte

| Frage | Nötige Hausangabe |
|---|---|
| Wie lange ist mein Gutschein gültig? | Gültigkeitsdauer (häufig drei Jahre) |
| Was passiert mit dem Restbetrag? | Restbetragsregel |
| Kann ich den Gutschein online einlösen? | Einlösewege |
| Gilt der Gutschein auch für Sonderveranstaltungen und Zuschläge? | Ausnahmenliste — wird oft vergessen |
| Wie lade ich meine Kundenkarte auf, ich habe die PIN verloren? | Kartenprozesse, Login, PIN-Reset |
| Ist die Kundenkarte mit Ermäßigungen kombinierbar? | Kombinationsregel |

## 5. Abomodelle

| Frage | Nötige Hausangabe |
|---|---|
| Nehmen Sie Cineville? | Teilnahme ja/nein, welche Vorstellungen ausgenommen |
| Gilt MUBI GO bei Ihnen? | Teilnahme, Einlöseweg |

Beide Modelle sind in Deutschland real im Einsatz und am Schalter erklärungsbedürftig. Cineville startete in Deutschland im August 2024 mit 15 Pionierkinos in Hamburg, Köln, Berlin, Freiburg und Nürnberg und ist inzwischen auf über 60 Spielstellen in 15 Städten gewachsen (Stand 08/2026).

## 6. Barrierefreiheit

Der sensibelste Block. Hier keine Angabe schätzen.

| Frage | Nötige Hausangabe |
|---|---|
| Gibt es Rollstuhlplätze, wie viele, in welchem Saal? | Platzzahl pro Saal |
| Muss ich vorher reservieren? | Reservierungsweg und Frist |
| Ist der Zugang barrierefrei, gibt es einen Aufzug? | Zugangssituation |
| Gibt es eine barrierefreie Toilette? | ja/nein und Lage |
| Bieten Sie Audiodeskription oder Untertitel an? | Unterstützung der Apps von Greta & Starks, ggf. pro Film |
| Gibt es eine Induktionsschleife? | Technikausstattung |
| Kommt meine Assistenz kostenfrei mit? | Begleitpersonenregelung |

Greta & Starks ist die etablierte App-Infrastruktur in Deutschland für Audiodeskription und Untertitel und der übliche Verweis in solchen Antworten.

## 7. Jugendschutz

| Frage | Nötige Hausangabe |
|---|---|
| Mein Kind ist 11, der Film ist ab 12. Geht das mit mir? | Praxis des Hauses; gesetzlich nötig ist die Begleitung einer personensorgeberechtigten Person |
| Darf die volljährige Schwester mitgehen? | siehe unten — für FSK 12 genügt eine Erziehungsbeauftragung **nicht** |
| Bis wann dürfen Jugendliche abends bleiben? | nur Hinweis auf die gesetzliche Regel, siehe unten |

**Der häufigste Irrtum zuerst.** Für den Besuch eines **FSK-12-Films durch ein Kind ab 6 Jahren** verlangt § 11 Absatz 2 des Jugendschutzgesetzes die Begleitung einer **personensorgeberechtigten** Person. Eine erziehungsbeauftragte Person, die volljährige Schwester mit Elternzettel, genügt für diese Ausnahme **nicht**. Bei FSK 16 und 18 gibt es keine Begleitungslösung.

**Erziehungsbeauftragte Person** ist eine volljährige Person, der die Personensorgeberechtigten Erziehungsaufgaben übertragen haben. Sie zählt für Kinder unter 6 Jahren und für die Aufenthaltszeiten.

**Die Aufenthaltszeiten sind Gesetz, nicht Hausregel, und sie hängen am Ende der Vorführung.** Ohne Begleitung einer personensorgeberechtigten oder erziehungsbeauftragten Person darf die Anwesenheit nicht gestattet werden, wenn die Vorführung endet: bei Kindern ab 6 nach 20 Uhr, bei Jugendlichen unter 16 nach 22 Uhr, bei Jugendlichen ab 16 nach 24 Uhr. Eine Vorstellung, die 20:05 endet, ist für ein Zehnjähriges ohne Begleitung unzulässig. Der Unterschied zwischen Hausregel und Ordnungswidrigkeit liegt genau hier, bei Zweifelsfällen ist die zuständige Landesbehörde die richtige Adresse.

## 8. Programm und Fassungen

| Frage | Nötige Hausangabe |
|---|---|
| Wann steht das neue Programm? | Erscheinungstag — die Kinowoche läuft Donnerstag bis Mittwoch |
| Läuft der Film in OmU oder synchronisiert? | Fassung pro Vorstellung |
| Was heißt OmU, OV, OmeU? | Erklärung — siehe unten |
| Wie lange läuft der Film noch? | Einsatzdauer, sofern absehbar |
| Zeigen Sie Film X? | Programmauskunft, ggf. Verweis auf Wunschliste |
| Wann startet Film Y bei Ihnen? | Starttermin — siehe Markt-Briefing-Skill |
| Was läuft im Vorprogramm, wann fängt der Hauptfilm an? | Vorprogrammdauer |

**OmU** ist Original mit Untertiteln, **OV** ist Originalversion ohne Untertitel, **OmeU** ist Original mit englischen Untertiteln. Diese drei nie verwechseln.

## 9. Gruppen und Sonderveranstaltungen

| Frage | Nötige Hausangabe |
|---|---|
| Können wir einen Saal mieten, was kostet das? | Mietpreise, Kapazitäten, Rahmenbedingungen |
| Machen Sie Kindergeburtstage? | Angebot, Preise, Ablauf, Altersgrenzen |
| Wir sind eine Schulklasse und möchten vormittags kommen. | Schulvorstellungspraxis, Preise, Mindestgruppengröße, Terminfenster |
| Gibt es Begleitmaterial für den Unterricht? | Verweis auf VISION KINO |
| Können wir eine Firmenveranstaltung machen? | Angebot, Technik, Catering |
| Können wir unseren eigenen Film zeigen? | Voraussetzungen, Format, Rechtefrage |

Die gemeinnützige VISION KINO gGmbH koordiniert die SchulKinoWochen bundesweit, in Kooperation mit den Bildungs- und Kultusministerien der Länder, und stellt Unterrichtsmaterial bereit, der übliche Anknüpfungspunkt bei Schulanfragen. Schulveranstaltungen sind zusätzlich für die Förderdokumentation relevant.

## 10. Sonstiges und Organisatorisches

| Frage | Nötige Hausangabe |
|---|---|
| Ich habe etwas liegen gelassen. | Fundsachenweg |
| Ich möchte mich bewerben. | Kontaktweg, offene Stellen |
| Können wir bei Ihnen Werbung schalten? | Kinowerbung, Ansprechpartner |
| Läuft das Open-Air-Kino, was kostet es? | Saison, Preise, Decken- und Kissenverleih |
| Kann ich einen Film vorschlagen? | Wunschfilm-Praxis |
| Wie erreiche ich Sie? | Kontaktwege und Reaktionszeiten |

## 10a. Öffentliche Bewertungen

Ein eigener Block, weil die Antwort sichtbar bleibt und von künftigen Gästen gelesen wird.

| Fall | Nötige Hausangabe |
|---|---|
| Kritische Google-Bewertung zu Technik, Sauberkeit oder Personal | Kulanzrahmen, wer antwortet, Freigabeweg |
| Kritik am Programm oder an einer Filmauswahl | Haltung des Hauses zur Kuratierung |
| Sehr gute Bewertung | ob und wie das Haus antwortet |
| Bewertung, die auf einen falschen Umstand zielt | wer entscheidet, ob widersprochen wird |

Antworten auf öffentliche Bewertungen gehen nie ungeprüft raus. Der Kinoleitfaden führt Bewertungsmanagement über das Google-Business-Profil ausdrücklich als Marketingaufgabe.

## 11. Reklamationen

Keine Frageliste, sondern Fallgruppen: Technikprobleme (Bild, Ton, Klimatisierung), Störungen durch andere Gäste, Verspätung des Films, Verhalten des Personals, Falschauskunft, Ticket- oder Abrechnungsfehler, Sauberkeit.

Für jede Gruppe gilt: Was das Haus als Entgegenkommen anbietet, ist eine Leitungsentscheidung. Wenn im Hausprofil keine Kulanzregel steht, werden zwei Antwortvarianten geliefert und die Entscheidung bleibt beim Menschen.

## 12. Was regelmäßig fehlt

Erfahrungswerte für den Aufbau eines Hausprofils. Diese fünf Angaben fehlen fast immer und werden fast immer gebraucht:

1. Rollstuhlplatzzahl pro Saal und der Reservierungsweg
2. Die Ausnahmen bei Gutscheinen, Sonderveranstaltungen, Zuschläge, Feiertage
3. Abhol- und Stornofristen im Wortlaut
4. Saalmietpreise und was darin enthalten ist
5. Die Handhabung des Erziehungsbeauftragten an der Kasse
