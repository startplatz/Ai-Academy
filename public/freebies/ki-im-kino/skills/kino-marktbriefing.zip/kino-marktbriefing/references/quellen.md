# Geprüfte Quellen für das Markt- und Filmstart-Briefing

Stand der Prüfung: 18. August 2026. Alle Angaben wurden zu diesem Zeitpunkt verifiziert. Webseiten ändern sich, wenn eine URL nicht mehr passt, ist das ein Hinweis auf einen Umbau, nicht auf einen Fehler in diesem Skill.

**Eine Einschränkung vorweg, die für die Praxis wichtig ist:** Für keine der Quellen ließ sich ein RSS-Feed positiv verifizieren. Alle Quellen sind als HTML-Seiten frei zugänglich, aber es gibt keine dokumentierte Datenschnittstelle. Wer regelmäßig automatisiert abrufen will, sollte die Feed-Verfügbarkeit selbst testen und im Zweifel mit der HTML-Seite arbeiten.

## Inhalt

1. Starttermine und Änderungen
2. Charts und Besucherzahlen
3. Arthouse-News
4. Marktzahlen
5. Altersfreigaben
6. Anreicherung
7. Nicht verwenden
8. Empfohlener Ablauf

---

## 1. Starttermine und Änderungen

### AllScreens Kinofilmdatenbank — die Primärquelle
- **Starttermine:** https://allscreens.de/filmstarts
- **Änderungen:** https://www.allscreens.de/filmstarts/aktuelle-aenderungen
- **Zugang:** frei, ohne Login
- **Format:** HTML-Liste, gruppierbar nach Datum oder nach Verleih
- **Felder:** Titel und teils Originaltitel, Startdatum, Verleih, Kennzeichnung für Wiederaufführung und Neu, IMAX-Kennzeichnung, Trailer-Links über KinoCheck
- **Nicht enthalten:** FSK, Laufzeit, Fassungskennzeichnung
- **Besonders wertvoll:** Die Änderungsseite erlaubt Filterung nach Änderungsdatum von/bis und ein Verleiher-Dropdown mit über 300 Unternehmen. Damit sind Startterminverschiebungen systematisch auffindbar, die operativ wichtigste Wocheninformation.
- **Einschränkung:** keine dokumentierte API, kein Export, keine Angabe zur Aktualisierungsfrequenz

**Warum diese Quelle zuerst:** AllScreens ist der Verband Filmverleih und Audiovisuelle Medien, entstanden im Oktober 2023 aus der Fusion von VdF und BVV. Die Liste ist die offizielle der Verleiherseite. Bemerkenswert als Qualitätshinweis: programmkino.de, das Portal der AG Kino – Gilde, verlinkt für Filmstarts auf allscreens.de.

### insidekino D-Startplan
- **URL:** https://www.insidekino.de/DStarts/DStartplan.htm
- **Zugang:** frei, kostenlos, kein Login
- **Format:** HTML-Tabelle, Vorschau reichte bei Prüfung bis Dezember 2031
- **Besonderheit:** gliedert nach Segment, Mainstream, Family, Arthouse und Nische, Indies, Fremdsprache, Dokus, Events und Sondervorstellungen. Verleih als Kürzel (COL, SPL, BV, U, NCO).
- **Einschränkung:** Privatseite, betrieben seit 2001, keine institutionelle Gewähr. **Und wichtig: insidekino listet pro Woche deutlich weniger Titel als AllScreens oder filmstarts.de, weil nach Relevanz kuratiert wird.** Für ein Programmkino ist das ein Nachteil, für die Segmenteinordnung ein Vorteil.

### filmstarts.de Vorschau
- **URLs:** https://www.filmstarts.de/filme-vorschau/de/ (nach Woche), https://www.filmstarts.de/filme-vorschau/de/monat/ (nach Monat)
- **Zugang:** frei
- **Felder in der Liste:** Regie, Besetzung, Genre, Wertungen, Link zum Kinoprogramm. FSK, Laufzeit, Inhaltsangabe und Trailer stehen erst auf den Detailseiten.
- **Stärke:** vollständiger als insidekino
- **Einschränkung:** kommerzielles Medienportal der Webedia-Gruppe, keine offene Lizenz. Als Lesequelle für ein internes Briefing nutzbar; **systematisches automatisiertes Auslesen berührt die Nutzungsbedingungen** (https://www.filmstarts.de/services/nutzungsbedingungen/) und sollte vorher geprüft werden.
- **Hinweis zu falschen Pfaden:** `/kinofilme/demnaechst/` und `/kinostarts/` liefern 404. Nur `/filme-vorschau/de/` ist korrekt.

### Weitere freie Startlisten, nicht im Detail geprüft
filmdienst.de („Laufende Woche"), kino-zeit.de/filme/filmstarts/aktuell, only-entertainment.de/specials/starttermine. Existieren, Felder und Aktualität nicht verifiziert.

---

## 2. Charts und Besucherzahlen

### insidekino Wochencharts
- **Beispiel-URL-Muster:** https://www.insidekino.de/DTop10/26/DTop2026JUL16.htm
- **Felder:** Rang, Titel mit Verleih, Besucher am Wochenende, Besucher kumuliert, Leinwände und Kinos, Wochen im Einsatz, Bewertungen
- **Nutzen:** Die Charts weisen den Schnitt pro Kino bereits als eigene Spalte aus. Das ist die Kennzahl, mit der ein Haus seine eigene Performance einordnen kann, sie muss nicht nachgerechnet werden.
- **Einschränkung:** Privatseite. **Für Zahlen, die öffentlich zitiert werden, nicht als einzige Quelle verwenden.** Für die interne Einordnung gut geeignet.
- **Weiteres Angebot:** Charts aus über zwanzig Ländern, historische Charts seit 1954, Prognosen

### programmkino.de Arthouse Charts
Wöchentlich, frei zugänglich, für Arthouse-Häuser die relevantere Rangliste als die Gesamtcharts. Siehe Abschnitt 3.

---

## 3. Arthouse-News

### programmkino.de
- **URL:** https://www.programmkino.de/
- **Betreiber:** AG Kino – Gilde deutscher Filmkunsttheater
- **Zugang:** frei, Mitgliederbereich zusätzlich vorhanden
- **Rubriken:** News, Filmkritiken, Filme, wöchentliche Arthouse Charts, Brancheninfos zu Verbänden, Förderungen, Kinder- und Jugendkino
- **Newsletter:** wöchentlich, https://www.programmkino.de/#newsletter — für ein Briefing die bequemste Bezugsform
- **Einschätzung:** für Programm- und Arthouse-Häuser die passendste Newsquelle überhaupt

---

## 4. Marktzahlen

### FFA Marktdaten
- **URL:** https://www.ffa.de/marktdaten.html
- **Zugang:** ausdrücklich kostenfrei
- **Inhalte:** „Das Kinojahr" und „Das Kinojahr KOMPAKT" jährlich, Geschäftsbericht, **Filmhitlisten monatlich aktualisiert (Top 100 nach Besuch)**, Kinoergebnisse, Jahres- und Halbjahreshitlisten national und international
- **Format:** PDF, Hitlisten von 2013 bis laufend
- **Einschränkung:** kein Newsletter und kein Abo auf der Seite; erscheint in Intervallen, nicht wöchentlich. Für belastbare, zitierfähige Marktzahlen die erste Adresse.
- **Pressemitteilungen:** https://www.ffa.de/pressemitteilungen.html

### HDF KINO
- **URL:** https://hdf-kino.de/
- Marktzahlen auf Basis von Comscore Movies. **Weichen systematisch von den FFA-Zahlen ab, weil die Erhebungsbasis unterschiedlich ist.** Für 2025 etwa 89,2 Millionen Tickets (Comscore) gegenüber 91,9 Millionen (FFA). Beide Zahlen sind korrekt. Wenn beide in einem Briefing vorkommen, immer mit Quellenangabe und dem Hinweis auf die unterschiedliche Erhebung, nie vermischen.

---

## 5. Altersfreigaben

### FSK-Freigabensuche
- **URL:** https://www.fsk.de/freigabensuche/
- **Zugang:** frei, ohne Login
- **Suchbar nach:** Titel, Regie, FSK-Nummer, Inhaltstyp (Spielfilm, Dokumentarfilm, Kurzfilm, Serien, Musikclips, Trailer, Werbung), Freigabedatum von/bis
- **Felder:** mindestens Titel, Freigabedatum, Altersfreigabe
- **Einschränkung:** keine API, keine Downloads. Bei Entscheidungen vor 2003 können Laufzeit und Anbieter fehlen.
- **Detail, das Fachkunde zeigt:** Trailer und Werbung werden separat freigegeben und sind separat recherchierbar.

---

## 6. Anreicherung

### TMDB API
- **Doku:** https://developer.themoviedb.org/docs/region-support und https://developer.themoviedb.org/reference/movie-release-dates
- **Relevante Parameter:** `region` (ISO 3166-1, etwa `DE`), `language` (etwa `de-DE`), `with_release_type`, `release_date.gte` und `.lte`, kombinierbar auf `/discover/movie`. Der Endpunkt `/movie/{id}/release_dates` liefert länderspezifische Termine samt Certification, also die FSK-Angabe für Deutschland.
- **Zugang:** API-Key oder Access Token erforderlich

**Zwei Warnungen, die in der Praxis zählen:**

*Inhaltlich:* TMDB ist community-gepflegt. Deutsche Kinostarttermine sind dort erfahrungsgemäß unvollständiger und weniger aktuell als bei AllScreens, besonders bei kleinen Verleihen, Arthouse-Titeln, Wiederaufführungen und Sonderveranstaltungen, also genau bei dem, was ein Programmkino braucht. **TMDB deshalb nur zur Anreicherung verwenden: Poster, Synopsis, Trailer, Certification. Nicht als Startterminquelle.**

*Rechtlich:* Die TMDB-Nutzungsbedingungen ließen sich bei der Prüfung nicht abrufen. Die verbreitete Annahme „kostenlos für nichtkommerzielle Nutzung, kommerziell lizenzpflichtig, mit Attributionspflicht" ist damit **nicht verifiziert**. Vor produktiver oder kommerzieller Nutzung selbst prüfen.

---

## 7. Nicht verwenden

**the-spot-mediafilm.com (THE SPOT media & film).** Das Fachmedium selbst ist relevant, blickpunktfilm.de leitet seit Januar 2026 dorthin um, das gemeinsame Abo läuft seit 01.02.2026. Aber: Die Seite ist JavaScript-gerendert und liefert bei einfachem Abruf nur Metadaten, keine Inhalte. Teile liegen hinter einer Bezahlschranke. **Als automatisierte Newsquelle nicht nutzbar.** Menschlich lesen, ja. Automatisiert abrufen, nein.

**Comscore.** Die kommerzielle Referenz für Box-Office-Daten, Deutschland über Comscore Movies abgedeckt. Preise nicht öffentlich, nur über Vertrieb. **Nicht als Quelle für ein selbstgebautes Briefing einsetzbar.**

**filmecho/filmwoche.** Eingestellt. Existiert nicht mehr.

**kino&co.** Ein Publikumsmagazin, das kostenlos in Kinos auslegt, kein Fachmedium. Alle besprochenen Filme werden positiv bewertet, um zum Kinobesuch zu motivieren. Nicht als Branchenquelle zitieren.

**zurueckinskino.de.** War bei der Prüfung am 18.08.2026 nicht erreichbar. Vor einer Empfehlung prüfen.

---

## 8. Empfohlener Ablauf

**Minimalpfad, diese drei jede Woche:**

1. **AllScreens Änderungen:** Zeitraum seit dem letzten Briefing filtern. Dieser Block hat den höchsten operativen Wert, also zuerst.
2. **AllScreens Filmstarts**, kommende zwei bis vier Wochen als Basisliste.
3. **insidekino Wochencharts**, Zahlen der letzten Woche, Schnitt pro Kino aus der ausgewiesenen Spalte übernehmen.

**Nur auf Nachfrage oder bei erkennbarer Lücke:**

4. **insidekino D-Startplan**, Segmenteinordnung ergänzen.
5. **filmstarts.de Vorschau**, einzelne Titel gegenprüfen, wenn ein Titel zu fehlen scheint. **Nicht** die Liste systematisch auslesen, das berührt die Nutzungsbedingungen. Abweichungen benennen, nicht auflösen.
6. **programmkino.de**, Arthouse-News und Arthouse Charts.
7. **FFA**, nur wenn eine belastbare, zitierfähige Marktzahl gebraucht wird. Nicht wöchentlich.
8. **FSK-Freigabensuche**, punktuell für Titel, bei denen die Freigabe fehlt und relevant ist.
9. **TMDB**, nur zur Anreicherung, wenn Poster, Synopsis oder Certification gebraucht werden.

Für jeden genutzten Schritt notieren, ob er funktioniert hat. Was nicht funktioniert hat und was bewusst weggelassen wurde, kommt in den Abschnitt „Nicht abgedeckt" des Briefings, sonst wird das Briefing als vollständig gelesen.
