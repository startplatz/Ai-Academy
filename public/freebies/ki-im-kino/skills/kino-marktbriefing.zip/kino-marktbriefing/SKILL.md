---
name: kino-marktbriefing
description: Erstellt ein wöchentliches Markt- und Filmstart-Briefing für ein Kino, kommende Starttermine, Startterminverschiebungen, Chart-Entwicklung mit Besuchern pro Leinwand, Arthouse- und Branchennews, Altersfreigaben, als lesbares Briefing oder als HTML-Dashboard. Verwende diesen Skill, wenn jemand einen Überblick über kommende Filmstarts, ein Wochenbriefing, ein Dashboard, einen Marktüberblick, Branchennews oder eine Einordnung der eigenen Zahlen im Vergleich zum Markt braucht, oder Formulierungen nutzt wie "was startet demnächst", "Startterminverschiebungen", "wie läuft der Film woanders", "Marktüberblick", "Filmstart-Dashboard", "Wochenbriefing", "Konkurrenz beobachten", "Wettbewerbsanalyse".
compatibility: Benötigt Internetzugriff für die Web-Recherche. Ohne Netzzugang nur mit mitgelieferten Daten nutzbar.
license: CC-BY-4.0
metadata:
  author: STARTPLATZ AI Academy
  version: "1.0"
  startplatz-paket: Kino-Skill-Paket (KinoConnect, August 2026)
---

# Markt- und Filmstart-Briefing

Für einen Disponenten ist die teuerste Überraschung der Woche ein verschobener Starttermin. Danach kommt die Frage, wie ein Titel woanders läuft, bevor man über Verlängerung oder Absetzung entscheidet. Beides ist aus frei zugänglichen Quellen zu holen, kostet aber jede Woche Zeit. Dieser Skill bündelt das.

Die geprüften Quellen mit Erreichbarkeit, Feldern und Einschränkungen stehen in `references/quellen.md`. **Lies diese Datei, bevor du Daten holst**, sie enthält die konkreten URLs und mehrere Warnungen, die vor Fehlschlüssen bewahren.

## Bevor du anfängst: die Ehrlichkeitsregel

Dieser Skill arbeitet mit öffentlichen Webseiten, nicht mit einer Datenschnittstelle. Daraus folgen zwei Dinge, die im Ergebnis sichtbar sein müssen:

**Jede Zahl bekommt eine Quelle und ein Abrufdatum.** Ein Briefing ohne Herkunftsangabe ist für eine Programmentscheidung unbrauchbar, weil niemand weiß, wie alt die Information ist.

**Was nicht erreichbar war, wird benannt.** Wenn eine Quelle nicht lädt, hinter einer Bezahlschranke liegt oder erkennbar veraltet ist, steht das im Briefing, nicht als Fußnote, sondern in einem Abschnitt „Nicht abgedeckt". Ein Briefing, das eine Lücke verschweigt, wird als vollständig gelesen und führt zu falschen Entscheidungen.

Wenn kein Netzzugang besteht, sag das sofort und arbeite mit den Daten, die der Mensch mitliefert. Erfinde unter keinen Umständen Starttermine, Besucherzahlen oder Verleihangaben, das sind Zahlen, auf deren Basis Geld ausgegeben wird.

## Aufbau des Briefings

Die Reihenfolge folgt der Dringlichkeit für den Betrieb, nicht der Verfügbarkeit der Daten.

### 1. Änderungen und Verschiebungen, zuerst
Verschobene, vorgezogene oder abgesagte Starttermine seit dem letzten Briefing. Diese Information hat den höchsten operativen Wert, weil sie Disposition und bereits produzierte Werbemittel betrifft. AllScreens führt dafür eine eigene Änderungsübersicht mit Filter nach Änderungsdatum und Verleih.

Für jede Änderung: Titel, alter Termin, neuer Termin, Verleih, und wenn erkennbar ein Hinweis, ob eigene Werbemittel betroffen sind.

### 2. Neustarts der kommenden zwei bis vier Wochen
Titel, Starttermin, Verleih, Fassungen wenn bekannt, FSK wenn bekannt. Sortiert nach Startdatum.

Zwei Segmentierungshinweise, die den Unterschied machen: insidekino gliedert nach Mainstream, Family, Arthouse und Nische, Indies, Fremdsprache, Dokus sowie Events und Sondervorstellungen, brauchbar für die Einordnung, aber die Liste ist kürzer, weil kuratiert. Für ein Programmkino ist Vollständigkeit wichtiger, dafür sind AllScreens und filmstarts.de besser. Nenne bei Abweichungen zwischen den Quellen die Abweichung statt eine Liste zu bevorzugen.

### 3. Wie läuft was — Chart-Einordnung
Aus den Wochencharts: Besucher am Wochenende, Besucher kumuliert, Zahl der Leinwände oder Kinos, Wochen im Einsatz.

Die nützlichste Kennzahl ist der **Schnitt pro Kino beziehungsweise pro Leinwand**, weil er vergleichbar macht. Die insidekino-Wochencharts weisen ihn bereits als eigene Spalte aus, übernimm ihn von dort. Nur wenn er fehlt, rechne ihn selbst und kennzeichne das. Wenn eigene Besucherzahlen mitgeliefert werden, stelle sie daneben, das ist die praktikable, kostenlose Marktbeobachtung für ein kleines Haus.

### 4. Branchennews
Kurz und gefiltert. Drei bis fünf Meldungen, die eine Konsequenz für den Betrieb haben: Förderfristen, Verbandsmeldungen, Aktionstage, Verleihentscheidungen, Marktzahlen. Keine Personalien ohne Betriebsbezug, keine internationale Box-Office-Folklore.

Für Arthouse-Häuser ist programmkino.de von der AG Kino – Gilde die passendste Newsquelle, inklusive wöchentlicher Arthouse Charts.

### 5. Was daraus folgt
Zwei bis vier Sätze mit Handlungsbezug: welcher Titel eine Verlängerung wert wäre, wo ein Werbemittel angepasst werden muss, welche Frist ansteht, welcher Titel für eine Reihe interessant sein könnte. Formulierungen wie „der Markt entwickelt sich" helfen niemandem.

Ohne diesen Block ist das Briefing eine Datensammlung. Schreibe ihn auch dann, wenn nur zwei Quellen geliefert haben.

### 6. Nicht abgedeckt
Quellen, die nicht erreichbar waren. Angaben, die fehlen. Zeitraum, für den keine Daten vorliegen.

## Marktbeobachtung statt Wettbewerbsanalyse

Wenn jemand eine „Konkurrenzanalyse" verlangt, ist eine kurze Einordnung angebracht, weil die Erwartung sonst nicht erfüllbar ist.

Frei verfügbar ist: welche Titel breit laufen und wie lange, Chart-Performance pro Leinwand, öffentliche Preis- und Ermäßigungsstrukturen anderer Häuser, deren Reihen und Sonderformate, deren Social-Media-Aktivität. Das ist substanziell und für die eigene Positionierung ausreichend.

Nicht frei verfügbar ist: Besucherzahlen eines einzelnen anderen Hauses, deren Auslastung, deren Verleihkonditionen. Diese Daten sind ein kommerzielles Produkt, Comscore bietet Kinobetreibern ausdrücklich Einsicht in die Wettbewerbslandschaft an, zu nicht öffentlichen Preisen. Wer sie ohne Abo verspricht, verspricht etwas, das nicht geliefert werden kann.

Der zweite Grund für Zurückhaltung ist die Branchenkultur: Der Kinoleitfaden rahmt Wettbewerbsbeobachtung als Positionierungsaufgabe über SWOT und Value Proposition, nicht als Spionage. Und in einer Branche mit gemeinsamen Verbandsaktionen wie DAS KINOFEST und Abo-Verbünden wie Cineville klingt aggressive Wettbewerbsrhetorik fremd.

Der strukturell wichtigere Wettbewerbsfaktor ist ohnehin ein anderer: 2025 sind rund 1.007 Filme gestartet, bei begrenzter Leinwandzeit. Für ein kleines Haus ist Wettbewerb vor allem ein Auswahl- und Kommunikationsproblem, kein Beobachtungsproblem.

## HTML-Dashboard

Wenn ein Dashboard gewünscht ist, baue eine einzelne, in sich geschlossene HTML-Datei, Styles und Skripte inline, keine externen Abhängigkeiten. Sie soll sich per Doppelklick öffnen und weiterschicken lassen.

Aufbau von oben nach unten, in der Reihenfolge der Dringlichkeit:
1. Kopfzeile mit Kalenderwoche, Zeitraum und Erstellungsdatum
2. Änderungen und Verschiebungen, farblich hervorgehoben, der Block, auf den zuerst geschaut wird
3. Startkalender als Tabelle, sortierbar nach Datum
4. Chart-Tabelle mit Spalte für den Schnitt pro Leinwand
5. News als kurze Liste mit Quellenlink
6. Fußzeile mit allen Quellen und Abrufzeitpunkten

Gestalterisch zurückhaltend: keine Verlaufsflächen, keine dekorativen Diagramme, ausreichend große Schrift, ausreichender Kontrast. Ein Diagramm nur dort, wo eine Entwicklung über Zeit gezeigt wird, für Tabellendaten ist eine Tabelle besser lesbar als ein Balkendiagramm. Jede Zahl im Dashboard trägt ihre Quelle, entweder direkt oder über die Fußzeile.

## Rhythmus

Sinnvoll ist ein Lauf am Montag oder Dienstag, weil dann die Einsätze ab Donnerstag verhandelt werden und die Verschiebungsinformation den größten Wert hat. Frag beim ersten Lauf nach dem gewünschten Rhythmus und dem Zeitraum.

**Zum Block „Änderungen":** Du kannst zwischen zwei Sitzungen nichts speichern. Bitte deshalb am Ende jedes Briefings darum, es abzulegen und beim nächsten Lauf mitzuliefern, dann lassen sich Änderungen wirklich vergleichen. Liegt kein Vorlauf-Briefing vor, arbeite mit einem ausdrücklich genannten Stichtag und schreibe ihn ins Briefing.

## Umfang: Minimalpfad zuerst

Neun Quellen pro Woche kosten mehr Zeit, als sich wöchentlich durchhalten lässt. Der Minimalpfad deckt den größten Teil des Nutzens ab:

1. AllScreens Änderungsübersicht, für Block 1
2. AllScreens Filmstartliste, für Block 2
3. insidekino Wochencharts, für Block 3

Alles darüber hinaus, Gegenprüfung bei filmstarts.de, Segmenteinordnung, Arthouse-News, FFA-Marktzahlen, FSK-Freigaben, TMDB-Anreicherung, hol nur auf Nachfrage oder wenn der Minimalpfad eine erkennbare Lücke lässt. Sag dann im Briefing, welche Quellen genutzt wurden.

Eine Einschränkung zur Gegenprüfung: filmstarts.de ist ein kommerzielles Portal. Einzelne Titel dort nachzusehen ist unproblematisch, das systematische Auslesen der Liste berührt die Nutzungsbedingungen. Nutze die Seite also punktuell, nicht als zweite Vollquelle.
