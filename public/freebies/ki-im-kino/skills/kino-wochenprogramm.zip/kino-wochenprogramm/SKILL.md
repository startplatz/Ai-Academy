---
name: kino-wochenprogramm
description: Erzeugt aus dem fixierten Spielplan einer Kinowoche alle Textkanäle auf einmal, Website, Schaukasten-Aushang, Programmflyer, Newsletter-Abschnitt und Social-Posts, jeweils kanalgerecht formuliert und in der Tonalität des Hauses. Verwende diesen Skill, sobald jemand ein Wochenprogramm, einen Programmaushang, Programmtexte oder die Ankündigung der neuen Filmwoche braucht, einen Spielplan als Tabelle oder Liste liefert, oder Formulierungen nutzt wie "neue Woche", "ab Donnerstag", "Programm für nächste Woche", "Aushang", "Text für den Kasten draußen", "Programmtext", "Programminfo für das Stadtmagazin", "Wochenprogramm fertig machen". Für das vollständige Mailing mit Betreffzeilen ist kino-newsletter zuständig, für einen mehrwöchigen Postingplan kino-social-redaktionsplan.
license: CC-BY-4.0
metadata:
  author: STARTPLATZ AI Academy
  version: "1.0"
  startplatz-paket: Kino-Skill-Paket (KinoConnect, August 2026)
---

# Wochenprogramm für alle Kanäle

Die Kinowoche läuft von Donnerstag bis Mittwoch. Neustarts kommen donnerstags, und in vielen Häusern werden montags die Einsätze ab Donnerstag verhandelt. Daraus folgt der Engpass: Der komplette Textbedarf einer Woche entsteht zwischen Montag und Mittwoch, und er muss über fünf Kanäle hinweg dasselbe sagen, ohne fünfmal gleich zu klingen.

Genau das leistet dieser Skill. Er ersetzt nicht die automatische Filmdatenbank eines Kino-CMS, die liefert Plakate, Trailer und generische Inhaltsangaben ohnehin. Der Wert liegt in dem, was kein Automat wissen kann: warum dieser Film in diesem Haus in dieser Woche läuft.

## Zuerst: Hausprofil und Spielplan

Lies `hausprofil.md`, wenn eine vorhanden ist (Arbeitsverzeichnis, Uploads, Projektordner). Besonders relevant sind die Abschnitte Tonalität, Preise, Reihen, Fassungen und Verbindliche Regeln.

Ohne Hausprofil arbeitest du weiter, aber bitte darum, `hausprofil.md` an die Unterhaltung anzuhängen oder im Projekt zu hinterlegen, und frag zuerst die vier Angaben ab, ohne die die Texte beliebig bleiben: Name und Ort, Programmschwerpunkt, Anrede (Sie oder du), und ein Satz dazu, was das Haus von anderen unterscheidet. Weise darauf hin, dass sich das mit dem Hausprofil-Skill einmalig festhalten lässt.

Wenn nur ein einzelner Kanal gebraucht wird, etwa nur der Aushang für Donnerstag, liefere nur diesen. Ein Hinweis in einer Zeile genügt, dass die übrigen Kanäle konsistent nachgezogen werden können.

Der Spielplan kommt als Tabelle, Liste, Screenshot oder Export aus dem Kassensystem. Erwartbare Felder sind Titel, Tag, Uhrzeit, Saal, Fassung und FSK. Fehlt die Fassung oder die FSK, frag danach, statt zu raten, beides steht in vielen Häusern als verbindliche Angabe in den Regeln, und eine falsche FSK-Angabe ist ein echtes Problem, kein Schönheitsfehler.

## Wenn Drive verbunden ist

Falls ein Drive-Connector eingerichtet ist, lies den Spielplan direkt aus der Tabelle, statt kopierten Text zu erwarten. Bitte um den Dateinamen oder den Link und such nicht danach, das ist schneller und zuverlässiger. Google Sheets sind lesbar.

Was Drive nicht liefert: Bilder in Dokumenten werden nicht ausgewertet, nur Text. Und die Größe ist an das Kontextfenster gebunden, sehr große Tabellen brauchen einen Auszug.

Ergebnisse kannst du auf Wunsch als Datei zurück nach Drive schreiben. Frag vorher, wohin.

## Vor dem Schreiben: die redaktionelle Entscheidung

Ein Wochenprogramm ist keine Aufzählung, sondern eine Gewichtung. Bevor du Texte schreibst, entscheide und benenne kurz:

- **Was ist die Spitzenmeldung der Woche?** Der stärkste Neustart, ein besonderer Termin, ein Gast, eine Reihe. Genau eine Sache.
- **Was ist die zweite Meldung?** Meist etwas Kuratiertes, das ohne Hinweis untergeht.
- **Was läuft einfach weiter?** Das wird gelistet, nicht beworben.
- **Gibt es einen Anlass, der nichts mit den Filmen zu tun hat?** Ferienbeginn, Feiertag, Stadtfest, Wetterumschwung, Schuljahresstart. Das ist häufig der wirksamste Aufhänger, und keine Filmdatenbank kennt ihn.

Zeige diese Gewichtung dem Menschen, bevor du alle Kanäle produzierst. Wenn sie falsch ist, sind sonst fünf Texte falsch.

## Die fünf Kanäle

Jeder Kanal hat eine eigene Aufgabe. Denselben Text fünfmal leicht variiert auszugeben ist der häufigste Fehler und der Grund, warum solche Texte nach Maschine klingen.

### Website
Vollständig und nachschlagbar. Alle Titel mit Fassung, FSK, Laufzeit soweit bekannt, Spielzeiten pro Tag. Pro Film zwei bis drei Sätze, die einordnen statt zusammenzufassen, die Inhaltsangabe steht ohnehin schon in der Filmdatenbank. Am Anfang ein kurzer Wochenüberblick von drei bis vier Sätzen.

### Schaukasten-Aushang
Wird im Vorbeigehen gelesen, oft aus zwei Metern Entfernung. Titel, Tage, Uhrzeiten, Saal, Fassung. Keine Fließtexte. Höchstens eine Zeile Hervorhebung für die Spitzenmeldung. Gib das Ergebnis als klar strukturierte Liste oder Tabelle aus, die sich direkt in eine Vorlage setzen lässt.

### Programmflyer
Wie der Aushang, aber mit Platz für jeweils einen Satz pro Film und die Termine der Reihen. Wenn das Haus einen Zwei-Wochen- oder Monatsflyer macht, frag nach dem Zeitraum.

### Newsletter-Abschnitt
Nur der Programmteil, nicht der ganze Newsletter, für den vollständigen Aufbau inklusive Betreffzeilen ist der Newsletter-Skill zuständig. Hier geht es um den Block, der ins Mailing wandert: Wochenüberblick, Spitzenmeldung mit Empfehlung, dann die Liste. Persönlicher als die Website, weil die Empfänger das Haus kennen.

### Social-Posts
Drei Vorschläge, nicht dreißig. Einer zur Spitzenmeldung, einer zur kuratierten zweiten Meldung, einer zu einem Termin mit Anmeldebedarf (Reihe, Sonderveranstaltung, Schulvorstellung). Jeweils plattformneutral formuliert mit einem Hinweis, was für Instagram gekürzt und was für Facebook ausformuliert werden sollte. Für einen ganzen Redaktionsplan über mehrere Wochen ist der Social-Skill zuständig.

## Wie über Filme geschrieben wird

Der Unterschied zwischen einem Kinotext und einem Datenbankeintrag liegt in vier Dingen:

**Einordnen statt nachbeten.** Nicht die Handlung zusammenfassen, sondern sagen, für wen dieser Film ist und warum er im Programm steht. „Wer ‚X' mochte, wird hier fündig" leistet mehr als drei Sätze Plot.

**Der lokale Bezug, wenn es einen gibt.** Gedreht in der Region, Regisseur kommt aus der Stadt, Thema betrifft den Ort, passt zum Stadtjubiläum. Wenn es keinen gibt, keinen erfinden.

**Die Fassung ist Information, nicht Fußnote.** Bei OmU, OV und OmeU entscheidet die Fassung darüber, ob jemand kommt. Sie gehört in den Text, nicht in die Klammer am Ende.

**Nichts erfinden.** Keine Besetzungen, keine Laufzeiten, keine Preise, keine Auszeichnungen, keine Festivalteilnahmen, die nicht in den Eingaben stehen. Wenn eine Angabe fehlt und den Text tragen würde, markiere die Stelle sichtbar als Lücke, etwa mit `[Laufzeit prüfen]`. Ein Text mit sichtbaren Lücken ist in einer Redaktion arbeitsfähig, ein Text mit plausiblen Erfindungen ist gefährlich.

## Ausgabeformat

Gib die fünf Kanäle klar getrennt aus, mit Überschriften, damit die Blöcke einzeln kopiert werden können. Am Ende drei Zeilen:

- **Zu prüfen:** die markierten Lücken und Unsicherheiten
- **Nicht enthalten:** was bewusst weggelassen wurde und warum
- **Für nächste Woche:** was ins Hausprofil sollte, damit die Frage nicht wieder auftaucht

Am letzten Punkt hängt der Nutzen: Wenn dieselbe Korrektur zweimal kommt, gehört sie ins Profil und nicht in den Text.

## Wenn eine Vorgabe sich ändert

Häufiger Fall: Die Fassung wechselt, ein Termin wird zur Schulvorstellung, ein Film fällt aus, ein Gast kommt dazu. Ändere dann alle betroffenen Kanäle gemeinsam und zeige, was sich wo geändert hat. Inkonsistenz zwischen Website und Aushang ist der Fehler, der am Kassenschalter aufschlägt.

## Was dieser Skill nicht macht

Er entscheidet nicht über die Disposition. Welcher Film in welchem Saal zu welcher Zeit läuft, ist eine Verhandlungs- und Erfahrungsfrage mit Verleihbeziehungen, Publikumskenntnis und Saalökonomie. Er formuliert, was entschieden ist.
