# Förderprogramme für Kinos — Stand der Prüfung: 18. August 2026

**Diese Datei ist eine Orientierungshilfe, keine Richtlinie.** Alle Werte wurden am 18.08.2026 aus den unten genannten Quellen entnommen. Bedingungen, Fristen und Beträge ändern sich jährlich. Vor jeder Entscheidung die aktuelle Fassung bei der Förderstelle prüfen.

## Inhalt

1. Liebling Kino, Kinoprogrammprämie des Bundes
2. Kinoprogrammpreise des Bundes
3. Europa Cinemas
4. Zukunftsprogramm Kino I und II
5. FFA-Kinoprojekt- und Kinoreferenzförderung
6. Länderförderungen
7. Was welches Programm an Text verlangt
8. Quellen

---

## 1. Liebling Kino — Kinoprogrammprämie des Bundes

Getragen von der BKM, abgewickelt über die FFA. Das ist das Programm mit dem größten Textaufwand und dem größten Betrag.

**Zugangsvoraussetzungen**
- Sitz in einem Bundesland, das ein eigenes Kinoförderprogramm hat
- Im Schnitt 275 Vorführungen und mindestens 9 Monate fortlaufender Spielbetrieb in den letzten zwei Jahren
- Zuschauerschwellen für deutsche, europäische und künstlerisch-kreative Filme, je nach Gemeindegröße zwischen 40 und 60 Prozent

**Die Kategorisierung ist keine Ermessensfrage.** Ob ein Titel als deutscher, europäischer oder künstlerisch-kreativer Film zählt, richtet sich nach der Filmliste, die die FFA zur Prämie führt, nicht nach eigener Einschätzung. Ohne diese Liste lassen sich nur die eindeutigen Fälle zählen, alles andere gehört in „Zuordnung zu prüfen".

**Punkteschema**
- 1 Punkt pro Zuschauer bei deutschen oder europäischen Filmen
- 2 Punkte bei künstlerisch-kreativen Filmen
- 3 Punkte, wenn beides zutrifft
- Aufschlag 20 Prozent für Kinos mit maximal 2 Leinwänden
- Aufschlag 20 Prozent pro erfülltes Kulturkriterium, maximal 5 Kriterien
- Mindestens 2.500 Prämienpunkte erforderlich

**Obergrenze**
1,50 Euro pro Besucher beziehungsweise 150.000 Euro pro Kino.

**Booster-Kriterien, mindestens zwei müssen erfüllt sein.** Bei maximal 2 Leinwänden halbieren sich die Zahlen.

| Kriterium | Soll |
|---|---|
| Schulkinoveranstaltungen | 100 |
| Vorstellungen deutscher, europäischer oder künstlerisch-kreativer **Kinderfilme** | 100 |
| Vorstellungen Dokumentarfilm | 100 |
| Vorstellungen Kurzfilm | 100 |
| Vorstellungen Repertoirefilm | 50 |
| Kuratierte Kurzfilmabende | 12 |
| Filmreihen mit inhaltlichem Konzept | 4 |
| Veranstaltungen zu gesellschaftlich relevanten Themen | 12 |

**Einzureichen**
Kinobezogene Daten, eine Excel-Tabelle mit Zuschauerzahlen im vorgegebenen Format, Belege für die kulturellen Booster-Kriterien, und, sofern der Preis geltend gemacht wird, ein Scan der Urkunde des BKM-Kinoprogrammpreises.

**Die Preis-Urkunde ist keine Pflichtunterlage, sondern eine Erleichterung:** Wer im Vorjahr den BKM-Kinoprogrammpreis erhalten hat, für den gelten die Zuschauerschwellen als erfüllt. Häuser ohne Preis sind also nicht ausgeschlossen, sie müssen die Schwellen nur regulär nachweisen.

**Fristenlage 2026** (Stand 18.08.2026)
- Filmlistenmeldungen: bis 10. August 2026, also bereits abgelaufen
- Antragstellung: voraussichtlich ab September 2026 über das FFA-Serviceportal

→ **Praktische Folge:** Wer 2026 die Filmlistenmeldung verpasst hat, sollte prüfen, ob eine Nachmeldung möglich ist, und in jedem Fall die Dokumentation für den nächsten Zyklus jetzt beginnen. Die laufende Erfassung spart später die meiste Arbeit.

Quelle: https://www.ffa.de/kinoprogrammpraemie-des-bundes.html

---

## 2. Kinoprogrammpreise des Bundes

- Betrag: 2.500 bis 20.000 Euro
- Gegenstand: hervorragende Jahresfilmprogramme
- Bedeutung über den Betrag hinaus: Ein Preis aus dem Vorjahr ersetzt bei der Programmprämie den Nachweis der Zuschauerschwellen. Der Preis ist damit doppelt wertvoll, aber keine Voraussetzung.

**Nicht mit der Programmprämie verwechseln.** Prämie ist das besucherbasierte Punktesystem, Preis ist die Auszeichnung für das Jahresprogramm.

---

## 3. Europa Cinemas

- Betrag: bis 15.500 Euro für Ein-Saal-Kinos, bis 28.000 Euro bei maximal 7 Leinwänden
- Voraussetzung: Mitgliedschaft
- Nachweispflicht: Mitgliedskinos reichen Anfang jedes Jahres eine detaillierte Übersicht des Vorjahresprogramms ein, **aufgeschlüsselt nach Produktionsländern**

→ Die Aufschlüsselung nach Produktionsländern ist eine andere Sortierung als die der Bundesprämie. Wer beide Programme nutzt, sollte die laufende Erfassung von Anfang an so anlegen, dass das Produktionsland mitläuft, sonst muss die Liste zweimal aufgearbeitet werden.

---

## 4. Zukunftsprogramm Kino I und II

- Betrag: bis zu **40 Prozent** der förderfähigen Kosten, maximal **60.000 Euro für Ein-Saal-Kinos** beziehungsweise **45.000 Euro pro Leinwand** ab zwei Sälen
- **Wichtig, Stand 08/2026: Eine Antragstellung ist derzeit nicht möglich:** laut FFA übersteigt die Antragslage die eingeplanten Haushaltsmittel von 10 Millionen Euro.
- Die vielfach zitierten 80 Prozent betrafen das ältere Zukunftsprogramm Kino I, nicht das aktuelle Programm II.
- Gegenstand: Modernisierung, Barrierefreiheit, Marketing
- Anders als die Programmförderung ist das Investitionsförderung, der Textbedarf liegt bei Vorhabenbeschreibung und Verwendungsnachweis, nicht bei der Programmauswertung

Kontext: HDF KINO beziffert, gestützt auf eine FFA-Studie, den jährlichen Investitionsbedarf bei Standort-Modernisierungen auf 110 Millionen Euro und verweist darauf, dass Modernisierung Besucherzahlen um bis zu 30 Prozent steigern kann. Das ist ein brauchbares Argument in einer Vorhabenbeschreibung.

Quelle: https://www.ffa.de/zukunftsprogramm-kino-2.html

---

## 5. FFA-Kinoprojekt- und Kinoreferenzförderung

- **Kinoprojektförderung:** bis 50 Prozent der Kosten, projektbezogen
- **Kinoreferenzförderung:** jährlich, Referenzpunkte werden aus Besucherzahlen europäischer und deutscher Filme errechnet

Die Referenzförderung nutzt eine ähnliche Logik wie die Programmprämie, aber eine andere Berechnung. Zahlen aus einem Programm nicht ungeprüft in ein anderes übertragen.

---

## 6. Länderförderungen

Jedes Bundesland legt einen eigenen Kinoprogrammpreis und Investitionszuschüsse auf, üblicherweise mit Förderquoten zwischen 30 und 50 Prozent. Das ist gleichzeitig relevant für die Bundesprämie, deren Zugangsvoraussetzung ein bestehendes Landesprogramm ist.

Die konkreten Bedingungen unterscheiden sich erheblich. Bei einer Anfrage zuerst das Bundesland klären, dann gezielt recherchieren, eine pauschale Aussage über Länderförderung ist wertlos.

Quelle für den Überblick: https://kinoleitfaden.de/kapitel/kinofoerderung

---

## 7. Was welches Programm an Text verlangt

| Programm | Zahlenarbeit | Textarbeit | Wiederkehrend |
|---|---|---|---|
| Liebling Kino | hoch — Zuschauer nach Kategorien, Excel im Vorgabeformat | hoch — Programmkonzept, Reihenbegründungen, Kriterienbelege | jährlich |
| Kinoprogrammpreise | mittel | hoch — Bewerbungstext zum Jahresprogramm | jährlich |
| Europa Cinemas | hoch — Programmübersicht nach Produktionsländern | mittel | jährlich, Anfang des Jahres |
| Zukunftsprogramm Kino | mittel — Kostenaufstellung | hoch — Vorhabenbeschreibung, Verwendungsnachweis | pro Vorhaben |
| Kinoprojektförderung | mittel | hoch | pro Projekt |
| Kinoreferenzförderung | hoch | gering | jährlich |
| Länderprogramme | unterschiedlich | unterschiedlich | meist jährlich |

**Die Struktur für die laufende Erfassung**, die alle Programme gleichzeitig bedient:

| Datum | Titel | Produktionsland | Kategorie | Reihe / Anlass | Kooperationspartner | Besucher | Ein Satz Begründung |
|---|---|---|---|---|---|---|---|

Die Spalte Produktionsland kostet nichts und rettet die Europa-Cinemas-Meldung. Die Spalte Begründung kostet einen Satz und rettet die Reihennachweise.

---

## 8. Quellen

- FFA Kinoprogrammprämie des Bundes: https://www.ffa.de/kinoprogrammpraemie-des-bundes.html
- FFA Zukunftsprogramm Kino 2: https://www.ffa.de/zukunftsprogramm-kino-2.html
- FFA Marktdaten und Pressemitteilungen: https://www.ffa.de/marktdaten.html · https://www.ffa.de/pressemitteilungen.html
- Kinoleitfaden, Kapitel Kinoförderung: https://kinoleitfaden.de/kapitel/kinofoerderung
- HDF KINO zum deutschen Kinomarkt 2025: https://hdf-kino.de/deutscher-kinomarkt-2025/
- VISION KINO gGmbH, SchulKinoWochen: https://www.visionkino.de/schulkinowochen/

Alle abgerufen am 18.08.2026.
