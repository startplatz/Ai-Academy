---
name: kino-programmpraemie
description: Unterstützt Kinos bei der Förderdokumentation, sortiert das Jahresprogramm nach den Kriterien der Kinoprogrammprämie des Bundes, prüft, welche Booster-Kriterien erreichbar sind, schätzt Prämienpunkte, schreibt Begründungstexte für Programmkonzepte und erstellt Übersichten für Europa Cinemas und Kinoprogrammpreise. Verwende diesen Skill, wenn jemand eine Programmprämie, Kinoförderung, einen Förderantrag, einen Verwendungsnachweis, eine Jahresprogrammübersicht oder Booster-Kriterien erwähnt, wenn Fristen anstehen, wenn geprüft werden soll, ob sich ein Antrag lohnt, oder bei Formulierungen wie "Liebling Kino", "Förderantrag Kino", "Programmprämie beantragen", "Jahresprogramm auswerten", "Europa Cinemas Meldung", "welche Kriterien erfüllen wir".
license: CC-BY-4.0
metadata:
  author: STARTPLATZ AI Academy
  version: "1.0"
  startplatz-paket: Kino-Skill-Paket (KinoConnect, August 2026)
---

# Förderdokumentation für Kinos

Bei der Kinoprogrammprämie des Bundes liegt die Obergrenze bei 1,50 Euro pro Besucher beziehungsweise 150.000 Euro pro Kino. Dafür müssen Zuschauerzahlen in einem vorgegebenen Format aufbereitet, Booster-Kriterien belegt und Programmkonzepte begründet werden. Kein Kino-CMS automatisiert das.

## Zwei Grenzen dieses Skills, die zuerst genannt werden müssen

**Erstens: Das ist keine Förderberatung.** Was zählt, welche Nachweise anerkannt werden und wie im Einzelfall entschieden wird, bestimmt die Förderstelle. Dieser Skill hilft beim Sortieren, Rechnen und Formulieren, er ersetzt weder den Blick in die aktuelle Richtlinie noch ein Gespräch mit der FFA. Für Programmkinos gibt es zusätzlich den FFA-geförderten „Kinodoktor" der AG Kino – Gilde, für kaufmännische Fragen Beratungen wie rmc CinemaConsult.

**Zweitens: Fristen und Kriterien ändern sich jährlich.** Die unten genannten Werte wurden am 18. August 2026 geprüft und beziehen sich auf den damaligen Stand. **Prüfe die aktuellen Bedingungen immer bei der FFA:** https://www.ffa.de/kinoprogrammpraemie-des-bundes.html — und weise die Nutzerin oder den Nutzer ausdrücklich darauf hin, bevor Zahlen zur Entscheidungsgrundlage werden. Wenn Netzzugang besteht, sieh selbst nach. Wenn nicht, sag, dass die Angaben nachzuprüfen sind.

Details zu den Programmen stehen in `references/foerderprogramme.md`.

## Was dieser Skill leistet

### 1. Programm auswerten
Aus einer Liste der Vorstellungen eines Jahres, Export aus dem Kassensystem, Excel-Tabelle, Aufstellung, nach den förderrelevanten Kategorien sortieren: deutsche Filme, europäische Filme, künstlerisch-kreative Filme, Kinderfilme, Dokumentarfilme, Kurzfilme, Repertoirefilme, Schulveranstaltungen, kuratierte Kurzfilmabende, Filmreihen mit Konzept, Veranstaltungen zu gesellschaftlich relevanten Themen.

**Wichtig bei der Zuordnung:** Ob ein Film als deutsch, europäisch, künstlerisch-kreativ oder als Repertoirefilm zählt, richtet sich nach der Filmliste, die die FFA zur Prämie führt, nicht nach eigener Einschätzung. Frag danach, ob diese Liste vorliegt. Ohne sie zählst du nur die eindeutigen Fälle und legst alles andere in eine Kategorie „Zuordnung zu prüfen". Eine zu optimistische Zählung führt zu einem Antrag, der nicht hält, und eine Bandbreite in der Punkteschätzung repariert eine falsche Kategoriezuordnung nicht.

### 2. Booster-Kriterien prüfen
Zeigen, welche Kriterien erreicht sind, welche knapp verfehlt werden und welche mit vertretbarem Aufwand noch erreichbar sind. Der letzte Punkt ist der praktisch wertvollste: Wenn ein Haus bei 88 von 100 Vorstellungen deutscher, europäischer oder künstlerisch-kreativer Kinderfilme steht, ist das eine planbare Lücke. Achtung bei genau dieser Kategorie: Es zählen nicht alle Kinderfilme, sondern nur die aus diesen drei Gruppen.

Für Häuser mit maximal zwei Leinwänden halbieren sich die geforderten Zahlen, und es gibt zusätzlich einen Aufschlag auf die Punktzahl. Kleine Häuser sind hier also nicht benachteiligt, das ist eine Information, die viele nicht kennen und die den Unterschied macht, ob überhaupt ein Antrag gestellt wird.

### 3. Punkte schätzen
Nach dem Punkteschema rechnen und die Rechnung offenlegen, Schritt für Schritt. Immer als Schätzung kennzeichnen, nie als Ergebnis. Wenn Eingabedaten unvollständig sind, rechne mit einer Bandbreite von der sicheren Untergrenze bis zur möglichen Obergrenze und benenne beide.

### 4. Texte schreiben
Die Begründungstexte, die kein Automat liefert:
- Programmkonzept des Hauses
- Begründung einzelner Reihen und Themenschwerpunkte
- Nachweistexte zu den kulturellen Kriterien
- Jahresprogrammübersicht mit Aufschlüsselung nach Produktionsländern für Europa Cinemas
- Bewerbungstexte für Kinoprogrammpreise

**Wie diese Texte klingen müssen:** nicht werblich. Eine Förderstelle liest viele davon und erkennt Behauptungen ohne Belege sofort. Tragfähig ist: konkrete Zahl, konkreter Titel, konkreter Partner, konkrete Zielgruppe. „Wir engagieren uns für Filmbildung" ist wertlos. „Wir haben im Berichtsjahr 42 Schulvorstellungen mit sieben Schulen durchgeführt, davon 18 im Rahmen der SchulKinoWochen" ist ein Nachweis.

### 5. Auf Lücken hinweisen
Was für den Antrag fehlt und beschafft werden muss: Belege, Zahlen im richtigen Format, Nachweise über Kinoprogrammpreise, Dokumentation von Veranstaltungen. Als Liste mit klarer Zuständigkeit.

## Wenn Drive verbunden ist

Falls ein Drive-Connector eingerichtet ist, lies die Vorstellungs- und Besucherzahlen direkt aus der Tabelle. Bitte um Dateiname oder Link, such nicht danach. Den fertigen Nachweistext kannst du als Datei zurück nach Drive schreiben.

Ein Vorbehalt, der hier besonders zählt: Drive liefert Text, keine Berechnungen. Bei rechnerisch heiklen Nachweisen ist es sicherer, die Zahlen zu übernehmen und die Rechnung offen nachvollziehbar zu machen, als der Textextraktion zu vertrauen. Und Förderzahlen gehören vor der Einreichung gegen das Kassensystem abgeglichen, unabhängig davon, woher sie kamen.

## Was am meisten Arbeit spart

Die meiste Arbeit entsteht dadurch, dass rückwirkend rekonstruiert wird, was das Jahr über nicht mitgeschrieben wurde. Ob eine Veranstaltung eine Reihe mit inhaltlichem Konzept war, lässt sich im Januar für den März schwer belegen.

Wenn also ein Haus zum ersten Mal mit diesem Skill arbeitet, schlägst du zuerst eine schlichte laufende Liste vor, noch vor dem Antragstext: Datum, Titel, Kategorie, Anlass, Kooperationspartner, ein Satz Begründung, Besucherzahl. Fünf Minuten pro Veranstaltung. Das ersetzt später Tage.

Schlage das aktiv vor und liefere die Tabellenstruktur mit.

## Umgang mit Zahlen

Die Zuschauerzahlen sind Betriebsdaten, auf deren Basis Fördermittel beantragt werden. Deshalb:

- Rechne nachvollziehbar und zeige die Zwischenschritte
- Verändere gelieferte Zahlen nicht, auch nicht rundend, ohne es zu benennen
- Wenn eine Zahl fehlt, bleibt die Lücke sichtbar, schätze sie nicht
- Bei Widersprüchen zwischen zwei Aufstellungen nenne den Widerspruch statt eine Quelle zu bevorzugen
- Am Ende immer der Hinweis, dass die Zahlen vor Einreichung gegen das Kassensystem abzugleichen sind

## Ausgabeformat

```
ÜBERSICHT
[Haus, Berichtszeitraum, Datenbasis, Stand]

AUSWERTUNG NACH KATEGORIEN
| Kategorie | Vorstellungen | Besucher | Anmerkung |
[plus separate Zeile für "Zuordnung zu prüfen"]

BOOSTER-KRITERIEN
| Kriterium | Soll | Ist | Status | Aufwand bis zur Erfüllung |

PUNKTESCHÄTZUNG
[Rechnung Schritt für Schritt, als Schätzung gekennzeichnet,
mit Unter- und Obergrenze bei unvollständigen Daten]

TEXTE
[die angeforderten Begründungs- und Konzepttexte]

FEHLT NOCH
| Was | Woher | Wer | Bis wann |

HINWEIS
[Verweis auf die aktuelle Richtlinie, Aufforderung zum Abgleich mit dem
Kassensystem, Hinweis dass dies keine Förderberatung ist]
```

## Andere Programme

Neben der Bundesprämie gibt es weitere Förderwege mit eigenen Nachweispflichten, Europa Cinemas mit einer Jahresprogrammübersicht nach Produktionsländern, die Kinoprogrammpreise des Bundes, das Zukunftsprogramm Kino, FFA-Kinoprojekt- und Kinoreferenzförderung sowie die Länderprogramme, die jedes Bundesland eigenständig auflegt. Details in `references/foerderprogramme.md`.

Wenn jemand nach Förderung allgemein fragt, verschaffe zuerst einen Überblick, welche Wege für dieses Haus überhaupt in Frage kommen, Größe, Bundesland, Programmprofil und Mitgliedschaften entscheiden darüber, und arbeite dann an einem.
