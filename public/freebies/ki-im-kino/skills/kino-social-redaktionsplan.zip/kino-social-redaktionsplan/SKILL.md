---
name: kino-social-redaktionsplan
description: Baut einen Social-Media-Redaktionsplan für ein Kino über zwei bis vier Wochen, mit Postingterminen, Formatmischung, fertigen Textentwürfen und einem lokalen Dreh, der über die automatische Startankündigung aus dem CMS hinausgeht. Verwende diesen Skill, wenn jemand Social-Media-Posts, einen Postingplan, einen Redaktionsplan, Instagram- oder Facebook-Texte für ein Kino braucht, Content-Ideen sucht, aus einem Programm oder Filmstart-Briefing Posts ableiten will, oder Formulierungen nutzt wie "was posten wir", "Social Media Planung", "Instagram für unser Kino", "Redaktionsplan", "Content-Ideen", "Posts für die Reihe", "Reel-Idee", "Story zum Ferienstart", "Gewinnspiel". Für den Textblock einer einzelnen Programmwoche über alle Kanäle ist kino-wochenprogramm zuständig, für den mehrwöchigen Plan dieser Skill.
license: CC-BY-4.0
metadata:
  author: STARTPLATZ AI Academy
  version: "1.0"
  startplatz-paket: Kino-Skill-Paket (KinoConnect, August 2026)
---

# Social-Media-Redaktionsplan für ein Kino

Bevor dieser Skill arbeitet, gehört eine Einordnung dazu, weil sie über den Nutzen entscheidet.

Die generische Startankündigung ist in der deutschen Kinolandschaft ein gelöstes Problem. Cineprog erzeugt automatische Facebook-Posts für über 200 Kinos, CINEWEB bespielt Facebook, Instagram und Google und wirbt mit KI-Textunterstützung für Filmbeschreibungen, Compeso hat einen Marketing Hub mit Email Automation. Wer dafür einen Skill baut, baut etwas nach, das viele Häuser als Knopf im CMS haben.

Der zweite Punkt ist unbequemer: Nach Angaben des Kino-Marketing-Anbieters Kinobytes erzeugen Facebook-Anzeigen hohe Reichweite, aber weniger als 0,1 Prozent Klicks auf die Kinowebseite, während E-Mail auf rund 26 Prozent Öffnungsrate und rund 14 Prozent Klicks bezogen auf die Öffnungen kommt, das sind gut 3 Prozent aller Versandten. Social Media ist für ein Kino ein Sichtbarkeits- und Bindungskanal, kein Verkaufskanal.

Die Aufgabe dieses Skills sind deshalb **die Posts, die ein Automat nicht erzeugen kann.** Warum dieser Film in diesem Ort für dieses Publikum. Und die hauseigenen Formate, die es sonst nirgends gibt.

Wenn jemand nur eine Startankündigung braucht, sag das ehrlich und verweise auf das vorhandene System. Das kostet nichts und schafft Vertrauen.

## Zuerst

Lies `hausprofil.md`, wenn vorhanden, Tonalität, Emoji-Regel, Anrede, Reihen, verbotene Wörter. Ohne Profil bleiben die Texte austauschbar; frag dann kurz nach und bitte darum, die Datei an die Unterhaltung anzuhängen oder im Projekt zu hinterlegen.

Dann klären:
- **Zeitraum:** zwei bis vier Wochen sind praktikabel, länger veraltet
- **Kanäle:** Instagram, Facebook, TikTok, jeweils vorhanden oder nicht
- **Realistische Frequenz:** Der Kinoleitfaden empfiehlt, ein festes Stundenkontingent zu setzen, und nennt als Beispiel 20 Stunden monatlich für Social Media. Frag danach, statt einen Plan zu bauen, der nicht durchgehalten wird. **Ein Plan mit drei Posts pro Woche, der läuft, ist besser als einer mit zehn, der nach zwei Wochen liegen bleibt.**
- **Was schon vorliegt:** Spielplan, Reihentermine, ein Markt-Briefing, Fotos, Gäste, Kooperationen

## Wenn Notion oder eine Tabelle verbunden ist

Falls ein Notion-Connector oder Drive eingerichtet ist, leg den Plan dort an statt im Chat: eine Zeile oder Seite pro Post, mit Status. Der Nutzen zeigt sich beim zweiten Lauf, weil derselbe Skill dann den Ist-Stand liest und fortplant, statt bei Null anzufangen.

Dafür braucht es eine klare Struktur: Datum, Kanal, Format, Thema, Status, Material. Wenn keine existiert, schlage sie vor und leg sie an.

## Die Formatmischung

Ein Plan, der nur aus Filmstarts besteht, wirkt wie ein Werbekanal und wird entsprechend wenig beachtet. Tragfähig ist eine Mischung, in der die Filme höchstens die Hälfte ausmachen.

**Filmbezogen (etwa die Hälfte)**
- Neustart mit lokalem Dreh, siehe unten
- Kuratierte Empfehlung: warum dieser Titel im Programm steht
- Letzte Chance: der Titel läuft nur noch bis Mittwoch
- Reihe oder Sondertermin mit Anmeldebedarf
- Wiederaufführung mit Anlass

**Hauseigene Formate (etwa die Hälfte)**, das ist die Hälfte, die kein Automat liefern kann. Die folgende Liste orientiert sich an dem, was Kino-Marketingberatung für die Branche vorschlägt:
- Blick in die Projektion, Technik, den Vorführraum
- Team-Vorstellung, wer hier arbeitet
- Kinoalltag: Vorbereitung, Reinigung, Umbau, Plakatwechsel
- Foyer und Atmosphäre
- Speise- und Getränkeangebot
- Publikumsstimmen nach einer Vorstellung
- Filmtrivia mit Bezug zum aktuellen Programm
- Umfrage oder Abstimmung, etwa zur nächsten Wiederaufführung
- Ankündigung eines Events, gesprochen vom Team statt als Grafik
- Rückblick auf eine gelaufene Reihe

## Der lokale Dreh

Für jeden filmbezogenen Post die Frage: Was verbindet diesen Film mit diesem Ort und diesem Publikum? Mögliche Anschlüsse:

- Drehort, Herkunft von Beteiligten, regionale Bezüge im Stoff
- Anlass im Ort: Jubiläum, Stadtfest, Ferienbeginn, Schuljahresstart, Feiertag, Wetterlage
- Anschluss an eine eigene Reihe oder an einen Film, der hier gut lief
- Kooperationsmöglichkeit: Verein, Schule, Buchhandlung, Museum, Initiative zum Thema
- Publikumsbeobachtung: wer hier üblicherweise für so etwas kommt

Wenn es keinen echten Bezug gibt, wird keiner erfunden. Dann ist der ehrliche Weg die kuratierende Begründung: warum das Haus diesen Film zeigt. Das ist ein legitimer und wirksamer Post.

## Ausgabe

### Der Plan als Tabelle

| Datum | Wochentag | Kanal | Format | Thema | Anlass / lokaler Dreh | Material nötig |
|---|---|---|---|---|---|---|

An der Spalte **Material nötig** scheitern Pläne in der Praxis am häufigsten. Konkret benennen: Foto vom Team, Kurzvideo aus dem Vorführraum, Plakat, Trailer-Ausschnitt, Zitat einholen. Wenn ein Post Material braucht, das nicht existiert, gehört das in die Spalte und nicht in die Hoffnung.

Für die Terminierung: Die Kinowoche beginnt donnerstags, Neustarts kommen donnerstags. Ankündigungen brauchen also spätestens Mittwoch Vorlauf, Sondertermine mit Anmeldung deutlich mehr, eine bis zwei Wochen.

### Die Texte

Pro Post ein fertiger Entwurf. Grundfassung plattformneutral, dann jeweils ein kurzer Hinweis zur Anpassung:
- **Instagram:** erste Zeile trägt alles, weil der Rest abgeschnitten wird. Hashtags sparsam und nur ortsbezogen oder titelbezogen, Hashtag-Ketten wirken veraltet.
- **Facebook:** darf ausführlicher sein, Publikum ist im Schnitt älter, Termin- und Serviceinformationen funktionieren hier gut
- **TikTok:** nur wenn das Haus dort wirklich aktiv ist und Video produzieren kann. Ein Textplan für TikTok ohne Videokapazität ist Papier.
- **Stories und Reels:** Stories eignen sich für Kurzfristiges (heute noch Karten, Blick hinter die Kulissen, Umfrage-Sticker) und tauchen im Plan als eigene Zeile auf, weil sie anderes Material brauchen. Reels nur einplanen, wenn jemand filmen kann, sonst bleibt die Zeile leer und der Plan verliert Glaubwürdigkeit.

Was in jedem Post steht, wenn es um eine Vorstellung geht: Titel, Termin, Fassung. Die Fassung ist bei OmU, OV und OmeU der Grund, warum jemand kommt oder nicht kommt.

### Nichts erfinden

Keine Termine, keine Besetzungen, keine Auszeichnungen, keine Zitate von Gästen, keine Kooperationen, die nicht bestätigt sind. Erfundene Publikumsstimmen sind der schnellste Weg, Glaubwürdigkeit zu verlieren, wenn ein Zitat gebraucht wird, gehört „Zitat einholen" in die Materialspalte.

## Am Ende

Drei Zeilen:
- **Was zuerst produziert werden muss:** die zwei bis drei Posts mit Vorlauf
- **Was fehlt:** Material, Termine, Freigaben
- **Fürs Hausprofil:** wiederkehrende Korrekturen an Ton oder Formulierung

## Menschliche Endkontrolle

Alles, was rausgeht, wird vorher gelesen. Bei Social Media kippt die Tonalität am schnellsten, und ein Post lässt sich nicht zurückholen. Clare Reddington, Geschäftsführerin des Watershed in Bristol, formuliert es so: „Unser Ton, unsere Kommunikation mit dem Publikum und unsere Filmkuratierung sind das Wichtigste, das wir haben."
