---
name: kino-filmreihe
description: Entwickelt Konzepte für Filmreihen, Sonderveranstaltungen und Themenabende im Kino, mit Reihentitel, inhaltlicher Begründung, Titelauswahl, Terminlogik, Kooperationspartnern, Ankündigungstexten und Presseinfo, und mit Blick auf die Förderkriterien, für die solche Reihen dokumentiert werden müssen. Verwende diesen Skill, wenn jemand eine Filmreihe, einen Themenabend, eine Sonderveranstaltung, eine Kooperation oder ein Eventformat für ein Kino planen oder beschreiben will, ein Reihenkonzept begründen muss, Ideen für kuratierte Programme sucht, oder Formulierungen nutzt wie "Reihe planen", "Themenabend", "Sonderveranstaltung", "Kooperation mit", "Konzept für eine Reihe", "was können wir zum Thema X zeigen", "etwas zum Stadtjubiläum machen", "Filmfrühstück", "Ladies Night", "Sneak aufziehen". Auch dann, wenn eine Reihe nur gebraucht wird, um Förderkriterien zu erreichen.
license: CC-BY-4.0
metadata:
  author: STARTPLATZ AI Academy
  version: "1.0"
  startplatz-paket: Kino-Skill-Paket (KinoConnect, August 2026)
---

# Filmreihen und Sonderveranstaltungen

Reihen sind für ein Programmkino keine Kür. Bei der Kinoprogrammprämie des Bundes gehören unter den Booster-Kriterien ausdrücklich Größen wie vier Filmreihen mit inhaltlichem Konzept und zwölf Veranstaltungen zu gesellschaftlich relevanten Themen. Das heißt: Eine Reihe muss nicht nur stattfinden, sie muss **begründet und beschrieben** sein. Genau daran hängt Geld.

Und es heißt zweitens: Der Text, den dieser Skill erzeugt, hat zwei Adressaten. Das Publikum, das kommen soll. Und die Förderstelle, die die Begründung liest. Beide brauchen unterschiedliche Fassungen derselben Idee.

## Zuerst

Lies `hausprofil.md`, wenn vorhanden, Reihen, Programmschwerpunkt, Säle, Tonalität, Kooperationen. Eine neue Reihe soll zu den bestehenden passen oder bewusst danebenstehen; beides ist eine Entscheidung, die das Profil informiert.

Dann klären, sofern nicht mitgeliefert:
- Was ist der Ausgangspunkt, ein Thema, ein Anlass, ein einzelner Film, ein Partner, eine Förderlücke?
- Wie viele Termine und in welchem Rhythmus?
- Welcher Saal, und ist das eine Auslastungsfrage?
- Gibt es einen Partner oder soll einer gesucht werden?
- Muss die Reihe förderrelevant dokumentiert werden?

## Wenn der Kalender verbunden ist

Falls ein Kalender-Connector eingerichtet ist, hol die Termine daraus: freie Slots, Kollisionen mit Vermietungen, Sneak-Terminen und Feiertagen. Eine Reihe kann anschließend als Serientermin angelegt werden.

Zwei Bedingungen: Das setzt einen gepflegten Betriebskalender voraus. Liegt die Disposition im Ticketsystem und der Kalender ist nur eine Zweitschrift, verlass dich nicht darauf, sondern frag nach den Terminen. Und leg Termine nur an, wenn der Mensch es ausdrücklich will.

## Wie ein Reihenkonzept entsteht

Der häufigste Fehler bei Reihen ist die Themenklammer, die zu weit ist. „Filme über Freundschaft" ist keine Reihe, das ist eine Kategorie. Eine Reihe braucht eine Spannung, eine Perspektive oder eine Frage, an der die Titel etwas voneinander unterscheiden.

Prüfe jedes Konzept an drei Fragen, und schreibe die Antworten in das Ergebnis:

**Warum diese Filme zusammen?** Wenn die Antwort „sie behandeln alle X" ist, ist die Klammer zu weit. Tragfähig ist es, wenn die Titel sich gegenseitig verändern, wenn der zweite Film den ersten anders aussehen lässt.

**Warum hier und jetzt?** Ein Anlass macht aus einer Reihe ein Ereignis. Jahrestag, lokales Thema, gesellschaftliche Debatte, Jubiläum eines Films, ein Partner mit eigenem Anlass, eine Ausstellung in der Stadt.

**Wer kommt konkret?** „Ein interessiertes Publikum" reicht nicht. Gemeint sind die Leute, die schon zur letzten Reihe kamen. Die Schule, die das Thema behandelt. Der Verein, der dazu arbeitet. Die Altersgruppe, die laut FFA-Studie 2025 wächst: 50 bis 59 Jahre plus 18 Prozent, über 60 plus 13 Prozent, während die 20- bis 29-Jährigen um 7 Prozent zurückgingen. Wenn niemand konkret benennbar ist, ist die Reihe noch nicht fertig gedacht.

## Kooperationen

Ein Partner bringt vier Dinge, die ein Kino allein nicht hat: ein eigenes Publikum, Fachlichkeit für die Einführung, geteilten Aufwand und einen zweiten Kommunikationskanal. Er kostet Abstimmung.

Naheliegende Partner nach Thema: Schulen und Volkshochschulen, Vereine und Initiativen, Museen und Stadtarchiv, Buchhandlungen und Bibliotheken, Hochschulen und Fachbereiche, Beratungsstellen, Verbände, Stadtverwaltung und Gleichstellungsstellen, Religionsgemeinschaften, Sportvereine, Wirtschaftsförderung.

Für Schulveranstaltungen ist VISION KINO der etablierte Anknüpfungspunkt: Die gemeinnützige VISION KINO gGmbH koordiniert die SchulKinoWochen bundesweit, in Kooperation mit den Bildungs- und Kultusministerien der Länder, und stellt Unterrichtsmaterial bereit. Schulveranstaltungen sind zusätzlich förderrelevant.

Wenn ein Partner vorgeschlagen wird, benenne konkret, was er beiträgt und was er dafür bekommt. Eine Kooperation, die nur auf Logo-Tausch beruht, bringt kein Publikum.

## Rechte und Praktisches

Ein Punkt, der Konzepte scheitern lässt und deshalb früh geklärt werden muss: **Nicht jeder Titel ist verfügbar.** Bei älteren Filmen, Repertoire und Wiederaufführungen hängt es an Verleih und Rechtelage, bei manchen Titeln existiert keine spielbare Fassung mehr. Prüfe das nicht selbst, aber weise darauf hin und markiere Titel, bei denen Verfügbarkeit unklar ist, sichtbar als zu klären.

Ebenso zu klären: Fassung (OmU, OV, synchronisiert), FSK bei Schulveranstaltungen, Vorlauf für Gäste und Einführungen, ob eine Lizenz für nichtgewerbliche Vorführung nötig ist.

## Ausgabeformat

```
REIHENTITEL
[plus zwei Alternativen]

DIE IDEE IN ZWEI SÄTZEN
[für Publikum, ohne Fachsprache]

INHALTLICHE BEGRÜNDUNG
[fünf bis acht Sätze, die Fassung für Förderanträge und Presse.
Warum diese Klammer, warum diese Titel, welche Perspektive]

TITELAUSWAHL
| Termin | Titel | Fassung | Warum dieser Titel in dieser Reihe | Verfügbarkeit |
[Verfügbarkeit immer als offene Frage markieren, wenn nicht bestätigt]

TERMINLOGIK
[Rhythmus, Wochentag, Uhrzeit, mit Begründung. Bei älterem Publikum sind
frühe Termine relevant: laut FFA-Kinobesucherstudie 2019, zitiert im
Kinoleitfaden, bevorzugt fast ein Drittel des Publikums, insbesondere
Kinder und Menschen über 60, Vorstellungen vor 17 Uhr]

RAHMENPROGRAMM
[Einführung, Gast, Gespräch, Vorfilm, Ausstellung im Foyer, je Termin]

KOOPERATIONSPARTNER
[Vorschläge mit Beitrag und Gegenleistung, plus Ansprechweg]

ANKÜNDIGUNGSTEXTE
Website [ausführlich]
Newsletter [kurz, persönlich]
Social [drei Posts]
Aushang [eine Zeile plus Termine]

PRESSEINFORMATION
[knapp und präzise, das ist die Vorgabe des Kinoleitfadens für
Pressemitteilungen. Was, wann, warum jetzt, Zitatangebot, Kontakt.
Dazu ein Hinweis auf den Vorlauf: Stadtmagazine und Monatsprogramme
haben Redaktionsschlüsse, die typischerweise mehrere Wochen vor dem
Termin liegen. Frag danach und rechne rückwärts]

FÖRDERRELEVANZ
[Ob und wie diese Reihe zu Booster-Kriterien beiträgt, und was dafür
dokumentiert werden muss, siehe unten]

ZU KLÄREN
[Rechte, Verfügbarkeit, Gäste, Partner, Budget]
```

## Förderdokumentation gleich mitdenken

Wenn das Haus Programmprämie beantragt, sollte die Reihe von Anfang an so beschrieben werden, dass die Beschreibung später als Nachweis taugt. Konkret heißt das: das inhaltliche Konzept schriftlich, die Anzahl der Vorstellungen, die Zuordnung zu einer Kategorie (Kinderfilm, Dokumentarfilm, Kurzfilm, Repertoire, gesellschaftlich relevantes Thema), und ein Beleg, dass die Veranstaltung stattgefunden hat.

Was dafür ausreicht, entscheidet die Förderstelle, nicht dieser Skill. Für die vollständige Dokumentation gibt es den Programmprämien-Skill. Hier genügt der Hinweis, welche Angaben aufbewahrt werden sollten, damit sie später nicht rekonstruiert werden müssen.

## Nichts erfinden

Keine Filmtitel, bei denen unklar ist, ob sie existieren oder passen. Keine Auszeichnungen, Festivalteilnahmen oder Jahreszahlen ohne Grundlage. Keine Zitate. Keine Zusagen von Gästen oder Partnern. Bei Titelvorschlägen, deren Details unsicher sind, das kenntlich machen, ein Reihenkonzept mit fünf sicheren Titeln ist besser als eines mit zehn, von denen drei nicht stimmen.
