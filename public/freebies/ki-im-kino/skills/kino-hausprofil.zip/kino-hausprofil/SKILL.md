---
name: kino-hausprofil
description: Erstellt und pflegt das Hausprofil eines Kinos, die zentrale Faktendatei mit Sälen, Preisen, Ermäßigungen, Barrierefreiheit, Reihen, Tonalität und Sprachregeln, auf die alle anderen Kino-Skills zugreifen. Verwende diesen Skill, wenn jemand ein Hausprofil anlegen, erweitern oder aktualisieren möchte, wenn Preise oder Öffnungszeiten sich geändert haben, wenn ein anderer Kino-Skill Angaben vermisst, oder wenn jemand sagt, dass die erzeugten Texte nicht nach dem eigenen Haus klingen oder alle gleich klingen. Auch bei Formulierungen wie "unsere Daten hinterlegen", "warum kennt die KI unsere Preise nicht", "Tonalität festlegen", "Kinoprofil anlegen" oder "Onboarding für neue Mitarbeitende".
license: CC-BY-4.0
metadata:
  author: STARTPLATZ AI Academy
  version: "1.0"
  startplatz-paket: Kino-Skill-Paket (KinoConnect, August 2026)
---

# Hausprofil für ein Kino

Dieser Skill legt die Datei an, von der alle anderen Kino-Skills leben. Ohne Hausprofil erzeugen sie Texte, die für jedes Kino in Deutschland passen würden. Die Unterscheidbarkeit kommt aus dieser Datei, nicht aus den Skills.

Das Hausprofil ist bewusst eine schlichte Markdown-Datei namens `hausprofil.md`. Sie soll von Menschen gelesen und geändert werden können, ohne dass jemand ein Werkzeug öffnen muss.

**Wo die Datei liegt, hat Folgen.** Ein Skill hat in Claude oder ChatGPT kein dauerhaftes Arbeitsverzeichnis. Die Datei muss also entweder in einem Projekt hinterlegt sein oder bei jeder Unterhaltung angehängt werden. Sag das beim Übergeben ausdrücklich, sonst arbeiten die anderen Skills beim nächsten Mal wieder ohne Hausdaten. In Claude Code genügt es, die Datei im Projektordner zu haben. Wer sie pflegt, ist idealerweise die Person, die auch heute die Newsletter freigibt, die Aufgabe ist redaktionell, nicht technisch.

## Was in ein Hausprofil gehört und was nicht

Hinein gehören Betriebsdaten: Säle, Kapazitäten, Preise, Ermäßigungen, Technik, Barrierefreiheit, feste Termine, Reihen, Tonalität, Ansprechpartner nach Funktion.

Nicht hinein gehören personenbezogene Gästedaten. Keine Adresslisten, keine Newsletter-Empfänger, keine Buchungshistorien. Das Hausprofil beschreibt das Haus, nicht seine Gäste. Diese Trennung ist nicht nur datenschutzrechtlich sauber, sie hält die Datei auch klein und pflegbar.

## Vorgehen

### 1. Prüfen, ob schon eines existiert

Suche zuerst nach einer vorhandenen `hausprofil.md` im Arbeitsverzeichnis, in hochgeladenen Dateien oder im Projektordner. Wenn eine existiert, lies sie und arbeite daran weiter statt eine neue anzulegen. Bei einer Aktualisierung zeige, was sich ändert, bevor du schreibst, Preise und verbindliche Aussagen sollten nicht unbemerkt umgeschrieben werden.

### 2. Interview führen, aber in Etappen

Ein vollständiges Hausprofil auf einmal abzufragen überfordert. Frage in vier Etappen und schreibe nach jeder Etappe den entsprechenden Abschnitt, damit sichtbarer Fortschritt entsteht.

**Etappe 1, das Minimum für den ersten Nutzen.** Mit diesen fünf Angaben funktionieren die anderen Skills bereits brauchbar:
- Name des Hauses und Ort
- Säle mit Platzzahlen
- Ticketpreise und die wichtigsten Ermäßigungen
- Programmschwerpunkt in einem Satz (Arthouse, Mainstream, Mischung, kommunal)
- Wie das Haus klingt: eher sachlich, eher persönlich, eher kuratierend, und ein Beispieltext, der gut gefallen hat

**Etappe 2, Gästekommunikation.** Alles, was am Telefon oder per Mail gefragt wird: Öffnungszeiten der Kasse, Online-Ticketing und Gebühren, Reservierung und Abholfristen, Storno, Gutscheine mit Gültigkeit und Restbetragsregel, Kundenkarte, Barrierefreiheit inklusive Rollstuhlplätzen, Jugendschutzpraxis, Mitbringregeln, Hunde, Fundsachen, Saalmieten, Kindergeburtstage, Schulvorstellungen.

**Etappe 3, Programm und Kalender.** Wiederkehrende Reihen und ihre Termine, feste Sondertermine, Fassungen die angeboten werden (OmU, OV, OmeU), typische Wochenstruktur, Sneak-Preview-Praxis, Kooperationen wie Cineville oder MUBI GO, Beteiligung an KINOFEST oder SchulKinoWochen.

**Etappe 4, Sprache und Grenzen.** Das ist der Abschnitt, der die Texte wirklich unterscheidbar macht, und er wird meistens vergessen:
- Wörter und Wendungen, die das Haus benutzt
- Wörter, die das Haus nie benutzt (oft aufschlussreicher als die erste Liste)
- Anrede: Sie oder du, und ob das je nach Kanal wechselt
- Ob Emojis vorkommen und wo
- Wie über Filme gesprochen wird: bewertend, beschreibend, einordnend
- Welche Aussagen nie ohne Freigabe rausgehen

### 3. Beim Interview mitdenken statt nur abfragen

Frage nicht die Liste ab wie ein Formular. Wenn jemand sagt „wir sind ein Programmkino mit zwei Sälen", folgen daraus Nachfragen, die zeigen, dass du die Branche kennst: Ob der kleine Saal für Reihen genutzt wird. Ob es eine Stammgastbindung über eine Karte gibt. Ob das Haus Programmprämie beantragt, weil dann Reihen und Schulveranstaltungen dokumentiert werden müssen.

Wenn Angaben fehlen und nicht sofort zu beschaffen sind, schreibe sie als offene Punkte in den Abschnitt `## Offene Punkte` statt zu raten. Ein Hausprofil mit ehrlichen Lücken ist besser als eines mit erfundenen Zahlen, weil die anderen Skills die Lücken erkennen und benennen können.

### 4. Datei schreiben

Verwende diese Struktur. Sie ist so aufgebaut, dass die anderen Skills gezielt die Abschnitte lesen können, die sie brauchen.

```markdown
# Hausprofil: [Name] — [Ort]

Stand: [Datum], gepflegt von: [Funktion, nicht Personenname]

## Kurzbeschreibung
[Zwei bis drei Sätze: was für ein Haus, welches Publikum, welcher Schwerpunkt]

## Säle und Technik
| Saal | Plätze | Rollstuhlplätze | Technik / Besonderheiten |

## Preise und Ermäßigungen
[Regulär, ermäßigt und wofür, Zuschläge, Online-Gebühr, Gruppenpreise]

## Gutscheine und Kundenkarte
[Gültigkeit, Restbetragsregel, Einlösewege, Ausnahmen]

## Barrierefreiheit
[Rollstuhlplätze und Reservierungsweg, barrierefreie Toilette, Audiodeskription
und Untertitel-Apps, Induktionsschleife, Assistenzregelung]

## Öffnung, Kasse, Reservierung
[Kassenzeiten, Reservierungsfristen, Abholfristen, Storno, Online-Ticketing-Weg]

## Programm und Fassungen
[Schwerpunkt, angebotene Fassungen, Wochenstruktur, Startpraxis]

## Wiederkehrende Reihen und Sondertermine
| Reihe | Rhythmus | Termin | Zielgruppe | Besonderheit |

## Kooperationen und Aktionen
[Abomodelle, Verbandsaktionen, lokale Partner, Schulkooperationen]

## Gruppen, Vermietung, Sonderveranstaltungen
[Saalmiete, Kindergeburtstage, Schulvorstellungen, Firmenevents, Preise, Kontaktweg]

## Tonalität
Anrede: [...]
So klingen wir: [...]
So klingen wir nicht: [...]
Wörter, die wir benutzen: [...]
Wörter, die wir nie benutzen: [...]
Emojis: [...]
Beispieltext, der gut war:
> [...]

## Verbindliche Regeln
[Was nie ungeprüft rausgeht, was immer genannt werden muss (z. B. Fassung und
FSK bei jeder Titelnennung), welche Aussagen Freigabe brauchen]

## Ansprechpartner nach Funktion
[Programm, Marketing, Technik, Verwaltung, als Funktion, nicht als Klarname]

## Offene Punkte
[Was noch fehlt und wer es liefern muss]
```

### 5. Übergeben

Nach dem Schreiben: Nenne die drei Angaben, die den größten Unterschied für die Textqualität machen und noch fehlen. Und nenne den nächsten sinnvollen Schritt, meist ist das, mit dem Wochenprogramm-Skill einen ersten Durchlauf zu machen, weil sich daran sofort zeigt, ob die Tonalität-Angaben tragen.

## Warum das Interview wichtiger ist als die Datei

Für die Textqualität leisten der Abschnitt „So klingen wir nicht" und die Liste der verbotenen Wörter mehr als alle Preisangaben zusammen. Nimm dir dafür Zeit und frage nach Beispieltexten, statt Adjektive zu sammeln, „persönlich" bedeutet in jedem Haus etwas anderes, ein Beispieltext ist eindeutig.

## Hinweis zur Pflege

Das Hausprofil veraltet an zwei Stellen zuverlässig: bei Preisen und bei Reihen. Ein kurzer Blick zum Jahreswechsel und nach jeder Preisanpassung genügt. Der Rest ist stabil.

Wenn mehrere Häuser einer Gruppe versorgt werden, lege pro Haus eine eigene Datei an (`hausprofil-koeln.md`, `hausprofil-bonn.md`) und halte gemeinsame Regeln in einer zusätzlichen `hausprofil-gruppe.md`. Das ist übersichtlicher als eine Datei mit Verzweigungen.
