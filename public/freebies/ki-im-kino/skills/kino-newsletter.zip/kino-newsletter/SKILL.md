---
name: kino-newsletter
description: Schreibt den Stammgäste-Newsletter eines Kinos vollständig aus, mit mehreren Betreffzeilen zur Auswahl, Preheader, Editorial, Programmteil, Reihen- und Veranstaltungshinweisen und einem klaren Handlungsaufruf, alles in der Tonalität des Hauses. Verwende diesen Skill, wenn jemand einen Newsletter, ein Mailing, einen Programmversand oder eine Stammgast-Mail für ein Kino braucht, nach Betreffzeilen oder Öffnungsraten fragt, einen bestehenden Newsletter verbessern will, oder Formulierungen nutzt wie "Newsletter für diese Woche", "Mailing an unsere Gäste", "Betreffzeile finden", "Newsletter zur Reihe". Auch bei Sonder-Mailings zu einzelnen Veranstaltungen, Reihenstarts oder Preisaktionen und bei Formulierungen wie "Mail an unsere Abonnenten" oder "an den Verteiler". Für das vollständige Mailing einschließlich Betreffzeilen ist dieser Skill zuständig, nicht kino-wochenprogramm.
license: CC-BY-4.0
metadata:
  author: STARTPLATZ AI Academy
  version: "1.0"
  startplatz-paket: Kino-Skill-Paket (KinoConnect, August 2026)
---

# Kino-Newsletter

Der Newsletter ist für ein Kino der wirksamste eigene Kanal. Der von der FFA geförderte Kinoleitfaden nennt ihn „die einfachste, günstigste und effizienteste Art, digitales Marketing für Kinos zu betreiben". Die Größenordnungen aus der Praxis stützen das: Der Kino-Marketing-Anbieter Kinobytes berichtet für E-Mail rund 26 Prozent Öffnungsrate und rund 14 Prozent Klicks bezogen auf die Öffnungen, das entspricht gut 3 Prozent aller Versandten. Facebook-Anzeigen erzeugen demgegenüber Reichweite, aber weniger als 0,1 Prozent Klicks auf die Kinowebseite. Beides sind Anbieterangaben, keine unabhängige Studie.

Der zweite Grund, warum der Newsletter wichtiger wird: Laut FFA-Studie zu den Kinobesuchern 2025 kommen mehr Menschen, aber jeder seltener, die Besuchshäufigkeit sank auf 3,8 Tickets pro Besucher, ein Rückgang von 4 Prozent. Gleichzeitig wuchs die Gruppe der 50- bis 59-Jährigen um 18 Prozent und die über 60 um 13 Prozent, während die 20- bis 29-Jährigen um 7 Prozent zurückgingen. Bindung wird damit wichtiger als Reichweite.

Daraus folgt für jeden Newsletter: Er schreibt an Menschen, die das Haus schon kennen. Er muss nicht überzeugen, dass Kino gut ist. Er muss einen Anlass liefern, diese Woche zu kommen.

## Zuerst

Lies `hausprofil.md`, wenn vorhanden, vor allem Tonalität, Reihen, Preise und Verbindliche Regeln. Ohne Profil frag nach Anrede, Haustyp und einem Beispieltext, der gut ankam, und bitte darum, `hausprofil.md` an diese Unterhaltung anzuhängen oder im Projekt zu hinterlegen, damit die Angaben beim nächsten Mal vorliegen.

Dann klär drei Dinge, falls nicht mitgeliefert:
- **Anlass:** Regelmäßiger Wochenversand oder Sondermailing zu einer Sache?
- **Inhalt:** Spielplan, Reihentermine, Sonderveranstaltungen. Wenn das Wochenprogramm bereits mit dem Wochenprogramm-Skill erzeugt wurde, nimm dessen Newsletter-Block als Grundlage statt neu zu formulieren.
- **Ziel:** Was soll der Leser tun? Ticket kaufen, sich für eine Reihe anmelden, einen Termin vormerken, weitersagen. Genau eines pro Mailing.

## Aufbau

### Betreffzeile
Liefere **drei bis fünf Varianten** mit je einer Zeile Begründung, bei einem kurzen Sondermailing genügen drei. Die Betreffzeile ist die einzige Stelle, an der ein Newsletter komplett scheitern kann. Die Varianten sollen unterschiedliche Strategien abdecken, nicht Synonyme derselben Idee sein:

1. Konkreter Titel plus Termin, funktioniert bei starken Neustarts
2. Der kuratierende Blick, „Diese Woche empfehle ich Ihnen …"
3. Der Anlass außerhalb des Films, Ferien, Feiertag, Wetter, Stadtereignis
4. Die Knappheit, wenn sie echt ist, letzte Vorstellung, wenige Plätze, einmaliger Termin
5. Die kurze, neugierige, vier bis sechs Wörter

Halte Betreffzeilen unter etwa 50 Zeichen, damit sie auf dem Handy nicht abgeschnitten werden. Keine erfundene Dringlichkeit. Keine Ausrufezeichen-Ketten. Wenn ein Haus laut Hausprofil keine Emojis verwendet, gilt das auch hier.

### Preheader
Ein Satz, der die Betreffzeile ergänzt, nicht wiederholt. Wird in vielen Mailprogrammen direkt neben dem Betreff angezeigt und ist die am häufigsten verschenkte Zeile im ganzen Mailing.

### Editorial
Drei bis fünf Sätze von einem Menschen an Menschen. Hier entsteht der Unterschied zu einem automatisch generierten Programmversand. Gute Editorials haben einen konkreten Ausgangspunkt: eine Beobachtung aus dem Foyer, eine Entscheidung, die begründet wird, ein Hinweis auf etwas, das fast untergegangen wäre.

Was hier nicht funktioniert: allgemeine Begeisterung für das Kino als Ort, Wetterfloskeln ohne Bezug, und jede Formulierung, die auch für ein anderes Haus stimmen würde.

### Spitzenmeldung
Ein Film, ein Termin, eine Sache. Mit Empfehlung, für wen das ist. Direkt darunter der Handlungsaufruf.

### Programmteil
Kompakt und überfliegbar. Titel, Tage, Zeiten, Fassung. Ein Satz pro Film höchstens, bei Weiterläufern gar keiner. Wer alles lesen will, klickt auf die Website, das ist der Zweck des Links.

### Reihen und Sondertermine
Eigener Block, weil diese Termine Vorlauf brauchen. Anmeldebedarf, Gäste, Einführungen und Kooperationen gehören hierhin. Wenn eine Reihe Teil der Förderdokumentation ist, ist das ein zusätzlicher Grund, sie sichtbar zu machen, dokumentierte Veranstaltungen sind bei der Programmprämie punkterelevant.

### Service und Fuß
Nur was gebraucht wird: Kassenzeiten, Barrierefreiheitshinweis wenn relevant, Gutschein-Hinweis in der Vorweihnachtszeit. Pflichtangaben und Abmeldelink gehören ins Versandwerkzeug, nicht in den Textentwurf, weise einmal darauf hin, ohne sie zu formulieren.

## Zielgruppenlogik

Wenn das Versandwerkzeug Segmente erlaubt, schlage höchstens zwei vor und begründe sie mit den Programmdaten, nicht mit Demografie-Vermutungen. Tragfähig sind zum Beispiel: Menschen, die schon einmal zu einer Reihe kamen, gegenüber allen anderen. Oder: Nachmittagsbesucher gegenüber Abendbesuchern, laut FFA-Kinobesucherstudie 2019, zitiert im Kinoleitfaden, bevorzugt fast ein Drittel des Publikums, insbesondere Kinder und Menschen über 60, Vorstellungen vor 17 Uhr. Die Zahl ist älter; der ältere Teil dieser Gruppe wächst aber laut der Studie von 2025.

Wenn keine Segmentierung möglich ist, sag das und schreibe ein Mailing, das ohne funktioniert. Zwei Zielgruppen in einem Text anzusprechen gelingt, wenn die Struktur es trägt: Spitzenmeldung breit, Reihenblock spezifisch.

## Datenschutz in einem Satz

Für Newsletter gilt Double-Opt-In nach DSGVO. Adressbestände gehören nicht in ein KI-Werkzeug, der Text schon. Wenn jemand Empfängerdaten mitliefern will, weise darauf hin und arbeite ohne sie.

## Ausgabeformat

```
BETREFFZEILEN (3 bis 5 Varianten mit Begründung)
PREHEADER
---
EDITORIAL
SPITZENMELDUNG + HANDLUNGSAUFRUF
PROGRAMM DER WOCHE
REIHEN UND SONDERTERMINE
SERVICE
---
ZU PRÜFEN: [Lücken, unsichere Angaben]
VERSANDHINWEISE: [Segment-Empfehlung, Versandzeitpunkt-Empfehlung]
FÜRS HAUSPROFIL: [Korrekturen, die dauerhaft festgehalten werden sollten]
```

Zum Versandzeitpunkt: Der Wochenversand sollte da sein, wenn das neue Programm gilt oder kurz davor. Weil die Kinowoche donnerstags beginnt, ist Mittwoch oder Donnerstag der naheliegende Rhythmus. Bestätigen lässt sich das nur an den eigenen Öffnungsraten, schlage daher vor, zwei Versandzeitpunkte über einige Wochen zu vergleichen, statt eine Regel zu behaupten.

## Nichts erfinden

Keine Öffnungsraten, keine Besucherzahlen, keine Zitate, keine Auszeichnungen, keine Preise, die nicht in den Eingaben oder im Hausprofil stehen. Markiere Lücken sichtbar. In einem Mailing an Stammgäste ist eine falsche Preisangabe teurer als ein fehlender Absatz.
